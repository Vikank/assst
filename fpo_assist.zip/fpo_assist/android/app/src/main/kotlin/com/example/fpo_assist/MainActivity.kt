package com.example.fpo_assist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
