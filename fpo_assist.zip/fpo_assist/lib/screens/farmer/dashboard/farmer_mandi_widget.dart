import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FarmerMandiWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Mandi Page'),
    );
  }
}