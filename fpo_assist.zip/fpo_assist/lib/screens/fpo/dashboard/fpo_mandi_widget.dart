import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MandiWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Mandi Page'),
    );
  }
}