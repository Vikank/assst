import  json
import traceback
from django.http import JsonResponse
from .models import *
from .scraper import *
from .cron import *
from django.shortcuts import get_object_or_404
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
import random
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.sessions.models import Session
from django.http import HttpResponse
from django.db.models import Q
import pandas as pd
from django.conf import settings
import xlrd
import requests
import string
import os
from urllib.parse import urlparse
from django.core.exceptions import ObjectDoesNotExist
from django.core.files.base import ContentFile
from django.db import transaction
from transformers import pipeline
from PIL import Image
from django.core.mail import send_mail
# from newsapi import NewsApiClient
from django.core.exceptions import ValidationError
import csv
from io import StringIO
# from serpapi import BingSearch
base_url = "64.227.136.113:8090"
import ast
import logging
logger = logging.getLogger('Agreeculture_App')
#################################################################--FPO-----------------##################################


################--------------------------------FPO Registration & LOgin---------------------------####################
#Registraion
@csrf_exempt
def Fpo_Signup(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        password = data.get('password')
        mobile_no = data.get('mobile_no')
        name = data.get('name')
        
        if FPOProfile.objects.filter(mobile_no=mobile_no).exists():
            return JsonResponse({'message': 'Mobile number already exists'}, status=400)
        
        password_hash = make_password(password)
        fpo_profile = FPOProfile.objects.create(mobile_no=mobile_no, password=password_hash, fpo_name=name)
        request.session['fpo_id'] = fpo_profile.id
        return JsonResponse({'message': 'User created and logged in successfully'}, status=201)
    else:
        return JsonResponse({'message': 'Method not allowed'}, status=405)
##########-------------Login    
@csrf_exempt
def Fpo_Login(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            mobile_no = data.get('mobile_no')
            password = data.get('password')
            user_language = data.get('user_language')

            if 'fpo_id' in request.session:
                try:
                    obj = FPOProfile.objects.get(id=request.session['fpo_id'])
                    if obj.mobile_no == mobile_no:
                        if check_password(password, obj.password):
                            obj.fk_language_id = user_language
                            obj.save()
                            return JsonResponse({'message': 'User already logged in', 'obj_id': obj.id})
                        else:
                            return JsonResponse({'message': 'Password does not match'}, status=401)
                except FPOProfile.DoesNotExist:
                    # If the profile does not exist, remove the session key
                    del request.session['fpo_id']

            obj = FPOProfile.objects.filter(mobile_no=mobile_no).first()
            if obj:
                if check_password(password, obj.password):
                    obj.fk_language_id = user_language
                    obj.save()
                    request.session['fpo_id'] = obj.id
                    
                    return JsonResponse({
                        'message': 'User logged in successfully',
                        'obj_id': obj.id,
                    })
                else:
                    return JsonResponse({'message': 'Password does not match'}, status=401)
            else:
                hashed_password = make_password(password)
                obj = FPOProfile.objects.create(mobile_no=mobile_no, password=hashed_password, fk_language_id=user_language)
                request.session['fpo_id'] = obj.id

                # Add Coins
                coin_amount = 100
                obj.add_coins(coin_amount)
                
                return JsonResponse({
                    'message': 'User created and logged in successfully',
                    'obj_id': obj.id,
                    'coins': obj.coins
                })
        else:
            return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
#####################---------------------Logout
@csrf_exempt
def Fpo_Logout(request):
    try:
        if request.method == "POST":
            if 'fpo_id' in request.session:
                del request.session['fpo_id']
                request.session.save()
                return JsonResponse({'message': 'User logged out successfully'})
            else:
                return JsonResponse({'message': 'User not logged in'})
        else:
            return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
#-----------------Forgot Password------------------##########
def generate_otp(length=6):
    lower_bound = 10**(length-1)
    upper_bound = 10**length - 1
    otp = random.randint(lower_bound, upper_bound)
    return otp

global_otp_store = {}
@csrf_exempt
def forgot_sendotp(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            email = data.get('email')
            if not email:
                return JsonResponse({'message': 'Email is required'}, status=400)
            
            fpo_profile = FPOProfile.objects.filter(email=email).first()
            if not fpo_profile:
                return JsonResponse({'message': 'Email not Found'}, status=404)

            otp = generate_otp()
            print("Generated OTP:", otp)
            
            # Store OTP in global store with email as the key
            global_otp_store[email] = otp
            print("Stored OTP for email:", email, otp)
            
            subject = 'Password Reset OTP'
            message = f'Your OTP for password reset is: {otp}'
            from_email = 'admin@accessassist.in'
            recipient_list = [email]
            send_mail(subject, message, from_email, recipient_list)
            
            return JsonResponse({'message': 'OTP sent successfully'})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)


@csrf_exempt
def verify_otp(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            email = data.get('email')
            entered_otp = data.get('entered_otp')
            
            if not email or not entered_otp:
                return JsonResponse({'error': 'Email and OTP are required'}, status=400)

            print("Entered OTP:", entered_otp)
            
            # Retrieve OTP from global store
            otp = global_otp_store.get(email)
            print("Retrieved OTP from global store for email", email, ":", otp)
            
            if otp and entered_otp == otp:
                del global_otp_store[email]
                return JsonResponse({'status': 'success', 'message': 'OTP Verified Successfully'}, status=200)
            else:
                return JsonResponse({'error': 'Invalid OTP. Please try again.'}, status=400)
        else:
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##---------------Generate New Password and match it
@csrf_exempt
def FPOreset_password(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            mobile_no = data.get('mobile_no')
            new_password = data.get('new_password')

            obj = FPOProfile.objects.filter(mobile_no=mobile_no).first()
            if obj:

                obj.password = make_password(new_password)  
                obj.save()
                return JsonResponse({'message': 'Password updated successfully'})
                
            else:
                return JsonResponse({'message': 'User does not exist'}, status=404)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
#####------------------------------------FPO Register Profile Update----------------------------------###################
@csrf_exempt
def FPO_profile_update(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            try:
                fpo_profile = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            fpo_bank_business, created = BankBusinessDetails.objects.get_or_create(fk_fpo=fpo_profile)
            fpo_shop,created=ShopDetails.objects.get_or_create(fk_fpo=fpo_profile)
            fpo_fields = [
             'mobile_no', 'fpo_name',
             'address', 'pincode', 'state', 'district',
            'sub_district', 'village'
            ]
            bank_business_fields = [
            'accountholder_name', 'account_number', 'bank_name', 'ifsc_code',
            'business_establishdate', 'pan_no', 'registration_id', 'gst_number'
            ]
            shop_details=[
                'shopName','shopContactNo','shopaddress','shop_opentime','shop_closetime','shop_opendays','shop_closedon'
            ]
            for i in fpo_fields:
                if i in data:
                    setattr(fpo_profile,i,data[i])
            for i in bank_business_fields:
                if i in data:
                    setattr(fpo_bank_business,i,data[i])
            for i in shop_details:
                if i in data:
                    setattr(fpo_shop,i,data[i])
            fpo_profile.save()
            fpo_bank_business.save()
            fpo_shop.save()
            return JsonResponse({'message': 'FPO profile updated successfully'}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except FPOProfile.DoesNotExist:
        return JsonResponse({'message': 'FPO not found'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
#############################------------------FPO PRofile pic Update-----------------------##############
@csrf_exempt
def FPOProfilePictureUpdate(request):
    try:
        if request.method=="POST":
            userid = request.POST.get('userid')
            profile_image = request.FILES.get('profile_image')
            try:
                fpo_profile = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            fpo_profile.profile=profile_image
            fpo_profile.save()
            return JsonResponse({'message': 'FPO Image updated successfully'}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
###------------------------------------------Get FPO Details-------------------------###################
@csrf_exempt
def GetFPODetails(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data['userid']
            try:
                fpo_data = FPOProfile.objects.filter(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            fpobank_business=BankBusinessDetails.objects.filter(fk_fpo_id=userid)
            fposhop_details=ShopDetails.objects.filter(fk_fpo_id=userid)
            return JsonResponse({'message':'suceess',"basic_info":list(fpo_data.values()),
                                 'bank_business':list(fpobank_business.values()),
                                 'shop_details':list(fposhop_details.values())})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except FPOProfile.DoesNotExist:
        return JsonResponse({'error': 'User does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
######################-------------------------FPO Rewards Profile-------------------------------------#######################
############----------------------------FPO Coins------------------------------############
@csrf_exempt
def show_coinsfpo(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            fpo_profile = FPOProfile.objects.filter(id=user_id).first()
            if fpo_profile:
                id=fpo_profile.id
                coins = fpo_profile.coins
                image=fpo_profile.profile.url
                return JsonResponse({"userid":id,'coins': coins,"image":image})
            else:
                return JsonResponse({'error': 'User not found'}, status=404)
        else:
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred', 'error': traceback.format_exc()}, status=500)

######################################---FPO WInner with BADGES-----------------------------------#######################
@csrf_exempt
def show_winners(request):
    try:
        if request.method == 'GET':
            fpo_users = FPOProfile.objects.all().order_by('-coins').values('id', 'coins', 'state', 'badgecolor')
            rss = list(fpo_users)
            data = []
            for i in rss:
                res = {
                    "coins": i['coins'],
                    "state": i['state'],
                    "badgecolor": i['badgecolor']
                }
                data.append(res)
            return JsonResponse({"status": "success", "fpo_users": data})
        else:
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred', 'error': str(e)}, status=500)
    
#######################------------------FPO Winner Filter Wise---------------------------###############
@csrf_exempt
def filterwinners(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            filter_type = data.get('filter_type')
            if not filter_type:
                return JsonResponse({'error': 'Invalid Filter.'}, status=400)
            if filter_type=="State level":
                fpo_profile=FPOProfile.objects.values('fpo_name','coins','state','profile','badgecolor')
            elif filter_type=="District level":
                fpo_profile=FPOProfile.objects.values('fpo_name','coins','district','profile','badgecolor')
            elif filter_type=="Village level":
                fpo_profile=FPOProfile.objects.values('fpo_name','coins','village','profile','badgecolor')
            return JsonResponse({"status": "success", "filter_type": filter_type, "fpo_users": list(fpo_profile)})
        else:
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred', 'error': traceback.format_exc()}, status=500)


#################-----------------------------Add Farmers By FPO Profile------------------------- #################
@csrf_exempt
def Add_FarmerbyFpo(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            farmer_name = data.get('farmer_name')
            farmer_mobile = data.get('farmer_mobile')
            farmer_village=data.get('farmer_village')
            farmer_block=data.get('farmer_block')
            land_area=data.get('land_area')
            try:
                fpouser = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            if FarmerProfile.objects.filter(mobile_no=farmer_mobile).exists():
                return JsonResponse({'message': 'Mobile number already exists'}, status=400)

            farmer = FarmerProfile.objects.create(
                fpo_name=fpouser,
                name=farmer_name,
                mobile_no=farmer_mobile,
                village=farmer_village,
                block=farmer_block
            )
            farmer_land=FarmerLandAddress.objects.create(fk_farmer=farmer,land_area=land_area)
            return JsonResponse({'message': 'Farmer added successfully', 'farmer_id': farmer.id,'land_id':farmer_land.id})

        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    

##########################----------------------------Add Farmer by FPO via CSV File---------------################
@csrf_exempt
def Add_Farmer_Csv(request):
    try:
        if request.method == "POST":
            csv_file = request.FILES['csv_file']
            df = pd.read_excel(csv_file)
            userid = request.POST.get('userid')
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            for i, j in df.iterrows():
                mobile_no = j['mobile_number']
                if not FarmerProfile.objects.filter(mobile_no=mobile_no).exists():
                    farmer=FarmerProfile.objects.create(
                        fpo_name=fpo,
                        name=j['name'],
                        mobile_no=mobile_no,
                        village=j['village'],
                        block=j['block']
                    )
                    farmer_land=FarmerLandAddress.objects.create(fk_farmer=farmer,land_area=j['land_area'])
            return JsonResponse({'message': 'Farmers added successfully via Excel'})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
############-------------------------ADD Product Details BY FPO--------------###################
@csrf_exempt
def AddProductDetails_FPO(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        userid = data.get('userid')
        if not userid:
            return JsonResponse({'message': 'FPO ID is required'}, status=400)
        try:
            fpo = FPOProfile.objects.get(id=userid)
        except FPOProfile.DoesNotExist:
            return JsonResponse({'message': 'FPO not found'}, status=404)

        filter_type = data.get('filter_type')
        product_data = {
            'productName': data.get('productName'),
            'productDescription': data.get('productDescription'),
            'composition': data.get('composition'),
            'measurement_type': data.get('measurement_type'),
            'measurement_unit':data.get('measurement_unit'),
            'selling_status': data.get('selling_status'),
            'Category':data.get('Category'),
            'quantity':data.get('quantity'),
            'fk_productype_id': data.get('producttype'),
            'fk_fpo': fpo,
            'expiry_date': data.get('expiry_date')
        }

        if filter_type == "Agricultural Inputs" or filter_type == "Finish Goods":
            product_data['manufacturerName'] = data.get('manufacturerName')
        elif filter_type == "Crops":
            product_data['fk_crops_id'] = data.get('crop_id')
            product_data['fk_variety_id'] = data.get('variety')
        supplier=FPOSuppliers.objects.create(
            fk_fpo=fpo,
            fk_productype_id=data.get('producttype'),
            quantity=data.get('quantity'),
            total_amount=data.get('purchase_price'),
            party_name=data.get('party_name'),
            party_mobileno=data.get('mobileno'),
            party_company=data.get('company_name'),
            unit_price=data.get('unit_price'),
            party_gst=data.get('party_gst')
        )
        product = ProductDetails.objects.create(**product_data)
        product.fk_fposupplier=supplier
        product.save()
        ProductPrices.objects.create(
            fk_product=product,
            purchase_price=data.get('purchase_price'),
            unit_price=data.get('unit_price'),
            #discount=data.get('discount',0),
            final_price_unit=data.get('final_price'),
            fk_fpo=fpo,
            fk_fposupplier=supplier  
        )
        InventoryDetails.objects.create(
            fk_product=product,
            fk_fpo=fpo,
            stock=data.get('quantity', 0),
            fk_fposupplier=supplier
            #fk_price=data.get('final_price')
        )
        
        return JsonResponse({'message': 'Product created & Added successfully!'})
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
#############################--------------------------UPDATE Product Details BY FPO----------------############
@csrf_exempt
def UpdateProduct_DeatilsFPO(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)
    
    try:
        data = json.loads(request.body.decode('utf-8'))
        product_id = data.get('product_id')
        userid = data.get('userid')
        
        if not product_id or not userid:
            return JsonResponse({'message': 'Product ID and FPO ID are required'}, status=400)
        
        try:
            fpo = FPOProfile.objects.get(id=userid)
        except FPOProfile.DoesNotExist:
            return JsonResponse({'message': 'FPO not found'}, status=404)
        
        try:
            product = ProductDetails.objects.get(id=product_id, fk_fpo=fpo)
        except ProductDetails.DoesNotExist:
            return JsonResponse({'message': 'Product not found'}, status=404)

        # Update product details
        product.quantity = data.get('quantity', product.quantity)
        product.expiry_date = data.get('expiry_date', product.expiry_date)
        product.productName = data.get('productName', product.productName)
        product.productDescription = data.get('productDescription', product.productDescription)
        product.composition = data.get('composition', product.composition)
        product.measurement_type = data.get('measurement_type', product.measurement_type)
        product.measurement_unit = data.get('measurement_unit', product.measurement_unit)
        product.selling_status = data.get('selling_status', product.selling_status)
        product.Category = data.get('Category', product.Category)
        product.fk_productype_id = data.get('producttype', product.fk_productype_id)

        filter_type = data.get('filter_type')
        if filter_type in ["Agricultural Inputs", "Finish Goods"]:
            product.manufacturerName = data.get('manufacturerName', product.manufacturerName)
        elif filter_type == "Crops":
            product.fk_crops_id = data.get('crop_id', product.fk_crops_id)
            product.fk_variety_id = data.get('variety_id', product.fk_variety_id)
        
        product.save()

        # Update the product prices
        try:
            product_prices = ProductPrices.objects.get(fk_product=product, fk_fpo=fpo)
            product_prices.purchase_price = data.get('purchase_price', product_prices.purchase_price)
            product_prices.unit_price = data.get('unit_price', product_prices.unit_price)
            product_prices.discount = data.get('discount', product_prices.discount)
            product_prices.final_price_unit = data.get('final_price', product_prices.final_price_unit)
            product_prices.save()
        except ProductPrices.DoesNotExist:
            return JsonResponse({'message': 'Product prices not found'}, status=404)
        try:
            inventory = InventoryDetails.objects.get(fk_product=product,fk_fpo=fpo)
            inventory.stock = product.quantity
            inventory.save()
        except InventoryDetails.DoesNotExist:
            return JsonResponse({'message': 'Inventory details not found'}, status=404)

        return JsonResponse({'message': 'Product updated successfully!'})
    
    except json.JSONDecodeError:
        return JsonResponse({'message': 'Invalid JSON'}, status=400)
    
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e), 'traceback': traceback.format_exc()}, status=500)
    
####################################----------------------Get all Products BY FPO------------------#########
@csrf_exempt
def GetFPOAllProducts(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        userid = data.get('userid')

        products = InventoryDetails.objects.filter(fk_fpo_id=userid)
        if not products.exists():
            return JsonResponse({'message': 'No products found for the specified filter type'}, status=404)

        product_list = []
        for product in products:
            product_details = product.fk_product  # Assuming fk_product is a ForeignKey to ProductDetails
            if product_details:
                product_data = {
                    'inventory_id': product.id,
                    'supplier_id':product.fk_fposupplier.id if product.fk_fposupplier else None,
                    'supplier_state':product.fk_fposupplier.state if product.fk_fposupplier else None,
                    'supplier_name':product.fk_fposupplier.party_name if product.fk_fposupplier else None,
                    'supplier_district':product.fk_fposupplier.district if product.fk_fposupplier else None,
                    'stock_status': product.stock_status() if product else None,
                    'stock_quantity': product.stock if product else 0,
                    'product_id': product_details.id,
                    'productName': product_details.productName,
                    'Category': product_details.Category,
                    'product_type': product_details.fk_productype.product_type,
                }
                product_prices = ProductPrices.objects.filter(fk_product=product_details)
                if product_prices.exists():
                    price_data = {
                        'purchase_price': product_prices.first().purchase_price,
                        'unit_price': product_prices.first().unit_price,
                        'discount': product_prices.first().discount,
                        'final_price': product_prices.first().final_price_unit,
                    }
                    product_data.update(price_data)

                product_list.append(product_data)

        return JsonResponse({'status': 'success', 'products': product_list})

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##############################################----------------GET Produtc Details-----------------------###################
@csrf_exempt
def GetFPOProductDetails(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        userid=data.get('userid')
        filter_type = data.get('filter_type')
        if not filter_type:
            return JsonResponse({'message': 'Filter type is required'}, status=400)

        products = ProductDetails.objects.filter(fk_productype__product_type=filter_type,fk_fpo_id=userid)

        product_list = []
        for product in products:
            product_data = {
                'product_id':product.id,
                'productName': product.productName,
                'Category':product.Category,
                'productDescription': product.productDescription,
                'composition': product.composition,
                'measurement_type': product.measurement_type,
                'measurement_unit':product.measurement_unit,
                'selling_status': product.selling_status,
                'manufacturerName': product.manufacturerName if filter_type in ["Agricultural Inputs", "Finish Goods"] else None,
                'crop_name': product.fk_crops.crop_name if product.fk_crops else None,
                'variety': product.fk_variety.variety if product.fk_variety else None,
                'expiry_date':product.expiry_date
            }
            product_prices = ProductPrices.objects.filter(fk_product=product)
            if product_prices.exists():
                price_data = {
                    'purchase_price': product_prices.first().purchase_price,
                    'unit_price': product_prices.first().unit_price,
                    'discount': product_prices.first().discount,
                    'final_price': product_prices.first().final_price_unit,
                }
                product_data.update(price_data)

            product_list.append(product_data)

        return JsonResponse({'status': 'success','products': product_list})

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

##############-----------------------------------Add Product Details by FPO via CSV----------------------##################
@csrf_exempt
def AddProductDetails_FPO_Csv(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)
    
    try:
        userid = request.POST.get('userid')
        if not userid:
            return JsonResponse({'message': 'FPO ID is required'}, status=400)
        
        try:
            fpo = FPOProfile.objects.get(id=userid)
        except FPOProfile.DoesNotExist:
            return JsonResponse({'message': 'FPO not found'}, status=404)
        
        filter_type = request.POST.get('filter_type')
        if not filter_type:
            return JsonResponse({'message': 'Product type is required'}, status=400)
        
        excel_file = request.FILES.get('excel_file')
        if not excel_file:
            return JsonResponse({'message': 'Excel file is required'}, status=400)
        
        if not excel_file.name.endswith('.xlsx'):
            return JsonResponse({'message': 'File is not an Excel file'}, status=400)
        
        df = pd.read_excel(excel_file)
        products_created = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                try:
                    product_type = ProductType.objects.get(product_type__iexact=filter_type)
                except ProductType.DoesNotExist:
                    raise ValueError(f'Product type "{filter_type}" not found')
                
                product_data = {
                    'productName': row.get('ProductName', ''),
                    'Category': row.get('Category', ''),
                    'quantity': row.get('Quantity', 0),  # Replace with appropriate default
                    'productDescription': row.get('ProductDescription', ''),
                    'composition': row.get('Composition', ''),
                    'measurement_type': row.get('Measurement', ''),
                    'measurement_unit': row.get('MeasurementIn', ''),
                    'selling_status': row.get('Selling Status', ''),
                    'expiry_date': row.get('Expiry Date', None),  # Replace with appropriate default
                    'fk_productype': product_type,
                    'fk_fpo': fpo,
                    'manufacturerName': row.get('Manufacturer', '')
                }
                
                if filter_type == "Crops":
                    crop_name = row['CropName']
                    try:
                        crop = CropMaster.objects.get(crop_name__iexact=crop_name)
                    except CropMaster.DoesNotExist:
                        raise ValueError(f'Crop "{crop_name}" not found in Crop Master')
                    
                    variety_name = row['Variety']
                    try:
                        variety = CropVariety.objects.get(fk_crops=crop, variety__iexact=variety_name)
                    except CropVariety.DoesNotExist:
                        raise ValueError(f'Variety "{variety_name}" not found for crop "{crop.crop_name}"')
                    
                    product_data.update({
                        'fk_crops': crop,
                        'fk_variety': variety
                    })
                
                product = ProductDetails.objects.create(**product_data)
                
                ProductPrices.objects.create(
                    fk_product=product,
                    purchase_price=row.get('Purchase Price', 0),  # Replace with appropriate default
                    unit_price=row.get('Selling Price', 0),  # Replace with appropriate default
                    discount=row.get('Discount', 0),  # Replace with appropriate default
                    final_price_unit=row.get('Final Price', 0),  # Replace with appropriate default
                    fk_fpo=fpo
                )
                
                supplier_data = {
                    'fk_fpo': fpo,
                    'fk_productype': product_type,
                    'quantity': row.get('Quantity', 0),  # Replace with appropriate default
                    'total_amount': row.get('Purchase Price', 0),  # Replace with appropriate default
                    'party_name': row.get('Party Name', ''),
                    'party_mobileno': row.get('Mobile No', ''),
                    'party_company': row.get('Company Name', ''),
                    'unit_price': row.get('Unit Price', 0),  # Replace with appropriate default
                    'party_gst': row.get('Party GST', '')
                }
                
                supplier = FPOSuppliers.objects.create(**supplier_data)
                
                InventoryDetails.objects.create(
                    fk_product=product,
                    fk_fpo=fpo,
                    stock=row.get('Quantity', 0),  # Replace with appropriate default
                    fk_fposupplier=supplier
                )
                
                products_created += 1
            
            except Exception as e:
                errors.append(f"Error in row {index + 2}: {str(e)}")
        
        result = {
            'message': f'{products_created} products created successfully',
            'errors': errors
        }
        return JsonResponse(result)
    
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)

####################----------------------SHow Product/Inventory DETAILS---------------------------##########
@csrf_exempt
def ShowInventory(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method. Use POST.'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        filter_type = data.get('filter_type')
        userid = data.get('userid')
        if not filter_type or not userid:
            return JsonResponse({'error': 'Filter type and FPO ID are required.'}, status=400)
        product_type = ProductType.objects.filter(product_type=filter_type).first()
        if not product_type:
            return JsonResponse({'error': 'Invalid filter type.'}, status=400)
        fpo = FPOProfile.objects.filter(id=userid).first()
        if not fpo:
            return JsonResponse({'error': 'Invalid FPO ID.'}, status=400)

        products = ProductDetails.objects.filter(fk_productype=product_type,fk_fpo=fpo)
        response_data = []
        
        for product in products:
            inventory = InventoryDetails.objects.filter(fk_product=product,fk_fpo=fpo).first()
            response_data.append({
                'product_id': product.id,
                'product_name': product.productName,
                'Category': product.Category,
                'product_expiry':product.expiry_datestatus(),
                'inventory_id': inventory.id if inventory else None,
                'stock_status': inventory.stock_status() if inventory else None,
                'stock_quantity': inventory.stock if inventory else 0,
                "sell_via":product.selling_status if product else None
            })

        return JsonResponse(response_data, safe=False)

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

#############################------------------------------Update Inventory------------------------------################
@csrf_exempt
def UpdateInventorybyFPO(request):
    try:
        if request.method=="POST":
            data=json.loads(request.body.decode('utf-8'))
            inventory_id=data.get('inventory_id')
            new_stock=data.get('new_stock')
            userid=data.get('userid')
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            if inventory_id is None or new_stock is None:
                return JsonResponse({'error': 'Inventory ID and new stock value are required.'}, status=400)
            try:
                new_stock = int(new_stock)
            except ValueError:
                return JsonResponse({'error': 'Stock value must be an integer.'}, status=400)
            inventory = InventoryDetails.objects.filter(id=inventory_id,fk_fpo=fpo).first()
            product_id=inventory.fk_product.id
            if not inventory:
                return JsonResponse({'error': 'Invalid inventory ID.'}, status=400)
            # Get the associated product
            product = ProductDetails.objects.filter(id=product_id).first()
            if not product:
                return JsonResponse({'error': 'Associated product not found.'}, status=400)
            if new_stock > product.quantity:
                return JsonResponse({
                    'error': 'Stock update failed. New stock value exceeds the product\'s original quantity.',
                    'max_allowed': product.quantity
                }, status=400)
            inventory.stock = new_stock
            inventory.save()
            return JsonResponse({
            'message': 'Stock updated successfully',
            'inventory_id': inventory.id,
            'new_stock': inventory.stock,
            'stock_status': inventory.stock_status()
        })

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##################################-----------------------------------ADD Sales to Customer---------------############
@csrf_exempt
def AddSalesbyFPO(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            required_fields = ['userid', 'buyer_name', 'mobile_no', 'address', 'sale_date', 'products', 'payment']
            for field in required_fields:
                if field not in data or not data[field]:
                    return JsonResponse({'error': f'Missing or empty field: {field}'}, status=400)
            userid = data.get('userid')
            buyer_name = data.get('buyer_name')
            mobile_no = data.get('mobile_no')
            address = data.get('address')
            sale_date = data.get('sale_date')
            products = data.get('products')
            payment = data.get('payment')
            #Check Fpo id
            fpo = FPOProfile.objects.filter(id=userid).first()
            if not fpo:
                return JsonResponse({'error': 'Invalid FPO ID.'}, status=400)
             # Check if the mobile number belongs to a farmer
            try:
                farmer = FarmerProfile.objects.get(mobile_no=mobile_no, fpo_name=fpo)
                is_farmer = True
            except FarmerProfile.DoesNotExist:
                is_farmer = False
            discount = data.get('discount', 0) if is_farmer else 0

            customer = CustomerDetails.objects.create(
                buyer_name=buyer_name,
                mobile_no=mobile_no,
                address=address,
                fk_fpo=fpo
            )
            with transaction.atomic():
                sale_responses = []
                total_price = 0
                for product_data in products:
                    quantity = product_data.get('Quantity')
                    inventory_id = product_data.get('inventory_id')
                    inventory = InventoryDetails.objects.filter(id=inventory_id, fk_fpo=fpo).first()
                    if not inventory:
                        return JsonResponse({'error': f'Inventory not found for product id: {inventory_id}'}, status=404)
                    product = inventory.fk_product
                    if inventory.stock < quantity:
                        return JsonResponse({"error": f"Insufficient stock for product: {product.productName}"}, status=400)

                    try:
                        productprice = ProductPrices.objects.filter(fk_product=product).first()
                        price = productprice.final_price_unit
                        amount = price * quantity
                        amount -= amount * (discount / 100)  
                    except TypeError:
                        return JsonResponse({'error': f'Invalid price or quantity for product: {product.productName}'}, status=400)

                    # Update Inventory
                    inventory.stock -= quantity
                    inventory.save()

                    # Update Product Quantity
                    product.quantity -= quantity
                    product.save()

                    # Create Sales
                    sale = ProductSale.objects.create(
                        fk_invent=inventory,
                        amount=amount,
                        sales_date=sale_date,
                        final_price=price,
                        payment_method=payment,
                        fk_custom=customer
                    )

                    sale_responses.append({
                        "sale_id": sale.id,
                        "product_name": product.productName,
                        "final_price": price,
                        "remaining_stock": inventory.stock,
                    })
                    total_price += amount

                    SalesRecordItem.objects.create(
                        name=buyer_name,
                        quantity=quantity,
                        total_amount=amount,
                        fk_fpo=fpo,
                        sales_date=sale_date,
                        category=inventory.fk_product.fk_productype.product_type,
                        fk_fposupplier_id=inventory.fk_fposupplier.id
                    )

            return JsonResponse({
                "message": "Sales processed successfully",
                "sales": sale_responses,
                "total_price": total_price
            }, status=201)

        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except KeyError as e:
        return JsonResponse({"error": f"Missing field {str(e)}"}, status=400)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': traceback.format_exc()}, status=500)

################---------------------------------Get all Sales---------------###################################
@csrf_exempt
def GetCustomerRecordSales(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            customer_sales=SalesRecordItem.objects.filter(fk_fpo_id=userid)
            return JsonResponse({"message": "success",'data':list(customer_sales.values())})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
#######################----------------------------Get FPO Supplier Details-----------------#########
@csrf_exempt
def GetFPOSuppliersInfo(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            if not userid:
                return JsonResponse({'message': 'User ID not provided'}, status=400)
            suppliers = FPOSuppliers.objects.filter(fk_fpo_id=userid)
            supplier_details = []
            product_details = []
            price_details=[]

            for supplier in suppliers:
                products = ProductDetails.objects.filter(fk_fpo_id=userid, fk_fposupplier=supplier.id)
                product_names = ', '.join([product.productName for product in products])
                supplier_details.append({
                    'supplierid': supplier.id,
                    'suppliername': supplier.party_name,
                    'suppliermobileno': supplier.party_mobileno,
                    'party_company': supplier.party_company,
                    'total_amount': supplier.total_amount,
                    'unit_pricebought': supplier.unit_price,
                    'party_gst': supplier.party_gst,
                    'producttype': supplier.fk_productype.product_type if supplier.fk_productype else None,
                    'quantity': supplier.quantity,
                    'product_names': product_names
                })

                products = ProductDetails.objects.filter(fk_fpo_id=userid, fk_fposupplier=supplier.id)
                for product in products:
                    product_details.append({
                        'supplierid':product.fk_fposupplier.id if product else None,
                        'product_id': product.id,
                        'productName': product.productName,
                        'Category': product.Category,
                        'productDescription': product.productDescription,
                        'composition': product.composition,
                        'measurement_type': product.measurement_type,
                        'measurement_unit': product.measurement_unit,
                        'selling_status': product.selling_status,
                        'manufacturerName': product.manufacturerName,
                        'crop_name': product.fk_crops.crop_name if product.fk_crops else None,
                        'variety': product.fk_variety.variety if product.fk_variety else None,
                        'expiry_date': product.expiry_date
                    })
                prices=ProductPrices.objects.filter(fk_fpo_id=userid, fk_fposupplier=supplier.id)
                for price in prices:
                    price_details.append({
                        'product_id':price.fk_product.id if price else None,
                        'supplierid':price.fk_fposupplier.id if price else None,
                        'unit_price':price.unit_price,
                        'purchase_price':price.purchase_price,
                    })

            return JsonResponse({"message": "success", 'supplier_details': supplier_details, 'product_details': product_details,
                                 'price_details':price_details})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        import traceback
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##################---------------------------------FPO Purchase Record-----------------------#############
@csrf_exempt
def GetFPOPurchaseInfo(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            userid=data.get('userid')
            supplierid = data.get('supplierid')
            if not supplierid:
                return JsonResponse({'message': 'User ID not provided'}, status=400)
            
            suppliers = FPOSuppliers.objects.filter(id=supplierid,fk_fpo_id=userid)
            supplier_details = []

            for supplier in suppliers:
                products = ProductDetails.objects.filter(fk_fposupplier_id=supplierid,fk_fpo_id=userid)
                product_details = []
                for product in products:
                    product_details.append({
                        'product_id': product.id,
                        'productName': product.productName,
                        'Category': product.Category,
                        'productDescription': product.productDescription,
                        'composition': product.composition,
                        'measurement_type': product.measurement_type,
                        'measurement_unit': product.measurement_unit,
                        'selling_status': product.selling_status,
                        'manufacturerName': product.manufacturerName,
                        'crop_name': product.fk_crops.crop_name if product.fk_crops else None,
                        'variety': product.fk_variety.variety if product.fk_variety else None,
                        'expiry_date': product.expiry_date
                    })
                
                prices = ProductPrices.objects.filter(fk_fposupplier_id=supplierid,fk_fpo_id=userid)
                price_details = []
                for price in prices:
                    price_details.append({
                        'product_id': price.fk_product.id if price else None,
                        'unit_price': price.unit_price,
                        'purchase_price': price.purchase_price,
                    })
                
                supplier_details.append({
                    'supplierid': supplier.id,
                    'suppliername': supplier.party_name,
                    'suppliermobileno': supplier.party_mobileno,
                    'party_company': supplier.party_company,
                    'total_amount': supplier.total_amount,
                    'unit_pricebought': supplier.unit_price,
                    'party_gst': supplier.party_gst,
                    'producttype': supplier.fk_productype.product_type,
                    'quantity': supplier.quantity,
                    'products': product_details,
                    'prices': price_details
                })

            return JsonResponse({"message": "success", 'supplier_details': supplier_details})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        import traceback
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
###########################-----------------------Get ALL Sample Product Information----------------#################
@csrf_exempt
def GetProductCategoryWise(request):
    try:
        if request.method == "POST":
            # Fetch all products
            all_products = ProductDetails.objects.all()
            categorized_data = []
            for product in all_products:
                product_data = {
                    "product_id": product.id,
                    "productName": product.productName,
                    "crop_id": product.fk_crop_type.id if product.fk_crop_type else None,
                    "crop_name": product.fk_crop_type.crop_name if product.fk_crop_type else None,
                    "weight": product.weight,
                    "productDescription": product.productDescription,
                    "price": product.price,
                    "manufacturerName": product.manufacturerName,
                    "product_image": product.product_image.url if product.product_image else None,
                    "measurement_type": product.measurement_type,
                    "quantity": product.quantity,
                    "Category": product.Category
                }
                
                categorized_data.append(product_data)
            
            return JsonResponse({"status": "success", "fpo_product": categorized_data}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
###########################---------------------------Get Single Product Details---------------------------##############
@csrf_exempt
def GetSingleProduct_FPODetails(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data['userid']
            product_id = data.get('product_id') 
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'error': 'User does not exist'}, status=404)
            
            fpo_product = ProductDetails.objects.filter(fk_fpo=fpo, id=product_id)
            for i in fpo_product:
                prices=ProductPrices.objects.filter(fk_product=i,fk_fpo=fpo).first()
                res=({
                    'productid':i.id,
                    "productname":i.productName,
                    "productdescription":i.productDescription,
                    'manufacturerName':i.manufacturerName,
                    'manufacturing_date':i.manufacturing_date,
                    'crop_id':i.fk_crops.id if i.fk_crops else None,
                    'measurement_type':i.measurement_type,
                    'measurement_unit':i.measurement_unit,
                    'composition':i.composition,
                    'quantity':i.quantity,
                    'selling_status':i.selling_status,
                    'productype':i.fk_productype.product_type,
                    'Category':i.Category,
                    'cropname':i.fk_crops.crop_name if i.fk_crops else None,
                    'variety':i.fk_variety.id if i.fk_variety else None,
                    'expirydate':i.expiry_date,
                    'purchase_price':prices.purchase_price if prices else None,
                    'unit_price':prices.unit_price if prices else None,
                    'discount':prices.discount if prices else None,
                    'gst':prices.gst if prices else None,
                    'sgst':prices.sgst if prices else None,
                    'cgst':prices.cgst if prices else None,
                    'final_price_unit':prices.final_price_unit if prices else None
                })
            return JsonResponse({"success": res})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)


############----------------------------FPO Coins------------------------------############
@csrf_exempt
def show_coinsfpo(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            fpo_profile = FPOProfile.objects.filter(id=userid).first()
            if fpo_profile:
                id = fpo_profile.id
                coins = fpo_profile.coins
                image_url = fpo_profile.profile.url if fpo_profile.profile else None
                return JsonResponse({"userid": id, 'coins': coins, "image": image_url})
            else:
                return JsonResponse({'error': 'User not found'}, status=404)
        else:
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
    except Exception as e:
        import traceback
        return JsonResponse({'error': 'An error occurred', 'error_details': traceback.format_exc()}, status=500)
######################################---FPO WInner with BADGES-----------------------------------#######################
@csrf_exempt
def show_winners(request):
    try:
        if request.method == 'GET':
            fpo_users = FPOProfile.objects.all().order_by('-coins').values('id', 'coins', 'state', 'badgecolor')
            rss = list(fpo_users)
            data = []
            for i in rss:
                res = {
                    "coins": i['coins'],
                    "state": i['state'],
                    "badgecolor": i['badgecolor']
                }
                data.append(res)
            return JsonResponse({"status": "success", "fpo_users": data})
        else:
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred', 'error': str(e)}, status=500)
    
#######################------------------FPO Winner Filter Wise---------------------------###############
@csrf_exempt
def filterwinners(request):
    try:
        if request.method != 'POST':
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
        try:
            data = json.loads(request.body.decode('utf-8'))
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON format.'}, status=400)
        filter_type = data.get('filter_type')
        if not filter_type:
            return JsonResponse({'error': 'Filter type is required.'}, status=400)

        if filter_type == "State level":
            fpo_profile = FPOProfile.objects.values('fpo_name', 'coins', 'state', 'profile', 'badgecolor')
        elif filter_type == "District level":
            fpo_profile = FPOProfile.objects.values('fpo_name', 'coins', 'district', 'profile', 'badgecolor')
        elif filter_type == "Village level":
            fpo_profile = FPOProfile.objects.values('fpo_name', 'coins', 'village', 'profile', 'badgecolor')
        else:
            return JsonResponse({'error': 'Invalid filter type.'}, status=400)

        return JsonResponse({"status": "success", "filter_type": filter_type, "fpo_users": list(fpo_profile)})
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

#############################-----------------------------------FPO Dashboard Home Page---------------------##########
#-------------------------------------------1.Inventory In & Out of Stock
def format_inventory_details(inventory_items):
    """Helper function to format inventory details."""
    return [{
        'inventory_id': item.id,
        'product_id': item.fk_product.id if item.fk_product else None,
        'productname': item.fk_product.productName if item.fk_product else None,
        'productytpe': item.fk_product.fk_productype.product_type if item.fk_product else None,
        'expiry_date':item.fk_product.expiry_date if item.fk_product else None,
        'stock': item.stock,
        'stock_status': item.stock_status()
    } for item in inventory_items]
@csrf_exempt
def FPOInventoryinstock(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            filter_type = data.get('filter_type')
            required_fields=['userid', 'filter_type']
            for i  in required_fields:
                if not data.get(i):
                    return JsonResponse({'message': f'Missing{i} is required'}, status=400)
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)

            in_stock_filter = InventoryDetails.objects.filter(stock__gte=10, fk_fpo=fpo, fk_product__selling_status=filter_type)

            # Apply common formatting
            instockls = format_inventory_details(in_stock_filter)
           
            # Get totals
            totalintsock = in_stock_filter.count()
            

            return JsonResponse({
                'message': 'success',
                'In Stock': instockls,
                'In Stock Total': totalintsock,
            })

        except json.JSONDecodeError:
            return JsonResponse({'message': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

    return JsonResponse({'error': 'Invalid request method.'}, status=405)

#1.1 FPO Inventory Out of Stock
@csrf_exempt
def FPOInventoryoutstock(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            filter_type = data.get('filter_type')
            required_fields=['userid', 'filter_type']
            for i  in required_fields:
                if not data.get(i):
                    return JsonResponse({'message': f'Missing{i} is required'}, status=400)
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)

            out_stock_filter = InventoryDetails.objects.filter(stock=0, fk_fpo=fpo)

            # Apply common formatting
            outtockls = format_inventory_details(out_stock_filter)

            # Get totals
            totaloutsock = out_stock_filter.count()

            return JsonResponse({
                'message': 'success',
                'Out of Stock': outtockls,
                'Out Stock Total': totaloutsock
            })

        except json.JSONDecodeError:
            return JsonResponse({'message': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

    return JsonResponse({'error': 'Invalid request method.'}, status=405)


##2.-----------------------------------Total Farmer and thier information
@csrf_exempt
def GetallFarmerbyFPO(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            if userid is None:
                return JsonResponse({'error': 'userid not provided'}, status=400)

            fpo_farmers = FarmerProfile.objects.filter(fpo_name_id=userid)
            if not fpo_farmers.exists():
                return JsonResponse({'message': 'FPO not found'}, status=404)
            farmers_data = []
            for farmer in fpo_farmers:
                farm_land = FarmerLandAddress.objects.filter(fk_farmer=farmer).first()
                farmers_data.append({
                    'farmer_id': farmer.id,
                    'farmer_name': farmer.name,
                    'farmer_mobile': farmer.mobile_no,
                    'farmer_district': farm_land.fk_district.district if farm_land and farm_land.fk_district else None
                })

            total_farmers = fpo_farmers.count()
            return JsonResponse({'message': 'success', 'data': farmers_data, 'total_farmers': total_farmers})
        else:
            return JsonResponse({'error': 'Invalid request method.'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e)}, status=500)
    
#3.Total Sales by FPO based on filtertype
@csrf_exempt
def GetTotalSalesByFPO(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('user_id')
            filter_type = data.get('filter_type')
            sales_status=data.get('sales_status')
            if userid is None:
                return JsonResponse({'error': 'userid or filter_type not provided'}, status=400)
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            sales=SalesRecordItem.objects.filter(fk_fpo=fpo,category=filter_type)
            sales_count = sales.count()
            total_sales_amount = sales.aggregate(total=models.Sum('total_amount'))['total'] or 0
            profit_sales=ProductPrices.objects.filter(fk_fpo=fpo,fk_product__fk_productype__product_type=filter_type,
                                                      fk_product__selling_status=sales_status)
            total_profit = sum(
                (ps.final_price_unit - ps.unit_price)
                for ps in profit_sales
            )
            return JsonResponse({
                'sales_count': sales_count,
                'total_sales_amount': total_sales_amount,
                'total_profit':total_profit
            }, status=200)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e)}, status=500)
    
#4.Get Total Profit based on filtertype
@csrf_exempt
def GetTotalSalesByFPOMonth(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            filter_type = data.get('filter_type')
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            sales = SalesRecordItem.objects.filter(fk_fpo=fpo,category=filter_type)
            sales_list = []
            for sale in sales:
                res = {
                    'sale_id': sale.id,
                    'total_amount': sale.total_amount,
                    'sales_date': sale.sales_date
                }
                sales_list.append(res)
            
            return JsonResponse({'sales': sales_list}, status=200)
        
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e)}, status=500)
    else:
        return JsonResponse({'message': 'Invalid request method'}, status=405)
#########################-----------------------------List all FPO Buyers who are farmers active,inactive,all--------------############
#5.Farmer who buys from FPO or not
@csrf_exempt
def CheckBuyerisFarmerorNot(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            filter_type = data.get('filter_type')
            if filter_type=="active":
                if not userid:
                    return JsonResponse({'message': 'User ID is required'}, status=400)
                try:
                    fpo = FPOProfile.objects.get(id=userid)
                except FPOProfile.DoesNotExist:
                    return JsonResponse({'message': 'FPO not found'}, status=404)
                farmers = FarmerProfile.objects.filter(fpo_name_id=fpo)
                mobile_no=farmers.values_list('mobile_no',flat=True)
                customers = CustomerDetails.objects.filter(fk_fpo=fpo, mobile_no__in=mobile_no)
                customers_count = customers.count()
                if not customers.exists():
                    return JsonResponse({'message': 'No farmers with matching mobile numbers found'}, status=404)
                return JsonResponse({'farmers': list(customers.values()),'count': customers_count}, status=200)
            elif filter_type=="all":
                try:
                    fpo = FPOProfile.objects.get(id=userid)
                except FPOProfile.DoesNotExist:
                    return JsonResponse({'message': 'FPO not found'}, status=404)
                customers = FarmerProfile.objects.filter(fpo_name=fpo)
                customers_count = customers.count()
                if not customers.exists():
                    return JsonResponse({'message': 'No Farmer details found'}, status=404)
                return JsonResponse({'customers':list(customers.values()),'count': customers_count}, status=200)
            elif filter_type=="inactive":
                if not userid:
                    return JsonResponse({'message': 'User ID is required'}, status=400)
                try:
                    fpo = FPOProfile.objects.get(id=userid)
                except FPOProfile.DoesNotExist:
                    return JsonResponse({'message': 'FPO not found'}, status=404)
                farmers = FarmerProfile.objects.filter(fpo_name=fpo)
                mobile_no=farmers.values_list('mobile_no',flat=True)
                customers = CustomerDetails.objects.filter(fk_fpo=fpo).exclude(mobile_no__in=mobile_no)
                customers_count = customers.count()
                if not customers.exists():
                    return JsonResponse({'message': 'No farmers with matching mobile numbers found'}, status=404)
                return JsonResponse({'farmers': list(customers.values()),'count': customers_count}, status=200)
        except json.JSONDecodeError:
            return JsonResponse({'message': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

    return JsonResponse({'message': 'Method not allowed'}, status=405)
           







@csrf_exempt
def CheckCustomerisFarmerornot(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            userid=data.get('userid')
            mobile_no=data.get('mobile_no')
            if userid is None:
                return JsonResponse({'error': 'userid or filter_type not provided'}, status=400)
            try:
                fpo = FPOProfile.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)
            try:
                farmer = FarmerProfile.objects.get(fpo_name=userid,mobile_no=mobile_no)
                return JsonResponse({'message': 'Farmer mobile number is associated with the FPO', 'associated': True}, status=200)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'message': 'Farmer mobile number is not associated with the FPO', 'associated': False}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)



