from .views import *
from .fpo import *
from .services import *
from .data import *
from .suppliers import *
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static


urlpatterns=[
    #################---------------------------------Cron Job For Sowing Date Increment-------------------------############

    path('Get_Users_Crops',Get_Users_Crops,name='Get_Users_Crops'),
    #####--------------------------------------Show All Farm by Info -------------------------###########
    path('GetFarmbyFarmer',GetFarmbyFarmer,name='GetFarmbyFarmer'),
    #####################################----------------------FARMER-------------------#################################
    ################-----------------------------Add Crop Variety----------------------------############
    path('AddCropVariety',AddCropVariety,name='AddCropVariety'),
    path('GetCropVariety',GetCropVariety,name='GetCropVariety'),
    ###----------------------------------------------------------------Farmer Login--------------#################
    path('Farmer_Login', Farmer_Login, name='Farmer_Login'),
    
    ####---------------------------------Get all Product Categories---------------###########
    path('getproduct_category', getproduct_category, name='Get_Product_Category'),
    
    ######--------------------------------Get all States---------------------#########
    path('getshops_states', getshops_states, name='getshops_states'),
    
    #######---------------------------------Get all Cities--------------------############
    path('getallcity', getallcity, name='Get_cty'),
    
    #####---------------------------------Get All Comments & Ratings on Shops-----------------#############
    path('Get_UserRatingOnShops', Get_UserRatingOnShops, name='Get_UserRatingOnShops'),
    
    ##################################----------------Show Ratings & Comments based on Shops--------------------##
    path('Show_UserRatingOnShops', Show_UserRatingOnShops, name='Show_UserRatingOnShops'),
    
    ###########################################-------------Get all community post list---------------#######
    path('Get_Community_Posts_List', Get_Community_Posts_List, name='Get_Community_Posts_List'),
    path('Get_All_Community_Posts',Get_All_Community_Posts,name='Get_All_Community_Posts'),
    
    ########------------------------------------------Farmer Logout--------------------------############
    path('Farmer_Logout', Farmer_Logout, name='Farmer_Logout'),
    path('Get_Initial_Screen_Crops', Get_Initial_Screen_Crops, name='Get_Initial_Screen_Crops'),
    path('Get_Season_List', Get_Season_List, name='Get_Season_List'),
    path('Get_Crops_Types_According_Season', Get_Crops_Types_According_Season, name='Get_Crops_Types_According_Season'),
    path('Get_Crop_According_Crop_Types', Get_Crop_According_Crop_Types, name='Get_Crop_According_Crop_Types'),
    path('AddFarmlandByFarmer',AddFarmlandByFarmer,name='AddFarmlandByFarmer'),
    path('GetSingleFarmDetails',GetSingleFarmDetails,name='GetSingleFarmDetails'),
    path('FarmerUpdte_Profile', FarmerUpdte_Profile, name='FarmerUpdte_Profile'),
    path('UpdateFarmLand',UpdateFarmLand,name='UpdateFarmLand'),
    path('GetFarmProfileDetails', GetFarmProfileDetails, name='GetFarmProfileDetails'),
    path('Detect_Disease', Detect_Disease, name='Detect_Disease'),
    path('GetDiseaseVideo',GetDiseaseVideo,name='GetDiseaseVideo'),
    path('GetDiseaseType',GetDiseaseType,name='GetDiseaseType'),
    path('GetDiagnosisReport', GetDiagnosisReport, name='GetDiagnosisReport'),
    path('GetSingleDiagnosisReport',GetSingleDiagnosisReport,name='GetSingleDiagnosisReport'),
    path('delete_report', delete_report, name='DeleteReport'),
    path('Add_Community_Post', Add_Community_Post, name='Add_Community_Post'),
    path('Comment_On_Post', Comment_On_Post, name='Comment_On_Post'),
    path('Reply_ON_Post_Comment', Reply_ON_Post_Comment, name='Reply_ON_Post_Comment'),
    
    ###############---------------------Show all Post Info----------------------###########
    path('Like_Post_By_User', Like_Post_By_User, name='Like_Post_By_User'),
    path('Service_Provider_List', Service_Provider_List, name='Service_Provider_List'),
    path('add_user_comment', add_user_comment, name="add_user_comment"),
    
    ################---------------Get All Products----------------------------###############
    path('Get_allProducts', Get_allProducts, name="Get_allProducts"),
    
    #########################------------Get all Services---------------#########
    path('GetallServices', GetallServices, name='GetallServices'),
    
    #####---------------------Add Fruts POP----------------------##########
    path('AddFruitsPOP',AddFruitsPOP,name='AddFruitsPOP'),
    
    ##############-----------------Dukan Filters Section------------------###########
    path('Filter_Dukan', Filter_Dukan, name='Filter_Dukan'),
    
    ########---------------------Show FPO Coins----------------------#########
    path('show_coinsfpo', show_coinsfpo, name="show_coinsfpo"),
    
    #######################------------FPO Reward Model------------------#########
    path('show_winners', show_winners, name="show_winners"),
    
    #########################-----------FPO Winners Based on Filter--------------########
    path('filterwinners', filterwinners, name="filterwinners"),
    
    ##############---------------------SHOW FPO INVENTORY-------------------------##########
    path('ShowInventory', ShowInventory, name='ShowInventory'),
    ################----------------------Update Inventory-------------------#########
    path('UpdateInventorybyFPO',UpdateInventorybyFPO,name='UpdateInventorybyFPO'),
    ###############--------------------------Shops Based on Products*******************#####
    path('GetSingleProductinfo', GetSingleProductinfo, name="GetSingleProductinfo"),
    path('Soil_Test_Shops', Soil_Test_Shops, name='Soil_Test_Shops'),
    path('Get_soil_test_plans', Get_soil_test_plans, name='Get_soil_test_plans'),
    path('get_all_shops', get_all_shops, name='get_all_shops'),
    path('get_single_shop', get_single_shop, name='get_single_shop'),
    
    path('Get_CategoryShops', Get_CategoryShops, name="Get_CategoryShops"),
    ###################--------------------------Get ALL Crops--------------------########

    ###-------GetProductCategoryWise-----
    path('GetProductCategoryWise', GetProductCategoryWise, name="GetProductCategoryWise"),
    
    ###########
    path('Dukan_all', Dukan_all, name='Dukan_all'),
    path('Fpo_Signup', Fpo_Signup, name='Fpo_Signup'),
    path('Fpo_Login', Fpo_Login, name='Fpo_Login'),
    path('Fpo_Logout', Fpo_Logout, name='Fpo_Logout'),
    path('forgot_sendotp', forgot_sendotp, name='forgot_sendotp'),
    path('verify_otp', verify_otp, name='verify_otp'),
    path('FPOreset_password', FPOreset_password, name='FPOreset_password'),
    
    path('FPO_profile_update', FPO_profile_update, name='FPO_profile_update'),
    path('FPOProfilePictureUpdate',FPOProfilePictureUpdate,name='FPOProfilePictureUpdate'),
    path('GetFPODetails', GetFPODetails, name='GetFPODetails'),
    path('Add_FarmerbyFpo', Add_FarmerbyFpo, name='Add_FarmerbyFpo'),
    path('Add_Farmer_Csv', Add_Farmer_Csv, name="Add_Farmer_Csv"),
    
    path('AddProductDetails_FPO', AddProductDetails_FPO, name='AddProductDetails_FPO'),
    path('GetFPOAllProducts',GetFPOAllProducts,name='GetFPOAllProducts'),
    path('GetCrops',GetCrops,name='GetCrops'),
    ###########################-----------FPO Home Dashboard-----------------------#########
    path('FPOInventoryinstock',FPOInventoryinstock,name='FPOInventoryinstock'),
    path('FPOInventoryoutstock',FPOInventoryoutstock,name='FPOInventoryoutstock'),
    path('GetallFarmerbyFPO',GetallFarmerbyFPO,name='GetallFarmerbyFPO'),
    path('GetTotalSalesByFPOMonth',GetTotalSalesByFPOMonth,name='GetTotalSalesByFPOMonth'),
    ############----------------------Get FPO Single Product Details----------------#########
    path('GetSingleProduct_FPODetails', GetSingleProduct_FPODetails, name='GetSingleProduct_FPODetails'),
    path('AddProductDetails_FPO_Csv', AddProductDetails_FPO_Csv, name='AddProductDetails_FPO_Csv'),
    path('UpdateProduct_DeatilsFPO', UpdateProduct_DeatilsFPO, name='UpdateProduct_DeatilsFPO'),
    path('GetFPOSuppliersInfo',GetFPOSuppliersInfo,name='GetFPOSuppliersInfo'),
    path('GetFPOProductDetails',GetFPOProductDetails,name='GetFPOProductDetails'),
    path('GetFPOPurchaseInfo',GetFPOPurchaseInfo,name='GetFPOPurchaseInfo'),
    ############################------------------Cultivation Tips----------------------###########
    path('CultivationTips', CultivationTips, name='CultivationTips'),
    path('StartSowing',StartSowing,name='StartSowing'),
    path('CompleteStage',CompleteStage,name='CompleteStage'),
    #################################----------------Govt Schemes------------------------##########
    path('GetallGovtSchemes',GetallGovtSchemes,name='GetallGovtSchemes'),
    path('GovtSchemesbyID',GovtSchemesbyID,name='GovtSchemesbyID'),
    path('GetCurrentNews',GetCurrentNews,name='GetCurrentNews'),
    ####################---------------------------------Fruits POP--------------------------#############
    path('GetFruitsPop',GetFruitsPop,name='GetFruitsPop'),
    path('CompleteFruitsStage',CompleteFruitsStage,name='CompleteFruitsStage'),
    path('FruitStagesHistory',FruitStagesHistory,name='FruitStagesHistory'),

    ###################-----------------------------Vegetable Pop--------------------------##############
    ###########################--------------------Disease Outbreak---------------#########
    path('DiseaseOutbreak',DiseaseOutbreak,name='DiseaseOutbreak'),
    path('AddState',AddState,name='AddState'),
    path('AddDistrict',AddDistrict,name='AddDistrict'),
    path('GetallStates',GetallStates,name='GetallStates'),
    path('GetStateWiseDistrict',GetStateWiseDistrict,name='GetStateWiseDistrict'),
    path('GetallDistricts',GetallDistricts,name='GetallDistricts'),
    path('FarmerFpoPart',FarmerFpoPart,name='FarmerFpoPart'),
    path('getscrapedata',getscrapedata,name='getscrapedata'),

    ############################----------------------------Sales by FPO---------------#######
    path('AddSalesbyFPO',AddSalesbyFPO,name='AddSalesbyFPO'),
    path('GetCustomerRecordSales',GetCustomerRecordSales,name='GetCustomerRecordSales'),
    path('GetTotalSalesByFPO',GetTotalSalesByFPO,name='GetTotalSalesByFPO'),
    #################################----------------------Salam Kisan API-------------------------################
    path('SendFarmerProfile',SendFarmerProfile,name='SendFarmerProfile'),
    #################################----------------------Fertilizer Calcualtion-------------------------################
    path('Fertilizerwithouttest',Fertilizerwithouttest,name='Fertilizerwithouttest'),
    path('AdvanceFertilizercalculator',AdvanceFertilizercalculator,name='AdvanceFertilizercalculator'),
    path('Fertilizerswithtest',Fertilizerswithtest,name='Fertilizerswithtest'),
    
    ########################-----------------------Vegetable POP----------------------#####################
    path('VegetableStages',VegetableStages,name = 'VegetableStages'),
    path('MarkVegetableStageComplete',MarkVegetableStageComplete,name = 'MarkVegetableStageComplete'),
    path('VegetableProgress',VegetableProgress,name='VegetableProgress'),
    #############################---------------------Spices POP-------------------------################
    path('AddSpicesPOP',AddSpicesPOP,name='AddSpicesPOP'),
    path('Spices_Stages',Spices_Stages,name='Spices_Stages'),
    path('ShowSpicesProductsBasedOnPrefrence',ShowSpicesProductsBasedOnPrefrence,name='ShowSpicesProductsBasedOnPrefrence'),
    path('MarkSpicesStageComplete',MarkSpicesStageComplete,name='MarkSpicesStageComplete'),
    ###############################--------------------CROP Suggestion----------------------##################
    path('AddSuggcropcsv',AddSuggcropcsv,name='AddSuggcropcsv'),
    path('Get_Suggested_Crops',Get_Suggested_Crops,name='Get_Suggested_Crops'),
    path('GetSuggested_Crop_Details',GetSuggested_Crop_Details,name='GetSuggested_Crop_Details'),
    ########################-----------------------Input Suppliers------------------################
    path('Supplier_Login',Supplier_Login,name='Supplier_Login'),
    path('Supplier_Logout',Supplier_Logout,name='Supplier_Logout'),
    path('GetSupplierProfileDetails',GetSupplierProfileDetails,name='GetSupplierProfileDetails'),
    path('Supplier_Profile_Update',Supplier_Profile_Update,name='Supplier_Profile_Update'),
    path('SupplierProfilePictureUpdate',SupplierProfilePictureUpdate,name='SupplierProfilePictureUpdate'),
    path('AddProductDetails_Suppliers',AddProductDetails_Suppliers,name='AddProductDetails_Suppliers'),
    path('UpdateProduct_DeatilsSuppliers',UpdateProduct_DeatilsSuppliers,name='UpdateProduct_DeatilsSuppliers'),
    path('GetSuppliersDetailsInfo',GetSuppliersDetailsInfo,name='GetSuppliersDetailsInfo'),
    path('ShowInventorySupplier',ShowInventorySupplier,name='ShowInventorySupplier'),
    path('UpdateInventorybySupplier',UpdateInventorybySupplier,name='UpdateInventorybySupplier'),
    path('AddSalesbySupplier',AddSalesbySupplier,name='AddSalesbySupplier'),
    path('GetSupplier_CustomerRecordSales',GetSupplier_CustomerRecordSales,name='GetSupplier_CustomerRecordSales'),
    path('GetThirdPartySupplier_AllProducts',GetThirdPartySupplier_AllProducts,name='GetThirdPartySupplier_AllProducts'),
    path('GetSingleProduct_SupplierDetails',GetSingleProduct_SupplierDetails,name='GetSingleProduct_SupplierDetails'),
    path('Supplier_Inventoryin_outstock',Supplier_Inventoryin_outstock,name='Supplier_Inventoryin_outstock'),
    path('GetTotalSalesBySuppliers',GetTotalSalesBySuppliers,name='GetTotalSalesBySuppliers'),
    path('CheckCustomerisFarmerornot',CheckCustomerisFarmerornot,name='CheckCustomerisFarmerornot'),
    path('CheckBuyerisFarmerorNot',CheckBuyerisFarmerorNot,name='CheckBuyerisFarmerorNot')
]

# urlpatterns = [*web_urls, *ajax_urls] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
