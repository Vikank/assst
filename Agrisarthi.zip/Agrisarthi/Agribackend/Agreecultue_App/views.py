
# Create your views here.
import  json
import traceback
from django.http import JsonResponse
from .models import *
from .scraper import *
from django.core.files.storage import default_storage
import calendar
from datetime import datetime, date
from .cron import *
from django.db import transaction
from django.shortcuts import get_object_or_404
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
import random
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.sessions.models import Session
from django.http import HttpResponse
from django.db.models import Q
import pandas as pd
from django.conf import settings
import xlrd
import requests
import string
import os
from urllib.parse import urlparse
from django.core.exceptions import ObjectDoesNotExist
from django.core.files.base import ContentFile
from transformers import pipeline
from PIL import Image
from django.core.mail import send_mail
# from newsapi import NewsApiClient
from django.core.exceptions import ValidationError
# from serpapi import BingSearch
base_url = "64.227.136.113:8090"
import ast
import logging
logger = logging.getLogger('Agreeculture_App')
#################################-----------------------Farmers--------------------------------------------###################

####################################------------------GET INITIAL CROPS SCREEN-----------------------------###########################
@csrf_exempt
def Get_Initial_Screen_Crops(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        crop_types = CropTypeMaster.objects.all()
        crop_data_by_type_and_season = {}

        for crop_type in crop_types:
            crops = CropMaster.objects.filter(
                fk_crop_type=crop_type, fk_language_id=data.get('user_language')
            ).values(
                'id', 'crop_name', 'fk_crop_type__id', 'fk_crop_type__fk_season__season', 'fk_crop_type__fk_season__id', 'crop_status'
            )

            for crop in crops:
                crop_type_name = crop_type.type
                season_name = crop['fk_crop_type__fk_season__season']
                season_id = crop['fk_crop_type__fk_season__id']

                crop_data = {
                    'id': crop['id'],
                    'status': crop['crop_status'],
                    'crop_name': crop['crop_name'],
                    'season_name': season_name,
                    'season_id': season_id
                }

                crop_images = CropImages.objects.filter(fk_cropmaster__id=crop['id']).values_list('crop_image', flat=True)
                crop_data['crop_images'] = [f"media/{image}" for image in crop_images]

                key = crop_type_name
                if key in crop_data_by_type_and_season:
                    crop_data_by_type_and_season[key].append(crop_data)
                else:
                    crop_data_by_type_and_season[key] = [crop_data]

        return JsonResponse(crop_data_by_type_and_season)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)
####################################--------------------------Get Disease Vdieo----------------------#############
@csrf_exempt
def GetDiseaseVideo(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            user_language=data['user_language']
            res=DiseaseVideo.objects.filter(fk_language_id=user_language)
            return JsonResponse({'message':'success','data':list(res.values())})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

###########-----------------------------------------Get Crops Season list*------------------#######################
@csrf_exempt
def Get_Season_List(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            obj = SeasonMaster.objects.filter(fk_language_id=data.get('user_language'))
            send_data = {'message': 'Season list', 'season_list': list(obj.values())}
            return JsonResponse(send_data)
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
###############################-------------------Show all Farms based on Farmers-------------------################
@csrf_exempt
def GetFarmbyFarmer(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            farmer_lands = FarmerLandAddress.objects.filter(fk_farmer_id=data.get('user_id'))
            res = []
            for land in farmer_lands:
                crop_images = CropImages.objects.filter(fk_cropmaster=land.fk_crops)
                image_urls = [image.crop_image.url for image in crop_images]
                data = {
                    'id': land.id,
                    'land_area': land.land_area,
                    'language':land.fk_language.id if land.fk_language else None,
                    'address': land.address,
                    'pincode': land.pincode,
                    'state': land.fk_state.state if land.fk_state else None,
                    'district': land.fk_district.district if land.fk_district else None,
                    'village': land.village,
                    'lat1': land.lat1,
                    'lat2': land.lat2,
                    'crop': land.fk_crops.crop_name if land.fk_crops else None,
                    'crop_id':land.fk_crops.id,
                    'crop_images': image_urls
                }
                res.append(data)
            return JsonResponse({'data': res})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    

###---------------------------------GET CROP TYPE ACCORDING TO SEASON----------------------------#####################
@csrf_exempt
def Get_Crops_Types_According_Season(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            fk_season_id = data.get('fk_season_id')
            if fk_season_id is not None:
                if isinstance(fk_season_id, int): 
                    obj = CropTypeMaster.objects.filter(fk_season_id=fk_season_id,fk_language_id=data.get('user_language'))
                    crops_types_list = list(obj.values())
                    return JsonResponse({'message': "Crops Types list", 'crops_type': crops_types_list})
                else:
                    return JsonResponse({'error': 'Invalid data type for fk_season_id'}, status=400)
            else:
                return JsonResponse({'error': 'fk_season_id is missing'}, status=400)
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON format in request body'}, status=400)
    except CropTypeMaster.DoesNotExist:
        return JsonResponse({'error': 'No crop types found for the given season'}, status=404)
    except Exception :
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
###################----------------------------------Get Selected Crops After Initail Screen-------------#####################
@csrf_exempt
def Get_Crop_According_Crop_Types(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            crop_type_id_arr = data.get('crop_type_id_arr')
            base_url = settings.MEDIA_URL

            if crop_type_id_arr is not None and isinstance(crop_type_id_arr, list):
                dummy_list = []
                for crop_type_id in crop_type_id_arr:
                    crop_type_obj = CropTypeMaster.objects.filter(id=crop_type_id, fk_language_id=data.get('user_language')).first()
                    if crop_type_obj:
                        crop_master_objs = CropMaster.objects.filter(fk_crop_type_id=crop_type_obj.id, fk_language_id=data.get('user_language'))
                        crops_data = []

                        for crop in crop_master_objs:
                            crop_data = {
                                'id': crop.id,
                                'crop_name': crop.crop_name,
                                'status': crop.crop_status,
                            }

                            # Fetch crop images for the current crop
                            crop_images = CropImages.objects.filter(fk_cropmaster=crop).values_list('crop_image', flat=True)
                            crop_data['crop_images'] = [f"{base_url}{img}" for img in crop_images]

                            crops_data.append(crop_data)

                        dummy_list.append({crop_type_obj.type: crops_data})

                return JsonResponse({'message': 'Filtered Data', 'data': dummy_list})
            else:
                return JsonResponse({'error': 'Invalid or missing crop_type_id_arr'}, status=400)
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON format in request body'}, status=400)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

#####################################-----------------------------Get User Selected Crops------------------##################
@csrf_exempt
def Get_Users_Crops(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        user_id = data.get('user_id')

        if user_id is None:
            return JsonResponse({'status': 'error', 'msg': "User ID not provided"}, status=400)

        try:
            farmer_profile = FarmerProfile.objects.get(id=user_id)
        except FarmerProfile.DoesNotExist:
            return JsonResponse({'status': 'error', 'msg': "User not found"}, status=404)

        related_crops = farmer_profile.fk_crops.all()
        crops_data = list(related_crops.values())

        send_data = {'status': 'success', 'msg': "Get crops list", 'data': crops_data}
        return JsonResponse(send_data)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)
#######################-----------------------------------------Comment on Shop by Farmers-----------------------#########################
@csrf_exempt
def add_user_comment(request):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Only POST requests are allowed'}, status=405)

    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON data'}, status=400)

    shop_id = data.get('shop_id')
    user_id = data.get('user_id')
    comment = data.get('comment')

    if not user_id:
        return JsonResponse({'status': 'error', 'message': 'User ID is required'}, status=400)

    if not comment:
        return JsonResponse({'status': 'error', 'message': 'Comment text is required'}, status=400)

    if not shop_id:
        return JsonResponse({'status': 'error', 'message': 'Shop ID is required'}, status=400)

    try:
        user = FarmerProfile.objects.get(id=user_id)
        shop = SupplierDetails.objects.get(id=shop_id)
    except :
        return JsonResponse({'status': 'error', 'message': 'User or Shop not found'}, status=404)

    UserCommentOnShop.objects.create(fk_shop=shop, fk_user=user, comment=comment)
    return JsonResponse({'status': 'success', 'message': 'Comment added successfully'},status=200)


#################-----------------------------Get ALL Shops Information(Based on Type)-------------------------------###########################@csrf_exempt
@csrf_exempt
def get_all_shops(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            type_filter = data['type_filter']
            shops = SupplierDetails.objects.filter(provided_by=type_filter)
            send_data = {'status': 1, "data":list(shops.values())}
        else:
            send_data = {'status': 0, 'msg': "Request is not POST"}
    except Exception as e:
        send_data = {'status': 0, 'msg': "Something went wrong", 'error': traceback.format_exc()}
    return JsonResponse(send_data)


######################-----------------------------Get Filter Dukan based on type------------------------------##########################
@csrf_exempt
def Filter_Dukan(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            state = data.get('state')
            city = data.get('city')
            category = data.get('category')
            filter_params = {}

            if state:
                filter_params['state'] = state
            if city:
                filter_params['city'] = city
            if category:
                filter_params['products__Category'] = category
            shops = SupplierDetails.objects.filter(**filter_params).distinct()
            shop_data = []
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            state = data.get('state')
            city = data.get('city')
            category = data.get('category')
            filter_params = {}

            if state:
                filter_params['state'] = state
            if city:
                filter_params['city'] = city
            if category:
                filter_params['products__Category'] = category
            shops = SupplierDetails.objects.filter(**filter_params).distinct()
            shop_data = []
            for shop in shops:
                
                shop_info = {
                    'shopName': shop.shopName,
                    'shopImage': shop.shopimage.url if shop.shopimage else None,
                    'shopId': shop.id,
                    'shopImage': shop.shopimage.url if shop.shopimage else None,
                    'shopId': shop.id,
                }
                shop_data.append(shop_info)
            
            return JsonResponse({'shops': shop_data})
        
        else:
            return JsonResponse({'error': 'Only POST requests are allowed'}, status=405)
    
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)  
##########-----------------------------------------Get All Type OF Products--------------------###############
def getproduct_category(request):
    try:
        if request.method=="GET":
            categories=ProductDetails.objects.values_list('Category',flat=True).distinct()
            return JsonResponse({'status': "success", "data":list(categories)})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

#####-------------------------------------------Get All Types of States------------------------###################
def getshops_states(request):
    try:
        if request.method=="GET":
            categories=SupplierDetails.objects.values_list('state',flat=True).distinct()
            return JsonResponse({'status': "success", "data":list(categories)})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

#####----------------------------------------Get ALL City--------------------------------###################
def getallcity(request):
    try:
        if request.method=="GET":
            categories=SupplierDetails.objects.values_list('city',flat=True).distinct()
            return JsonResponse({'status': "success", "data":list(categories)})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
#######################---------------------------Get ALL Services--------------------------#####################
def GetallServices(request):
    try:
        if request.method=="GET":
            categories=SupplierDetails.objects.values_list('provided_by',flat=True).distinct()
            return JsonResponse({'status': "success", "services":list(categories)})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
#################----------------------------------Get all Products-----------------------------#####################
@csrf_exempt
def Get_allProducts(request):
    try:
        if request.method == 'POST':
            products = ProductDetails.objects.all()
            return JsonResponse({'message': 'Data successful', 'products': list(products.values())}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except ProductDetails.DoesNotExist:
        return JsonResponse({'message': 'Table does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
######################-----------------------------Get Single Shop Information-------------------------------########################
@csrf_exempt
def get_single_shop(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            shop_id = data['shop_id']
            
            # Fetch the shop details
            shop = SupplierDetails.objects.prefetch_related('products').filter(id=shop_id).first()
            
            if not shop:
                return JsonResponse({'status': 'error', 'message': 'Shop not found'})
            
            # Fetch associated products
            products = shop.products.all()

            # Prepare shop details
            shop_details = {
                'id': shop.id,
                'shopName': shop.shopName,
                'shopContactNo': shop.shopContactNo,
                'suppliarLocation': shop.shopaddress,
                'state': shop.state,
                'village': shop.village,
                'city': shop.city,
                'shopLatitude': shop.shopLatitude,
                'shopLongitude': shop.shopLongitude,
                'productDealsIn': shop.productDealsIn,
                'Tehsil': shop.Tehsil,
                'shop_opentime': shop.shop_opentime,
                'shop_closetime': shop.shop_closetime,
                'shop_opendays': shop.shop_opendays,
                'shop_closedon': shop.shop_closedon,
                'shopimage': shop.shopimage.url if shop.shopimage else None,
                'no_of_ratings': shop.no_of_ratings,
                'provided_by': shop.provided_by,
                'partnerservice': shop.partnerservice.id if shop.partnerservice else None,
                'fpo_name': shop.fpo_name.id if shop.fpo_name else None,
            }

            # Prepare product details
            product_list = []
            for product in products:
                product_details = {
                    'id': product.id,
                    'productName': product.productName,
                    'weight': product.weight,
                    'productDescription': product.productDescription,
                    'price': product.price,
                    'manufacturerName': product.manufacturerName,
                    'product_image': product.product_image.url if product.product_image else None,
                    'measurement_type': product.measurement_type,
                    'sellby': product.sellby,
                    'quantity': product.quantity,
                    'pieces': product.pieces,
                    'weight_max': product.weight_max,
                    'weight_min': product.weight_min,
                    'shelf_life': product.shelf_life,
                    'storage_temp': product.storage_temp,
                    'storage_use': product.storage_use,
                    'countary_origin': product.countary_origin,
                    'sku_id': product.sku_id,
                    'Category': product.Category,
                    'fk_crop_type': product.fk_crop_type.id if product.fk_crop_type else None,
                }
                product_list.append(product_details)

            return JsonResponse({'status': 'success', 'shop': shop_details, 'products': product_list})

        else:
            return JsonResponse({'status': 'error', 'message': 'Only POST requests are allowed'})

    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

#######--------------------------------------Get Single Product Information with Shops-----------------#################
@csrf_exempt
def GetSingleProductinfo(request):
        if request.method=="POST":
            data=json.loads(request.body.decode('utf-8'))
            product_id=data.get('product_id')
            try:
                product = ProductDetails.objects.get(id=product_id)
                suppliers = product.fk_supplier.all()  
                product_data = {
                'id': product.id,
                'name': product.productName,
                'category': product.Category,
                'weight': float(product.weight) if product.weight else None,
                'description': product.productDescription,
                'price': float(product.price) if product.price else None,
                'manufacturer': product.manufacturerName,
                'image_url': product.product_image.url if product.product_image else None,
            }

                supplier_data = []
                for supplier in suppliers:
                    supplier_data.append({
                    "shop_id":supplier.id,
                    'shop_name': supplier.shopName,
                    'city': supplier.city,
                    'state': supplier.state,
                    })

                return JsonResponse({'product': product_data, 'suppliers': supplier_data})
            except ProductDetails.DoesNotExist:
                return JsonResponse({'error': 'Product ID does not exist'}, status=404)
        else:
            return JsonResponse({'error': 'Invalid request method'}, status=400)
            

################--------------------------------------------Get Dukaan All Info----------------------###################
@csrf_exempt
def Dukan_all(request):
    if request.method == 'GET':
        try:
            service_names = ['Soil Testing', 'Loan', 'Yojna']
            services = SupplierDetails.objects.filter(provided_by__in=service_names)
            shops = SupplierDetails.objects.filter(provided_by="Shops") 
            products = ProductDetails.objects.all()
            return JsonResponse({'services': list(services.values()), 'shops': list(shops.values()), 'products': list(products.values())})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)
################----------------------------------------Get All Shops (i.e Shops)----------------------------##################
@csrf_exempt
def Get_CategoryShops(request):
    try:
        if request.method == 'GET':
            shops = SupplierDetails.objects.filter(provided_by="Shops")
            return JsonResponse({'message': 'Data successful','shops': list(shops.values())}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except SupplierDetails.DoesNotExist:
        return JsonResponse({'message': 'Table does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
#####------------------------------------------POST User Rating On Shops--------------------##############

## Add Commnet & Rating On Shops
@csrf_exempt
def Get_UserRatingOnShops(request):
    try:
        if request.method=="POST":
            data=json.loads(request.body.decode('utf-8'))
            shop_id=data.get('shop_id')
            user_id=data.get('user_id')
            rating=data.get('rating')
            comment=data.get('comment')
            if not (shop_id and user_id and comment and rating):
                return JsonResponse({"error": "Incomplete data provided"}, status=400)
            comment = UserCommentOnShop.objects.create(
            fk_shop_id=shop_id,
            fk_user_id=user_id,
            comment=comment,
            rating=rating,
                            )
            return JsonResponse({"success": "Comment and rating added successfully"}, status=201)

        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
## Show Comment and Ratings based on Shop
@csrf_exempt
def Show_UserRatingOnShops(request):
    try:
        if request.method=="POST":
            data=json.loads(request.body.decode('utf-8'))
            shop_id=data.get('shop_id')
            comment=UserCommentOnShop.objects.filter(fk_shop_id=shop_id)
            comment_data=[]
            for i in comment:
                res={
                    "user_id":i.fk_user.id,
                    "shop_id":i.fk_shop.id,
                    "comment":i.comment,
                    "rating":i.rating

                }
                comment_data.append(res)
            return JsonResponse({'data': comment_data})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##########################------------------------------Community Section(Create Post)-----------------------------##########################
###--Add Post By User
@csrf_exempt
def Add_Community_Post(request):
    try:
        if request.method == "POST":
            user_id = request.POST.get('user_id')
            #fk_crop_id = request.POST.get('fk_crop_id')
            description = request.POST.get('description')
            video_file = request.FILES.get('video_file')
            image_file = request.FILES.get('image_file')
            user_type = request.POST.get('user_type')

            if not user_id or not description or not user_type:
                return JsonResponse({'status': 'error', 'msg': 'Missing required fields'}, status=400)

            if user_type == "farmer":
                user = FarmerProfile.objects.get(id=user_id)
                obj = CommunityPost.objects.create(fk_user=user,description=description, created_dt=datetime.datetime.now())
                if video_file:
                    PostsMedia.objects.create(fk_post=obj, video_file=video_file, image_file=image_file)
                coins = user
            elif user_type == "fpo":
                user = FPOProfile.objects.get(id=user_id)
                obj = CommunityPost.objects.create(fk_fpo=user, description=description, created_dt=datetime.datetime.now())
                if video_file:
                    PostsMedia.objects.create(fk_post=obj, video_file=video_file, image_file=image_file)
                coins = user
            else:
                return JsonResponse({'status': 'error', 'msg': 'Invalid user type'}, status=400)

            coins.add_coins(100)
            coins.save()
            return JsonResponse({'status': 'success', 'msg': 'Post Created Successfully'}, status=200)
        else:
            return JsonResponse({'status': 'error', 'msg': 'Request method not allowed'}, status=400)
    except FarmerProfile.DoesNotExist:
        return JsonResponse({'status': 'error', 'msg': 'FarmerProfile does not exist'}, status=404)
    except FPOProfile.DoesNotExist:
        return JsonResponse({'status': 'error', 'msg': 'FPOProfile does not exist'}, status=404)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
###############################----------------------------------Add Comment on Post----------------------#################################
@csrf_exempt
def Comment_On_Post(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            post_id = data.get('post_id')
            comment_text = data.get('comment_text')
            user_type = data.get('user_type')

            try:
                fk_post = CommunityPost.objects.get(id=post_id)
                print(fk_post)
            except CommunityPost.DoesNotExist:
                return JsonResponse({'status': 'error', 'msg': 'Community post does not exist'})

            try:
                if user_type == "farmer":
                    user = FarmerProfile.objects.get(id=user_id)
                    print(user)
                    comment = PostComments.objects.create(fk_user=user, fk_post=fk_post, text=comment_text, created_dt=datetime.datetime.now())
                elif user_type == "fpo":
                    user = FPOProfile.objects.get(id=user_id)
                    comment = PostComments.objects.create(fk_fpo=user, fk_post=fk_post, text=comment_text, created_dt=datetime.datetime.now())
                else:
                    return JsonResponse({'status': 'error', 'msg': 'Invalid user type'})
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'status': 'error', 'msg': 'Farmer profile does not exist'})
            except FPOProfile.DoesNotExist:
                return JsonResponse({'status': 'error', 'msg': 'FPO profile does not exist'})

            return JsonResponse({'status': 'success', 'msg': 'Comment Added Successfully'})
        else:
            return JsonResponse({'status': 'error', 'msg': 'Request is not POST'})
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
        
###########################----------------------------Reply On POST------------------------#################################
@csrf_exempt
def Reply_ON_Post_Comment(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            fk_postcoment_id = data.get('fk_postcoment_id')
            user_id = data.get('user_id')
            text = data.get('text')
            user_type = data.get('user_type')

            if not fk_postcoment_id or not user_id or not text or not user_type:
                return JsonResponse({'status': 'error', 'msg': 'Missing required fields'}, status=400)

            if user_type == "farmer":
                fk_user = FarmerProfile.objects.get(id=user_id)
                comment_reply=CommentReply.objects.create(fk_user=fk_user, text=text, created_dt=datetime.datetime.now())
            elif user_type == "fpo":
                fk_fpo = FPOProfile.objects.get(id=user_id)
                comment_reply=CommentReply.objects.create(fk_fpo=fk_fpo, text=text, created_dt=datetime.datetime.now())
            else:
                return JsonResponse({'status': 'error', 'msg': 'Invalid user type'}, status=400)

            return JsonResponse({'status': 'success', 'msg': 'Reply on comment successfully'}, status=200)
        else:
            return JsonResponse({'status': 'error', 'msg': 'Request method not allowed'}, status=400)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
###########################---------------------------Like Post By Differente uSers---------------######################
@csrf_exempt
def Like_Post_By_User(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            fk_post_id = data.get('fk_post_id')
            user_id = data.get('user_id')
            user_type = data.get('user_type')
            
            if not fk_post_id or not user_id or not user_type:
                return JsonResponse({'status': 0, 'msg': 'Missing required fields'})
            
            # Check if the post exists
            if not CommunityPost.objects.filter(id=fk_post_id).exists():
                return JsonResponse({'status': 0, 'msg': 'Post does not exist'})

            if user_type == "farmer":
                if FarmerProfile.objects.filter(id=user_id).exists():
                    post_like, created = PostsLike.objects.get_or_create(fk_post_id=fk_post_id, fk_user_id=user_id)
                    if not created:
                        post_like.like_count += 1
                    post_like.created_dt = datetime.now()
                    post_like.save()
                else:
                    return JsonResponse({'status': 0, 'msg': 'Farmer does not exist'})
            elif user_type == "fpo":
                if FPOProfile.objects.filter(id=user_id).exists():
                    post_like, created = PostsLike.objects.get_or_create(fk_post_id=fk_post_id, fk_fpo_id=user_id)
                    if not created:
                        post_like.like_count += 1
                    post_like.created_dt = datetime.now()
                    post_like.save()
                else:
                    return JsonResponse({'status': 0, 'msg': 'FPO does not exist'})
            else:
                return JsonResponse({'status': 0, 'msg': 'Invalid user type'})
            
            return JsonResponse({'status': 1, 'msg': 'Post liked successfully'})
        else:
            return JsonResponse({'status': 0, 'msg': 'Request method must be POST'})
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
#################################-------------------Get ALL Info about POST-------------------##################
@csrf_exempt
def Get_Community_Posts_List(request):
    try:
        if request.method == 'POST':
            final_list = []
            filter_type = request.POST.get('filter_type')
            user_id = request.POST.get('user_id')  # Ensure user_id is obtained from the request

            if filter_type == 'farmer':
                obj = CommunityPost.objects.filter(fk_user__isnull=False)
            elif filter_type == 'fpo':
                obj = CommunityPost.objects.filter(fk_fpo__isnull=False)
            else:
                obj = CommunityPost.objects.all()

            for post in obj:
                post_img = PostsMedia.objects.filter(fk_post_id=post.id).first()
                like_objects = PostsLike.objects.filter(fk_post_id=post.id)
                is_liked = False
                if user_id:
                    is_liked = like_objects.filter(fk_user_id=user_id).exists()
                users_liked = [
                    {
                        'user_id': like.fk_user.id if like.fk_user else None,
                        'user_name': like.fk_user.name if like.fk_user else None,
                        'post_id':like.fk_post.id if like.fk_post else None
                    }
                    for like in like_objects
                ]

                final_dict = {
                    "user_name": post.fk_user.name if post.fk_user else '',
                    'user_id': post.fk_user.id if post.fk_user else '',
                    "post_id": post.id,
                    'profile_pic': post.fk_user.profile.url if post.fk_user and post.fk_user.profile else '',
                    'crop_name': post.fk_crop.crop_name if post.fk_crop else '',
                    'post_image': post_img.image_file.url if post_img and post_img.image_file else '',
                    'like_count': like_objects.count(),
                    'is_likedbysameuser': is_liked,
                    'users_liked': users_liked,  # Include list of users who liked the post
                    'description': post.description if post.description else '',
                    'created_dt': post.created_dt if post.created_dt else '',
                    'comment_list': []
                }

                comment_list = []
                comment_objects = PostComments.objects.filter(fk_post_id=post.id)
                for comment in comment_objects:
                    comment_dict = {
                        'user_name': comment.fk_user.name if comment.fk_user else '',
                        'user_id': comment.fk_user.id if comment.fk_user else '',
                        'profile_pic': comment.fk_user.profile.url if comment.fk_user and comment.fk_user.profile else '',
                        'id': comment.id if comment.id else '',
                        'post_comment': comment.text if comment.text else '',
                        'created_dt': comment.created_dt if comment.created_dt else '',
                        'reply_comments': []
                    }

                    reply_list = []
                    reply_objects = CommentReply.objects.filter(fk_postcomment_id=comment.id)
                    for reply in reply_objects:
                        reply_dict = {
                            'user_name': reply.fk_user.name if reply.fk_user else '',
                            'user_id': reply.fk_user.id if reply.fk_user else '',
                            'profile_pic': reply.fk_user.profile.url if reply.fk_user and reply.fk_user.profile else '',
                            'id': reply.id if reply.id else '',
                            'text': reply.text if reply.text else '',
                            'created_dt': reply.created_dt if reply.created_dt else '',
                        }
                        reply_list.append(reply_dict)

                    comment_dict['reply_comments'] = reply_list
                    comment_list.append(comment_dict)

                final_dict['comment_list'] = comment_list
                final_list.append(final_dict)

            return JsonResponse({'status': 'success', 'message': "Community post list", 'data': final_list})
        else:
            return JsonResponse({'status': 'error', 'message': "Request is not POST"}, status=400)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

######################################----------------------Get all USer Community-------------############
@csrf_exempt
def Get_All_Community_Posts(request):
    try:
        if request.method == 'GET':
            final_list = []
            posts = CommunityPost.objects.all()

            for post in posts:
                post_img = PostsMedia.objects.filter(fk_post_id=post.id).first()
                like_obj = PostsLike.objects.filter(fk_post_id=post.id)

                final_dict = {
                    "user_name": post.fk_user.name if post.fk_user else (post.fk_fpo.name if post.fk_fpo else ''),
                    'user_id': post.fk_user.id if post.fk_user else (post.fk_fpo.id if post.fk_fpo else ''),
                    "post_id": post.id,
                    'profile_pic': post.fk_user.profile.url if post.fk_user and post.fk_user.profile else (
                        post.fk_fpo.profile.url if post.fk_fpo and post.fk_fpo.profile else ''),
                    'post_image': post_img.image_file.url if post_img and post_img.image_file else (
                        post_img.video_file.url if post_img and post_img.video_file else ''),
                    'like_count': like_obj.count(),
                    'description': post.description if post.description else '',
                    'created_dt': post.created_dt if post.created_dt else '',
                    'comment_list': []
                }

                comment_list = []
                comment_objects = PostComments.objects.filter(fk_post_id=post.id)
                for comment in comment_objects:
                    comment_dict = {
                        'user_name': comment.fk_user.name if comment.fk_user else (comment.fk_fpo.name if comment.fk_fpo else ''),
                        'user_id': comment.fk_user.id if comment.fk_user else (comment.fk_fpo.id if comment.fk_fpo else ''),
                        'profile_pic': comment.fk_user.profile.url if comment.fk_user and comment.fk_user.profile else (
                            comment.fk_fpo.profile.url if comment.fk_fpo and comment.fk_fpo.profile else ''),
                        'id': comment.id if comment.id else '',
                        'post_comment': comment.text if comment.text else '',
                        'created_dt': comment.created_dt if comment.created_dt else '',
                        'reply_comments': []
                    }

                    reply_list = []
                    reply_objects = CommentReply.objects.filter(fk_postcomment_id=comment.id)
                    for reply in reply_objects:
                        reply_dict = {
                            'user_name': reply.fk_user.name if reply.fk_user else (reply.fk_fpo.name if reply.fk_fpo else ''),
                            'user_id': reply.fk_user.id if reply.fk_user else (reply.fk_fpo.id if reply.fk_fpo else ''),
                            'profile_pic': reply.fk_user.profile.url if reply.fk_user and reply.fk_user.profile else (
                                reply.fk_fpo.profile.url if reply.fk_fpo and reply.fk_fpo.profile else ''),
                            'id': reply.id if reply.id else '',
                            'text': reply.text if reply.text else '',
                            'created_dt': reply.created_dt if reply.created_dt else '',
                        }
                        reply_list.append(reply_dict)

                    comment_dict['reply_comments'] = reply_list
                    comment_list.append(comment_dict)

                final_dict['comment_list'] = comment_list
                final_list.append(final_dict)

            return JsonResponse({'status': 'success', 'message': "Community post list", 'data': final_list})
        else:
            return JsonResponse({'status': 'error', 'message': "Request method not allowed"}, status=400)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
#################--------------------------------------------Service Providers-----------------------------########################
@csrf_exempt
def Service_Provider_List(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            user_language=data.get('user_language')
            obj = Service_Provider.objects.filter(fk_language_id=user_language)
            return JsonResponse({'status': 'success', 'data': list(obj.values())})
        else:
            return JsonResponse({'status': 'error', 'message': 'Only POST requests are allowed'})
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
####---------------------------------------------Soil Testing Shops List-----------------------###################
@csrf_exempt
def Soil_Test_Shops(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            service_providerid = data['service_providerid']
            service_providerid = data['service_providerid']
            shops_data = []
            soil_service_shops = SupplierDetails.objects.filter(partnerservice__id=service_providerid, provided_by="Soil Testing")
            for shop in soil_service_shops:
                shop_data = {
                    'shop_id': shop.id,
                    'shop_id': shop.id,
                    'shop_name': shop.shopName,
                    'shop_contact_no': shop.shopContactNo,
                    'location': shop.suppliarLocation,
                }
                shops_data.append(shop_data)

            return JsonResponse({'status': 'success', 'shops': shops_data})
        else:
            return JsonResponse({'status': 'error', 'message': 'Only POST requests are allowed'})
    except Service_Provider.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Service provider not found'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})
########################--------------------------------Soil Testing Plans------------------------##################
@csrf_exempt
def Get_soil_test_plans(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            shop_id=data['shop_id']
            soil_test_plans = SoilCharges.objects.filter(fk_shop_id=shop_id)
            plans_data = []
            for plan in soil_test_plans:
                plan_data = {
                    'price': plan.price,
                    'plan': plan.plans,
                    'details': plan.details,
                    'description':plan.description,
                }
                plans_data.append(plan_data)

            shop = SupplierDetails.objects.get(id=shop_id)
            shop_data = {
                'shop_name': shop.shopName,
                'shop_contact_no': shop.shopContactNo,
                'location': shop.suppliarLocation,
            }

            return JsonResponse({'status': 'success', 'shop': shop_data, 'soil_test_plans': plans_data})
        else:
            return JsonResponse({'status': 'error', 'message': 'Only POST requests are allowed'})
    except SupplierDetails.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Shop not found'})
    except SoilCharges.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Soil test plans not found for the shop'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})
    

#########---------------------------------------------Disease Detection----------------------------------- ###################
def process_image(image, model_name):
    pipe = pipeline("image-classification", model=model_name, device='cpu')
    predictions = pipe(image)
    max_prediction = max(predictions, key=lambda x: x['score'])
    disease_name = max_prediction['label']
    return disease_name, predictions

@csrf_exempt
def GetDiseaseType(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            user_language=data.get('user_language')
            obj=DiseaseTypeSelector.objects.filter(fk_language_id=user_language)
            return JsonResponse({'message':'success','data':list(obj.values())})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)

@csrf_exempt
def Detect_Disease(request):
    try:
        if request.method == 'POST':
            service_provider_id = request.POST.get('service_provider_id')
            crop_id = request.POST.get('crop_id')
            filter_type = request.POST.get('filter_type')
            image = request.FILES.get('image')
            user_language = request.POST.get('user_language')
            farmer_land_id = request.POST.get('farmer_land_id')
            fk_userid = request.POST.get('fk_userid')
            fk_farm_id = None
            state = None
            district = None
            if farmer_land_id:
                try:
                    farm = FarmerLandAddress.objects.get(id=farmer_land_id, fk_farmer_id=fk_userid, fk_crops__id=crop_id)
                    fk_farm_id = farm.id
                    state = farm.fk_state.state if farm.fk_state else None
                    district = farm.fk_district.district if farm.fk_district else None
                except FarmerLandAddress.DoesNotExist:
                    return JsonResponse({'error': 'Invalid farmer land ID'}, status=404)

            related_crop_ids = {
                '4': ['4', '72'],
                '72': ['4', '72'],
                '5': ['5', '73'],
                '73': ['5', '73'],
            }
            if filter_type.lower() == 'leaf' or filter_type.lower() == 'leaves':
                if crop_id in related_crop_ids['4']:
                    model_name = "Amanaccessassist/finetuner-potato-leaf"
                elif crop_id in related_crop_ids['5']:
                    model_name = "Amanaccessassist/finetune-mango-leaf"
                else:
                    return JsonResponse({'error': 'Invalid crop ID'}, status=400)
            elif filter_type.lower() == 'finished product':
                if crop_id in related_crop_ids['4']:
                    model_name = "Amanaccessassist/finetuned-potato-chips"
                else:
                    return JsonResponse({'error': 'Invalid crop ID'}, status=400)
            elif filter_type.lower() == 'crop':
                if crop_id in related_crop_ids['4']:
                    model_name = "Amanaccessassist/finetuned-potato-food"
                elif crop_id in related_crop_ids['5']:
                    model_name = "Amanaccessassist/finetuned-mango-food"
                else:
                    return JsonResponse({'error': 'Invalid crop ID'}, status=400)
            else:
                return JsonResponse({'error': 'Invalid filter type'}, status=400)

            pil_image = Image.open(image)
            disease_name, disease_images = process_image(pil_image, model_name)

            if user_language == '1':
                obj = DiseaseMaster.objects.filter(name=disease_name, fk_crops__id__in=related_crop_ids[crop_id], fk_language_id=user_language).first()
            else:
                try:
                    language = LanguageSelection.objects.get(id=user_language)
                    disease_translations = DiseaseTranslation.objects.filter(
                        fk_disease__name=disease_name,
                        fk_language=language,
                    )
                    if disease_translations.exists():
                        disease_translation = disease_translations.first()
                        disease_name = disease_translation.translation
                        obj = DiseaseMaster.objects.filter(name=disease_name, fk_crops__id__in=related_crop_ids[crop_id]).first()
                    else:
                        return JsonResponse({'error': f'Disease translation not found for language {user_language}'}, status=404)
                except LanguageSelection.DoesNotExist:
                    return JsonResponse({'error': 'Invalid language ID'}, status=400)

            if not obj:
                return JsonResponse({'error': 'Disease not found in database'}, status=404)

            disease_images = list(Disease_Images_Master.objects.filter(fk_disease__id=obj.id).values())
            disease_results = []

            try:
                coins = FarmerProfile.objects.get(id=fk_userid)
                coins.add_coins(90)
                coins.save()
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'error': 'User not found'}, status=404)

            upload_disease = Upload_Disease.objects.create(
                fk_provider_id=service_provider_id,
                fk_crop_id=crop_id,
                fk_disease=obj,
                uploaded_image=image,
                fk_User_id=fk_userid,
                filter_type=filter_type,
                created_dt=datetime.now(),
                fk_farmer_land_id=fk_farm_id,
                state=state,
                district=district,
                fk_language_id=user_language
            )
            uploaded_image_data = {
                'id': None,
                'disease_file': upload_disease.uploaded_image.url if upload_disease.uploaded_image else None,
            }
            product_disease = DiseaseProductInfo.objects.filter(fk_disease__name=disease_name, fk_crop_id__in=related_crop_ids[crop_id])
            product_disease_results = []
            for i in product_disease:
                res = {
                    'productid': i.fk_product.id,
                    'productimage': i.fk_product.product_image.url if i.fk_product else None,
                    'productname': i.fk_product.productName if i.fk_product else None,
                    'price': i.fk_product.price if i.fk_product else None,
                    'category': i.fk_product.Category if i.fk_product else None
                }
                product_disease_results.append(res)
            disease_images.append(uploaded_image_data)
            disease_results = {
                'disease_id':obj.id,
                'disease': obj.name,
                'crop_id':int(crop_id),
                'symptom': obj.symptom,
                'treatmentbefore': obj.treatmentbefore,
                'treatmentfield': obj.treatmentfield,
                'treatment': obj.treatment,
                'message':obj.message,
                'suggestiveproduct': obj.suggestiveproduct,
                'images': disease_images,
                'base_path': '/media/disease'
            }

            return JsonResponse({
                'disease_results': disease_results,
                'product_disease': product_disease_results

            })

        else:
            return JsonResponse({'error': 'Request method must be POST'}, status=400)

    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##########################---------------------------------Get Single Diagnosis Reprot------------------------###################
@csrf_exempt
def GetSingleDiagnosisReport(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            user_id = data['user_id']
            user_language = data['user_language']
            diag_id = data['diag_id']
            user_disease = Upload_Disease.objects.filter(id=diag_id, fk_User_id=user_id, fk_language_id=user_language)
            
            if not user_disease.exists():
                return JsonResponse({'status': 'error', 'message': 'Diagnosis report not found'}, status=404)
            first_disease = user_disease.first()
            disease = first_disease.fk_disease.name
            cropid = first_disease.fk_crop.id
            
            disease_results = []
            for plan in user_disease:
                plan_data = {
                    'id': plan.id,
                    'crop_id':plan.fk_crop.id if plan.fk_crop else None,
                    'disease': plan.fk_disease.name if plan.fk_disease else None,
                    'images': plan.uploaded_image.url if plan else None,
                    'treatmentbefore': plan.fk_disease.treatmentbefore if plan else None,
                    'treatmentfield': plan.fk_disease.treatmentfield if plan else None,
                    'treatment': plan.fk_disease.treatment if plan else None,
                    'symptom': plan.fk_disease.symptom if plan.fk_disease else None,
                    'suggestiveproduct':plan.fk_disease.suggestiveproduct if plan else None,
                    'Upload_Data': plan.created_dt,
                }
                disease_results.append(plan_data)
            
            product_disease = DiseaseProductInfo.objects.filter(fk_disease__name=disease, fk_crop_id=cropid)
            product_disease_results = []
            for i in product_disease:
                res = {
                    'productid': i.fk_product.id,
                    'productimage': i.fk_product.product_image.url if i.fk_product else None,
                    'productname': i.fk_product.productName if i.fk_product else None,
                    'price': i.fk_product.price if i.fk_product else None,
                    'category': i.fk_product.Category if i.fk_product else None
                }
                product_disease_results.append(res)
            
            return JsonResponse({'disease_results': disease_results, 'product_disease_results': product_disease_results})
        else:
            return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
###########-----------------------------------------------Get Diagnosis Report -----------------############
@csrf_exempt
def GetDiagnosisReport(request):
    try:
        if request.method =="POST":
            data = json.loads(request.body.decode('utf-8'))
            user_id=data['user_id']
            user_language=data['user_language']
            user_disease = Upload_Disease.objects.filter(fk_User_id=user_id,fk_language_id=user_language)
            disease_details = []
            for plan in user_disease:
                plan_data = {
                    'id':plan.id,
                    'crop_id':plan.fk_crop.id if plan.fk_crop else None,
                    'Service_Provider':plan.fk_provider.name if plan else None,
                    'disease': plan.fk_disease.name if plan.fk_disease else None,
                    'image': plan.uploaded_image.url if plan.uploaded_image else None,
                    'Upload_Data':plan.created_dt,
                }
                disease_details.append(plan_data)
            return JsonResponse({'status': 1, 'disease_details': disease_details})
        else:
            return JsonResponse({'status': 'error','message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
########################------------------------------Delete Diagnosis Report---------------------------#################
@csrf_exempt
def delete_report(request):
    try:
        if request.method =="POST":
            data = json.loads(request.body.decode('utf-8'))
            user_id=data['user_id']
            disease_id=data['disease_id']
            Upload_Disease.objects.filter(fk_User_id=user_id,id=disease_id).delete()
            return JsonResponse({'status': 1,'message': 'Disease deleted successfully'})
        else:
            return JsonResponse({'status': 'error','message': 'Method not allowed'}, status=405)
    except Upload_Disease.DoesNotExist:
        return JsonResponse({'status': 'error','message': 'Tabel not found'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
########################################-------------------Disease OutBreak------------#######################
@csrf_exempt
def DiseaseOutbreak(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            state=data.get('state')
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e: 
            return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)


#################--------------------------------Farmer Login & Logout-----------------------------###########
##1.Farmer LOgin
@csrf_exempt
def Farmer_Login(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            if 'mobile_no' not in data:
                return JsonResponse({'status': 'error', 'message': 'mobile_no key is missing'}, status=400)
            if 'user_language' not in data:
                return JsonResponse({'status': 'error', 'message': 'user_language key is missing'}, status=400)
            mobile_no = data.get('mobile_no')
            user_language = data.get('user_language')
            
            if 'farmer_id' in request.session:
                obj = FarmerProfile.objects.get(id=request.session['farmer_id'])
                if obj.mobile_no == mobile_no:
                    obj.fk_language_id = user_language  
                    obj.save()
                    return JsonResponse({
                        'message': 'User already logged in', 
                        'obj_id': obj.id, 
                        'user_exists': True
                    })

            obj = FarmerProfile.objects.filter(mobile_no=mobile_no).first()
            if obj:
                obj.fk_language_id = user_language 
                obj.save()
                request.session['farmer_id'] = obj.id
                return JsonResponse({
                    'message': 'User Logged in successfully', 
                    'obj_id': obj.id, 
                    'user_exists': True
                })
            else:
                obj = FarmerProfile.objects.create(mobile_no=mobile_no, fk_language_id=user_language)  
                request.session['farmer_id'] = obj.id
                return JsonResponse({
                    'message': 'User created and logged in successfully', 
                    'obj_id': obj.id, 
                    'user_exists':False
                })
        else:
            return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)

##2.Farmer Logout
@csrf_exempt
def Farmer_Logout(request):
    try:
        if request.method == "POST":
            if 'farmer_id' in request.session:
                del request.session['farmer_id']
                request.session.save()
                return JsonResponse({'message': 'User logged out successfully'})
            else:
                return JsonResponse({'message': 'User not logged in'})
        else:
            return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##########################------------------------------Add land By Farmer---------------------#####################
@csrf_exempt
def AddFarmlandByFarmer(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data['userid']
            farmer_profile = FarmerProfile.objects.get(id=userid)
            land_address = FarmerLandAddress(
                fk_farmer=farmer_profile,
                address=data.get('address', ''),
                pincode=data.get('pincode', ''),
                fk_state_id=data.get('state', None),
                fk_district_id=data.get('district', None),
                village=data.get('village', ''),
                fk_crops_id=data.get('crop_id',''),
                land_area=data.get('land_area', None),
                lat1=data.get('lat1', None),
                lat2=data.get('lat2', None)
            )
            land_address.save()

            return JsonResponse({'message': 'Farmer land address created successfully', 'land_id': land_address.id})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON format in request body'}, status=400)
    except KeyError as e:
        return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
    except FarmerProfile.DoesNotExist:
        return JsonResponse({'error': 'User does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

#######################################---------------GetSingleFarmDetails-------------------####################
@csrf_exempt
def GetSingleFarmDetails(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'msg': 'Invalid JSON'}, status=400)
        
        user_id = data.get('user_id')
        land_id = data.get('land_id')

        if not user_id:
            return JsonResponse({'status': 'error', 'msg': 'User ID is required'}, status=400)
        if not land_id:
            return JsonResponse({'status': 'error', 'msg': 'Land ID is required'}, status=400)

        try:
            farmer = FarmerProfile.objects.get(id=user_id)
        except FarmerProfile.DoesNotExist:
            return JsonResponse({'status': 'error', 'msg': 'Farmer profile does not exist'}, status=404)

        try:
            farm_land = FarmerLandAddress.objects.get(id=land_id, fk_farmer=farmer)
        except FarmerLandAddress.DoesNotExist:
            return JsonResponse({'status': 'error', 'msg': 'Farm land does not exist'}, status=404)

        farm_details = {
            'id': farm_land.id,
            'land_area': farm_land.land_area,
            'address': farm_land.address,
            'state':farm_land.fk_state.state if farm_land.fk_state else None,
            'district':farm_land.fk_district.district if farm_land.fk_district else None,
            'tehsil': farm_land.tehsil,
            'crop':farm_land.fk_crops.crop_name if farm_land.fk_crops else None,
        }

        return JsonResponse({'status': 'success', 'farm_details': farm_details})
    else:
        return JsonResponse({'status': 'error', 'msg': 'Invalid request method'}, status=405)

############################----------------------------Update Farmer Profile------------------------####################
@csrf_exempt
def FarmerUpdte_Profile(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data['userid']
            land_id=data['land_id']
            try:
                farmer_profile = FarmerProfile.objects.get(id=userid)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'message': 'Farmer not found'}, status=404)
            
            # Update FarmerProfile fields
            farmer_data = ['name', 'fk_language_id']
            for field in farmer_data:
                if field in data:
                    setattr(farmer_profile, field, data[field])
            
            # Update FarmerLandAddress fields
            land_data = ['land_area', 'address', 'fk_state_id', 'fk_district_id', 'village', 'fk_crops_id']
            farmer_land, created = FarmerLandAddress.objects.get_or_create(fk_farmer_id=userid,id=land_id)
            for field in land_data:
                if field in data:
                    setattr(farmer_land, field, data[field])
            
            # Save both models
            farmer_profile.save()
            farmer_land.save()
            
            return JsonResponse({'message': 'Farmer profile & Land updated successfully'})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON format in request body'}, status=400)
    except KeyError as e:
        return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
    except FarmerProfile.DoesNotExist:
        return JsonResponse({'error': 'User does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
############################----------------------------Update Farmer land Address-----------------------------#############
@csrf_exempt
def UpdateFarmLand(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            land_id = data['land_id']
            land_address = FarmerLandAddress.objects.get(id=land_id)
            if 'address' in data:
                land_address.address = data['address']
            if 'pincode' in data:
                land_address.pincode = data['pincode']
            if 'state' in data:
                land_address.fk_state_id = data['state']
            if 'district' in data:
                land_address.fk_district_id = data['district']
            if 'village' in data:
                land_address.village = data['village']
            if 'land_area' in data:
                land_address.land_area = data['land_area']
            if 'lat1' in data:
                land_address.lat1 = data['lat1']
            if 'lat2' in data:
                land_address.lat2 = data['lat2']
            if 'landcrop_id' in data:
                land_address.fk_crops_id = data['landcrop_id']
            land_address.save()
            return JsonResponse({'message': 'Farmer land address updated successfully'})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON format in request body'}, status=400)
    except KeyError as e:
        return JsonResponse({'error': f'Missing required field: {e}'}, status=400)
    except FarmerLandAddress.DoesNotExist:
        return JsonResponse({'error': 'Land address does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)

#############################---------------------------Get Farmer Details--------------------------######################
@csrf_exempt
def GetFarmProfileDetails(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            userid = data['userid']
            farmer_data=FarmerProfile.objects.filter(id=userid)
            return JsonResponse({"data":list(farmer_data.values())})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except FarmerProfile.DoesNotExist:
        return JsonResponse({'error': 'User does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##############-----------------------------------Part of an FPO or not-----------------------###########
@csrf_exempt
def FarmerFpoPart(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            userid=data.get('userid')
            farmer = FarmerProfile.objects.get(id=userid)
            fpo = farmer.fpo_name
            fpo_name = fpo.fpo_name if fpo else None
            return JsonResponse({'messgae':'success','Fpo Name':fpo_name})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

###############-------------------------------Get ALL States----------------############
@csrf_exempt
def GetallStates(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            user_language=data.get('user_language')
            data=StateMaster.objects.filter(fk_language_id=user_language)
            return JsonResponse({'success':'Ok','data':list(data.values())})
        else:
           return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

########################--------------------------Get all Districrs------------------------##########
@csrf_exempt
def GetallDistricts(request):
    try:
        if request.method=="GET":

            data=DistrictMaster.objects.all()
            return JsonResponse({'success':'Ok','data':list(data.values())})
        else:
           return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

################------------------------------Get State Wise District------------------#########
@csrf_exempt
def GetStateWiseDistrict(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            state=data.get('state')
            user_language=data.get('user_language')
            data=DistrictMaster.objects.filter(fk_state_id=state,fk_language_id=user_language)
            return JsonResponse({'success':'Ok','data':list(data.values())})
        else:
           return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)
    
###################-------------------------------------------Cultivation Tips as Per Sowing Date--------------------###################
@csrf_exempt
def CultivationTips(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
            sowing_date = data.get('sowing_date')
            farmer_id = data.get('farmer_id')
            crop_id = data.get('crop_id')
            user_language = data.get('user_language')
            
            if not sowing_date:
                return JsonResponse({'error': 'Sowing date is required'}, status=400)

            sowing_time, created = SowingTime.objects.update_or_create(
                fk_user_id=farmer_id,
                fk_crop_id=crop_id,
                defaults={'sowing_date': sowing_date}
            )

            days_since_sowing = sowing_time.get_days_since_sowing()
            
            if days_since_sowing < 0:  
                pre_sowing_stages = CropStages.objects.filter(
                    fk_language_id=user_language,
                    fk_crop=crop_id,
                    sow_period__isnull=True
                )
                stage_data = [
                    {
                        'stage_name': stage.stages,
                        'Stage description': stage.description,
                        'status': 'In Progress'
                    }
                    for stage in pre_sowing_stages
                ]
                response_data = {
                    'days_since_sowing': days_since_sowing,
                    'stages': stage_data,
                }
                return JsonResponse(response_data)

            sowing_progress, created = SowingProgress.objects.update_or_create(
                fk_sowing_time=sowing_time,
                day_count=days_since_sowing,
                defaults={'created_at': timezone.now()}
            )

            relevant_stages = []
            for stage in CropStages.objects.filter(fk_crop=crop_id, fk_language_id=user_language):
                sow_period = stage.sow_period
                if sow_period:
                    period_ranges = [list(map(int, period.strip('()').split('-'))) for period in sow_period.split(',')]
                    for start, end in period_ranges:
                        if start <= days_since_sowing <= end:
                            relevant_stages.append((stage, 'In Progress'))
                        elif days_since_sowing > end:
                            relevant_stages.append((stage, 'Completed'))
                        elif days_since_sowing < start:
                            relevant_stages.append((stage, 'Not Started'))
            
            sowing_progress.save()

            stage_data = []
            for stage, status in relevant_stages:
                stage_data.append({
                    'stage_name': stage.stages,
                    'description': stage.description,
                    'sow_period': stage.sow_period,
                    'status': status,
                })

            response_data = {
                'days_since_sowing': days_since_sowing,
                'stages': stage_data,
            }
            return JsonResponse(response_data)

        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

    return JsonResponse({'error': 'Invalid HTTP method'}, status=405)

            
#####################################--------------------------------Cultivation Tips with/without Land(Have Not Sown Yet)------------########
@csrf_exempt
def StartSowing(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
            farmer_id = data.get('farmer_id')
            crop_id = data.get('crop_id')
            user_language = data.get('user_language')
            start_sowing = data.get('start_sowing', False)
            farmer_land_id=data.get('farmer_land_id')
            if farmer_land_id:

                try:
                    farm = FarmerLandAddress.objects.get(id=farmer_land_id, fk_farmer_id=farmer_id,fk_crops_id=crop_id)
                    fk_farm_id = farm.id
                except FarmerLandAddress.DoesNotExist:
                    return JsonResponse({'error': 'Invalid farmer land ID'}, status=404)
            else:
                farm = None
                fk_farm_id = None 
            

            if start_sowing:
                pre_sowing_stages = VegetablePop.objects.filter(
                    fk_language_id=user_language,
                    fk_crop=crop_id,
                    sow_period__isnull=True
                )
                stage_data = [
                    {
                        'stage_name': stage.stages,
                        'description': stage.description,
                        'status': 'In Progress'
                    }
                    for stage in pre_sowing_stages
                ]

                sowing_date = timezone.now().date()
                sowing_time, created = SowingTime.objects.update_or_create(
                    fk_user_id=farmer_id,
                    fk_crop_id=crop_id,
                    fk_farm_id=fk_farm_id,
                    defaults={'sowing_date': sowing_date}
                )
                days_since_sowing = sowing_time.get_days_since_sowing()

                sowing_progress, created = SowingProgress.objects.update_or_create(
                    fk_user_id=farmer_id,
                    fk_farm_id=fk_farm_id,
                    fk_sowing_time=sowing_time,
                    fk_crop_id=crop_id,
                    stage=None,
                    defaults={'day_count': days_since_sowing, 'completed_at': timezone.now(), 'status': 'In Progress'}
                )

                response_data = {
                    'pre_sowing': True,
                    'stages': stage_data,
                    'days_since_sowing': days_since_sowing
                }
                return JsonResponse(response_data)
            else:
                sowing_date = timezone.now().date()
                sowing_time, created = SowingTime.objects.update_or_create(
                    fk_user_id=farmer_id,
                    fk_farm_id=fk_farm_id,
                    fk_crop_id=crop_id,
                    defaults={'sowing_date': sowing_date}
                )

                days_since_sowing = sowing_time.get_days_since_sowing()

                sowing_progress, created = SowingProgress.objects.update_or_create(
                    fk_user_id=farmer_id,
                    fk_farm_id=fk_farm_id,
                    fk_sowing_time=sowing_time,
                    fk_crop_id=crop_id,
                    stage=None,
                    defaults={'day_count': days_since_sowing, 'completed_at': timezone.now(), 'status': 'In Progress'}
                )

                response_data = {
                    'message': 'Sowing started.',
                    'days_since_sowing': days_since_sowing
                }
                return JsonResponse(response_data)

        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

    return JsonResponse({'error': 'Invalid HTTP method'}, status=405)
#####################################--------------------------------Cultivation Tips without holding any land (Mark the Stages as Completed)------------########
@csrf_exempt
def CompleteStage(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
            farmer_id = data.get('farmer_id')
            crop_id = data.get('crop_id')
            user_language = data.get('user_language')
            completed_stage_ids = data.get('completed_stage_ids', [])
            farmer_land_id = data.get('farmer_land_id')

            if farmer_land_id:
                try:
                    farm = FarmerLandAddress.objects.get(id=farmer_land_id, fk_farmer_id=farmer_id, fk_crops_id=crop_id)
                    fk_farm_id = farm.id
                except FarmerLandAddress.DoesNotExist:
                    return JsonResponse({'error': 'Invalid farmer land ID'}, status=404)
            else:
                fk_farm_id = None

            if not completed_stage_ids:
                return JsonResponse({'error': 'Completed stage IDs are required'}, status=400)

            sowing_time = SowingTime.objects.filter(fk_user_id=farmer_id, fk_crop_id=crop_id).first()
            if not sowing_time:
                return JsonResponse({'error': 'Sowing time not found for this farmer and crop'}, status=404)

            previous_stage = SowingProgress.objects.filter(
                fk_sowing_time=sowing_time,
                fk_user_id=farmer_id,
                fk_farm_id=fk_farm_id,
                fk_crop_id=crop_id
            ).order_by('-completed_at').first()

            if previous_stage:
                previous_stage_completion_time = previous_stage.completed_at
            else:
                previous_stage_completion_time = sowing_time.sowing_date

            total_days_taken = sum(
                StageCompletionInfo.objects.filter(
                    fk_sowing_progress__fk_sowing_time=sowing_time,
                    fk_user_id=farmer_id,
                    fk_farm_id=fk_farm_id
                ).values_list('total_days_taken', flat=True)
            ) or 0

            stage_data = []

            for completed_stage_id in completed_stage_ids:
                completed_stage_obj = VegetablePop.objects.filter(
                    fk_crop=crop_id,
                    fk_language_id=user_language,
                    id=completed_stage_id
                ).first()

                if not completed_stage_obj:
                    return JsonResponse({'error': f'Completed stage with ID {completed_stage_id} not found'}, status=404)

                # Calculate the completion days for this stage
                completion_days = (timezone.now().date() - previous_stage_completion_time.date()).days

                # Calculate delay based on sowing period
                stage_delay = 0
                if completed_stage_obj.sow_period:
                    sow_period_ranges = [list(map(int, period.strip('()').split('-'))) for period in completed_stage_obj.sow_period.split(',')]
                    for start, end in sow_period_ranges:
                        if total_days_taken >= start:
                            if total_days_taken <= end:
                                break
                            else:
                                stage_delay = total_days_taken - end

                # Update the total days taken
                total_days_taken += completion_days

                # Mark the completed stage as completed
                sowing_progress, created = SowingProgress.objects.update_or_create(
                    fk_user_id=farmer_id,
                    fk_farm_id=fk_farm_id,
                    fk_crop_id=crop_id,
                    fk_sowing_time=sowing_time,
                    stage=completed_stage_obj,
                    defaults={
                        'completed_at': timezone.now(),
                        'status': 'Completed',
                        'stage_start_date': previous_stage_completion_time.date(),
                        'stage_end_date': timezone.now().date(),
                        'day_count': completion_days,
                        'delay_days': stage_delay
                    }
                )

                # Create a StageCompletionInfo record
                StageCompletionInfo.objects.update_or_create(
                    fk_user_id=farmer_id,
                    fk_farm_id=fk_farm_id,
                    fk_sowing_progress=sowing_progress,
                    days_taken=completion_days,
                    total_days_taken=total_days_taken,
                    fk_crop_id=crop_id,
                    stage_start_date=previous_stage_completion_time.date(),
                    stage_end_date=timezone.now().date(),
                    delay_days=stage_delay
                )

                stage_data.append({
                    'stage_id': completed_stage_obj.id,
                    'stage_name': completed_stage_obj.stages,
                    'description': completed_stage_obj.description,
                    'sow_period': completed_stage_obj.sow_period,
                    'status': 'Completed',
                    'days_taken': completion_days,
                    'stage_start_date': previous_stage_completion_time.date(),
                    'stage_end_date': timezone.now().date(),
                    'delay_days': stage_delay
                })

                # Update the previous stage completion time for the next iteration
                previous_stage_completion_time = timezone.now()

            relevant_stages = []
            next_stage_found = False
            for stage in VegetablePop.objects.filter(fk_crop=crop_id, fk_language_id=user_language):
                sow_period = stage.sow_period
                if sow_period:
                    period_ranges = [list(map(int, period.strip('()').split('-'))) for period in sow_period.split(',')]
                    for start, end in period_ranges:
                        if start <= total_days_taken <= end:
                            if stage.id in completed_stage_ids:
                                pass  # Stage already marked as completed
                            elif not next_stage_found:
                                relevant_stages.append((stage, 'In Progress'))
                                next_stage_found = True
                        elif total_days_taken > end:
                            relevant_stages.append((stage, 'Completed'))
                        elif total_days_taken < start and not next_stage_found:
                            relevant_stages.append((stage, 'Not Started'))

            for stage, status in relevant_stages:
                delay_days = 0
                if status == 'Completed' or status == 'In Progress':
                    sow_period = stage.sow_period
                    if sow_period:
                        period_ranges = [list(map(int, period.strip('()').split('-'))) for period in sow_period.split(',')]
                        for start, end in period_ranges:
                            if start <= total_days_taken <= end:
                                break
                            elif total_days_taken > end:
                                delay_days = total_days_taken - end

                stage_data.append({
                    'stage_id': stage.id,
                    'stage_name': stage.stages,
                    'description': stage.description,
                    'sow_period': stage.sow_period,
                    'status': status,
                    'days_taken': 0 if status == 'Not Started' else (total_days_taken if status == 'Completed' else total_days_taken - int(stage.sow_period.split('-')[0])),
                    'stage_start_date': None,
                    'stage_end_date': None,
                    'delay_days': delay_days
                })

            response_data = {
                'total_days_taken': total_days_taken,
                'stages': stage_data
            }

            return JsonResponse(response_data, status=200)

        except Exception as e:
            traceback.print_exc()
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request method'}, status=405)
###############################------------------------------Get All Govt Schemes--------------------------###################
@csrf_exempt
def GetallGovtSchemes(request):
    try:
        data = json.loads(request.body.decode('utf-8'))
        user_language = data.get('user_language', None)
        filter_type = data.get('filter_type', 'all')
        schemes = GovtSchemes.objects.all()
        if user_language:
            schemes = schemes.filter(fk_language_id=user_language)
        if filter_type == 'central':
            schemes = schemes.filter(scheme_by__in=['Central Schemes', 'केन्द्र सरकार की योजनाएं'])
        elif filter_type == 'state':
            schemes = schemes.filter(scheme_by__in=['State Schemes', 'राज्य सरकार की योजनाएं'])
        schemes_list = []
        for scheme in schemes:
            schemes_list.append({
                'scheme_id':scheme.id,
                'scheme_name': scheme.scheme_name,
                'details': scheme.details,
                'benefits': scheme.benefits,
                'eligibility': scheme.elgibility,
                'application_process': scheme.application_process,
                'document_require': scheme.document_require,
                'scheme_by': scheme.scheme_by,
                'ministry_name': scheme.ministry_name,
                'state': scheme.fk_state.state if scheme.fk_state else None,
                'applicationform_link': scheme.applicationform_link,
                'reference': scheme.reference,
                'scheme_image': scheme.scheme_image.url if scheme.scheme_image else None
            })

        return JsonResponse({'status': 'success', 'schemes': schemes_list})

    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)
    
@csrf_exempt
def GovtSchemesbyID(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            govt_schemes = GovtSchemes.objects.filter(id=data.get('govt_id'),fk_language_id=data.get('user_language'))
            serialized_schemes = []
            for scheme in govt_schemes:
                serialized_scheme = {
                    'scheme_name': scheme.scheme_name,
                    'details': scheme.details,
                    'benefits': scheme.benefits,
                    'eligibility': scheme.elgibility,
                    'application_process': scheme.application_process,
                    'document_require': scheme.document_require,
                    'applicationform_link':scheme.applicationform_link,
                    'reference':scheme.reference,
                    'image':scheme.scheme_image.url if scheme.scheme_image else None
                }

                # Append the serialized scheme to the list
                serialized_schemes.append(serialized_scheme)

            return JsonResponse({'message': 'Successful', 'schemes': serialized_schemes}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
       return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

    
##########################################--------------------------Get Current News----------------------############
@csrf_exempt
def GetCurrentNews(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            user_language = data.get('user_language', None)
            filter_type = data.get('filter_type', 'all')
            news = CurrentNews.objects.all()
            
            if user_language:
                news = news.filter(fk_language_id=user_language)
            if filter_type in ["ABPLIVE", "KRISHAKJAGAT", "KISANSAMADHAAN", "KRISHIJAGRAN", "KISANTAK"]:
                news = news.filter(source=filter_type)
            news = news.exclude(title__isnull=True).exclude(content__isnull=True).exclude(image__isnull=True)
            news = news.order_by('-created_at')
            response_data = []
            for article in news:
                if article.title and article.content:
                    response_data.append({
                        'news_id': article.id,
                        'title': article.title,
                        'content': article.content,
                        'image': article.image.url if article.image else None,
                        'news_type': article.related_post,
                        'source': article.source,
                        'link': article.link,
                        'created_at': article.created_at,
                        'language': article.fk_language.language if article.fk_language else None
                    })
            
            return JsonResponse({'status': 'success', 'articles': response_data})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)
###############################################------------Get Current News by Id--------------------##################
@csrf_exempt
def GetCurrentNewsbyId(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            obj=CurrentNews.objects.filter(id=data.get('news_id'))
            return JsonResponse({'success':'Data Shows Successfully','data':list(obj.values())})
        else:
             return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
       return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

###############################------------------------------Get All current News--------------------------###################    
@csrf_exempt
def getscrapedata(request):
    if request.method == "POST":
        try:
            posts = process_and_scrape_data()
            idx = 1

            excluded_images = [
                'https://kisansamadhan.com/wp-content/uploads/2023/06/kisan-samadhan-logo-head.webp',
                'https://akm-img-a-in.tosshub.com/lingo/ktak/resources/img/default-ktak.png?size=216:121',
                'https://secure.gravatar.com/avatar/1b22ba0618fdd77bbeece05657e46c52?s=25&d=https%3A%2F%2Fkisansamadhan.com%2Fwp-content%2Fuploads%2F2023%2F09%2Fkisan-samadhan-logo-150x150.webp&r=g',
                'https://cdn.abplive.com/imagebank/default_16x9.png'
            ]

            

            for article_data in posts:
                article_data['image'] = [img for img in article_data['image'] if img not in excluded_images]

                title = article_data.get('title', 'No Title')
                content = article_data.get('content', 'No Content')
                url = article_data.get('url', '')
                source = article_data.get('source', 'Unknown')
                images = article_data.get('image', [])
                related_post = article_data.get('data_type', 'Additional Info')
                language_code = article_data.get('language')  
                # Get or create the language object
                language_obj, created = LanguageSelection.objects.get_or_create(language=language_code)
                # Check for existing records
                existing_articles = CurrentNews.objects.filter(
                    title=title,
                    content=content,
                    link=url,
                    source=source,
                    related_post=related_post,
                    fk_language=language_obj
                )

                if existing_articles.exists():
                    article = existing_articles.first()
                    created = False
                else:
                    article = CurrentNews.objects.create(
                        title=title,
                        content=content,
                        link=url,
                        source=source,
                        related_post=related_post,
                        fk_language=language_obj
                    )
                    created = True

                for img_url in images:
                    try:
                        response = requests.get(img_url)
                        response.raise_for_status()
                        if response.headers['Content-Type'].startswith('image/'):
                            img_filename = f"{idx}.jpg"
                            img_path = os.path.join('article_images', img_filename)

                            article.image.save(img_path, ContentFile(response.content), save=True)
                            idx += 1
                        else:
                            logger.warning(f"Skipping non-image URL: {img_url}")
                    except requests.RequestException as e:
                        logger.error(f"Error downloading image from {img_url}: {str(e)}")
                    except Exception as e:
                        logger.error(f"Unexpected error when handling image {img_url}: {str(e)}")

            return JsonResponse({'message': 'Data scraped and saved successfully'}, status=200)
        except Exception as e:
            logger.error(f"An error occurred: {str(e)}", exc_info=True)
            return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
    else:
        return JsonResponse({'message': 'Method not allowed'}, status=405)

####################################---------------------------------Fertilizer Calculation Metrics------------------@##################

@csrf_exempt
def Fertilizerwithouttest(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            farm_id = data.get('farm_id')
            user_language = data.get('user_language')
            try:
                farmer_profile = FarmerProfile.objects.get(id=user_id,fk_language_id=user_language)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'error': 'FarmerProfile not found for user_id'}, status=404)
            try:
                farmer_land_address = FarmerLandAddress.objects.get(id = farm_id, fk_farmer_id=farmer_profile)
                state = farmer_land_address.fk_state
            except FarmerLandAddress.DoesNotExist:
                return JsonResponse({'error': 'FarmerLandAddress not found for farmer_id'}, status=404)
            fertilizers = Fertilizer.objects.filter(fk_state=state, fk_language=user_language).values('nitrogen', 'phosphorus', 'potassium')

            results = []
            for fertilizer in fertilizers:
                nitrogen = fertilizer['nitrogen']
                phosphorus = fertilizer['phosphorus']
                potassium = fertilizer['potassium']
                
                # Calculations for Urea
                kgha_n = round(nitrogen * 2.17)
                bag_n = round(kgha_n / 50)
                price_n = round(kgha_n * 5.31)

                # Calculations for Super Phosphate
                kgha_p = round(phosphorus * 6.25)
                bag_p = round(kgha_p / 50)
                price_p = round(kgha_p * 6)

                # Calculations for Potash
                kgha_k = round(potassium * 1.66)
                bag_k = round(kgha_k / 50)
                price_k = round(kgha_k * 12.04)

                results.append({
                    'Urea': {
                        'Kg/ha': kgha_n,
                        '(50 kg bag)': bag_n,
                        'Price (Rs)': price_n
                    },
                    'Super Phosphate': {
                        'Kg/ha': kgha_p,
                        '(50 kg bag)': bag_p,
                        'Price (Rs)': price_p
                    },
                    'Potash': {
                        'Kg/ha': kgha_k,
                        '(50 kg bag)': bag_k,
                        'Price (Rs)': price_k
                    }
                })

            return JsonResponse({'message': 'Successful', 'results': results}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

@csrf_exempt
def AdvanceFertilizercalculator(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            farm_id = data.get('farm_id')
            user_language = data.get('user_language'),
            daep=data.get('daep')
            complexes=data.get('complexes')
            urea=data.get('urea')
            ssp=data.get('ssp')
            mop=data.get('mop')
            try:
                farmer_profile = FarmerProfile.objects.get(id=userid,fk_language_id=user_language)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'error': 'FarmerProfile not found for user_id'}, status=404)
            try:
                farmer_land_address = FarmerLandAddress.objects.get(id = farm_id, fk_farmer_id=farmer_profile)
                state = farmer_land_address.fk_state
            except FarmerLandAddress.DoesNotExist:
                return JsonResponse({'error': 'FarmerLandAddress not found for farmer_id'}, status=404)
            fertilizers = Fertilizer.objects.filter(fk_state=state,fk_language=user_language).values('nitrogen', 'phosphorus', 'potassium')
            
            #DAEP Calculation -Nitrogen,Phosporous,Potassium
            results=[]
            total=[]
            finalres1=[]
            finalres2=[]
            finalres3=[]
            finalres4=[]
            daep_nitrogen = round(daep * 9)
            daep_phosporous = round(daep * 23)
            daep_potassium = round(daep * 0)

            #Complex 17:17:17 Calculation -Nitrogen,Phosporous,Potassium
            complex_nitrogen = round(complexes * 8.5)
            complex_phosporous = round(complexes * 8.5)
            complex_potassium = round(complexes * 8.5)

            # Urea Calculation -Nitrogen,Phosporous,Potassium
            urea_nitrogen = round(urea * 23)
            urea_phosporous = round(urea * 0)
            urea_potassium = round(urea * 0)
            # SSP Calculation -Nitrogen,Phosporous,Potassium
            ssp_nitrogen = round(ssp * 0)
            ssp_phosporous = round(ssp * 8)
            ssp_potassium = round(ssp * 0)
            # MOP Calculation -Nitrogen,Phosporous,Potassium
            mop_nitrogen = round(mop * 0)
            mop_phosporous = round(mop * 0)
            mop_potassium = round(mop * 30)

            ########Total N,P,k
            nitrogen=daep_nitrogen+complex_nitrogen+urea_nitrogen+ssp_nitrogen+mop_nitrogen
            phosporous=daep_phosporous+complex_phosporous+urea_phosporous+ssp_phosporous+mop_phosporous
            potassium=daep_potassium+complex_potassium+urea_potassium+ssp_potassium+mop_potassium
            for i in fertilizers:
                or_nitrogen = i['nitrogen']
                or_phosphorus = i['phosphorus']
                or_potassium = i['potassium']
                #####-------------Required Qunatity Of NPK
                reqnpk_nirotrgen=or_nitrogen-nitrogen
                reqnpk_phosphorous=or_phosphorus-phosporous
                reqnpk_potassium=or_potassium-potassium
                ######---------------Required Qunatity of Fertilizers
                req_ferti_N=round(reqnpk_nirotrgen*2.17)
                req_ferti_P=round(reqnpk_phosphorous*6.25)
                req_ferti_K=round(reqnpk_potassium*1.66)
                #########--------------Required Amount To Buy Things
                req_amount_N=round(req_ferti_N*5.31)
                req_amount_P=round(req_ferti_P*6)
                req_amount_K=round(req_ferti_K*12.04)

            total.append({
                'Total':{
                    'Total Nitrogen':nitrogen,
                    'Total Phosporosu':phosporous,
                    'Total Potassium':potassium
                }
            })
            finalres1.append({
                'Required qunatity of NPK(kg/ha)':{
                    'Required Nitrogen':reqnpk_nirotrgen,
                    'Required Phosporous':reqnpk_phosphorous,
                    'Required Potassium':reqnpk_potassium
                }
                
            })
            finalres2.append({
                'Required quantitu of Fertilizers(kg/ha)':{
                    'Required Nitrogen':req_ferti_N,
                    'Required Phosporous':req_ferti_P,
                    'Required Potassium':req_ferti_K
                }
            })
            finalres3.append({
                'Amount Required to buy Fertilizers':{
                    'Amount N':req_amount_N,
                    'Amount P':req_amount_P,
                    'Amount K':req_amount_K
                }
            })
            finalres4.append({
                'Total Amount Required':req_amount_N+req_amount_P+req_amount_K
            })

            results.append({
                    'DAEP': {
                        'N': daep_nitrogen,
                        'P': daep_phosporous,
                        'K': daep_potassium
                    },
                    'Complex 17:17': {
                        'N': complex_nitrogen,
                        'P': complex_phosporous,
                        'K': complex_potassium
                    },
                    'Urea': {
                        'N': urea_nitrogen,
                        'P': urea_phosporous,
                        'K': urea_potassium
                    },
                    'SSP':{
                        'N': ssp_nitrogen,
                        'P': ssp_phosporous,
                        'K': ssp_potassium
                    },
                    'MOP':{
                        'N': mop_nitrogen,
                        'P': mop_phosporous,
                        'K': mop_potassium
                    }
                })

            return JsonResponse({'message': 'Successful', 'results': results,'total':total,'Required NPK':finalres1,
                                'Required Fertilizer':finalres2,'Required Amount':finalres3,
                                 'Total Amount Required':finalres4 }, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)
    
@csrf_exempt
def Fertilizerswithtest(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            userid=data.get('userid')
            user_language=data.get('user_language')
            farm_id=data.get('farm_id')
            nitrogen=data.get('nitrogen')
            phosporous=data.get('phosporous')
            potassium=data.get('potassium')
            try:
                farmer_profile = FarmerProfile.objects.get(id=userid,fk_language_id=user_language)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'error': 'FarmerProfile not found for user_id'}, status=404)
            try:
                farmer_land_address = FarmerLandAddress.objects.get(id = farm_id, fk_farmer_id=farmer_profile)
                state = farmer_land_address.fk_state
            except FarmerLandAddress.DoesNotExist:
                return JsonResponse({'error': 'FarmerLandAddress not found for farmer_id'}, status=404)
            npk=[]
            N = "Low" if nitrogen < 240 else "Medium" if 240 <= nitrogen <= 480 else "High"
            P="Low" if phosporous < 11 else "Medium" if 11 <= phosporous <= 22 else "High"
            K="Low" if potassium < 110 else "Medium" if 110 <= potassium <= 280 else "High"
            npk.append({
                'N':N,
                'P':P,
                'K':K
            })
            
            results=[]
                # Calculations for Urea
            kgha_n = round(nitrogen * 2.17)
            bag_n = round(kgha_n / 50)
            price_n = round(kgha_n * 5.31)
                # Calculations for Super Phosphate
            kgha_p = round(phosporous * 6.25)
            bag_p = round(kgha_p / 50)
            price_p = round(kgha_p * 6)
             # Calculations for Potash
            kgha_k = round(potassium * 1.66)
            bag_k = round(kgha_k / 50)
            price_k = round(kgha_k * 12.04)
            results.append({
                    'Urea': {
                        'Kg/ha': kgha_n,
                        '(50 kg bag)': bag_n,
                        'Price (Rs)': price_n
                    },
                    'Super Phosphate': {
                        'Kg/ha': kgha_p,
                        '(50 kg bag)': bag_p,
                        'Price (Rs)': price_p
                    },
                    'Potash': {
                        'Kg/ha': kgha_k,
                        '(50 kg bag)': bag_k,
                        'Price (Rs)': price_k
                    }
                })
            return JsonResponse({'NPK Status':npk,'results':results}, status=200)

        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)
    

#############################--------------------------Get Fruits POP based on User Currentv Month--------------------################

def month_to_number(month_name):
    return list(calendar.month_name).index(month_name)
@csrf_exempt
def GetFruitsPop(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            land_id = data.get('land_id')
            user_language = data.get('user_language')
            orchidtype = data.get('orchidtype')
            current_date = timezone.now().date()
            current_month = current_date.month
            try:
                land_address = FarmerLandAddress.objects.get(id=land_id, fk_farmer_id=user_id)
                crop_id = land_address.fk_crops_id
                farmer = land_address.fk_farmer_id
            except FarmerLandAddress.DoesNotExist:
                return JsonResponse({'error': 'Invalid land ID provided.'}, status=404)

            fruits_pop_data = FruitsPop.objects.filter(
                fk_crops_id=crop_id,
                fk_language_id=user_language,
                orchidtype=orchidtype,
                start_month__lte=current_month,
                end_month__gte=current_month,
                start_month__isnull=False,
                end_month__isnull=False
            )

            if fruits_pop_data.exists():
                response_data = {
                    'land_id': land_id,
                    'user_id': user_id,
                    'crops': []
                }

                for fruit_pop in fruits_pop_data:
                    completion, created = FruitsStageCompletion.objects.update_or_create(
                        fk_fruits=fruit_pop, 
                        fk_farmer_id=farmer,
                        fk_farmland_id=land_id
                    )

                    if created:
                        completion.start_date = current_date
                        completion.save()

                    start_month = month_to_number(fruit_pop.start_period)
                    end_month = month_to_number(fruit_pop.end_period)

                    current_year = current_date.year
                    start_date = date(current_year, start_month, 1)
                    end_date = date(current_year, end_month, calendar.monthrange(current_year, end_month)[1])

                    if end_month < start_month:
                        end_date = date(current_year + 1, end_month, calendar.monthrange(current_year + 1, end_month)[1])

                    total_days = (end_date - start_date).days

                    # Check if the stage is completed
                    is_completed = completion.completion_date is not None

                    # Calculate days completed and days left
                    if is_completed:
                        completion_date = completion.completion_date
                        days_completed = max(0, (completion_date - completion.start_date).days)
                        days_left = max(0, (end_date - completion_date).days)
                    else:
                        days_completed = max(0, (current_date - completion.start_date).days)
                        days_left = max(0, (end_date - current_date).days)

                    progress = min(100, max(0, int((days_completed / total_days) * 100)))

                    crop_data = {
                        'crop_name': fruit_pop.fk_crops.crop_name,
                        'stages_id': fruit_pop.id,
                        'stages': fruit_pop.stages,
                        'stage_name': fruit_pop.stage_name,
                        'stage_number': fruit_pop.stage_number,
                        'start_month': fruit_pop.start_month,
                        'end_month': fruit_pop.end_month,
                        'orchidtype': fruit_pop.orchidtype,
                        'description': fruit_pop.description,
                        'start': fruit_pop.start_period,
                        'end': fruit_pop.end_period,
                        'days_completed': days_completed,
                        'days_left': days_left,
                        'total_days': total_days,
                        'progress': progress,
                        'is_complete': is_completed,
                        'completion_date': completion.completion_date.isoformat() if completion.completion_date else None,
                        'delay_count': completion.delay_count
                    }
                    response_data['crops'].append(crop_data)

                return JsonResponse(response_data)
            else:
                return JsonResponse({'error': 'No fruits population data found for the given criteria.'}, status=404)

        except ValueError as ve:
            return JsonResponse({'error': 'Value error occurred', 'message': str(ve)}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request method.'}, status=405)

#################################--------------------------------Fruit Stage Completion------------------------#################
@csrf_exempt
def CompleteFruitsStage(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            stage_ids = data.get('stage_ids', [])
            is_complete = data.get('is_complete', True)
            task_image=data.get('task_image')

            if not user_id or not stage_ids:
                return JsonResponse({'error': 'User ID and stage IDs are required.'}, status=400)
            current_date = timezone.now().date()          
            completed_stages = []
            for stage_id in stage_ids:
                try:
                    fruit_pop = FruitsPop.objects.get(id=stage_id)
                    completion, created = FruitsStageCompletion.objects.get_or_create(
                        fk_fruits=fruit_pop,
                        fk_farmer_id=user_id,
                        fk_farmland_id=fruit_pop.fk_crops.farmerlandaddress_set.filter(fk_farmer_id=user_id).first().id,
                        submit_image=task_image
                    )
                    if is_complete and not fruit_pop.is_complete:
                        fruit_pop.is_complete = True
                        fruit_pop.save()
                        completion.completion_date = current_date
                        # Calculate delay
                        end_month = month_to_number(fruit_pop.end_period)
                        current_year = current_date.year
                        expected_end_date = date(current_year, end_month, calendar.monthrange(current_year, end_month)[1])
                        
                        # Adjust for cases where the end date might be in the next year
                        if end_month < month_to_number(fruit_pop.start_period):
                            expected_end_date = date(current_year + 1, end_month, calendar.monthrange(current_year + 1, end_month)[1])

                        if current_date > expected_end_date:
                            delay = (current_date - expected_end_date).days
                        else:
                            delay = 0

                        completion.days_completed = max(0, (current_date - completion.start_date).days)
                        completion.delay_count = delay
                        completion.save()

                        completed_stages.append({
                            'stage_id': stage_id,
                            'stage_name': fruit_pop.stage_name,
                            'completion_date': current_date.isoformat(),
                            'delay': delay,
                            'days_completed': completion.days_completed
                        })

                except FruitsPop.DoesNotExist:
                    return JsonResponse({'error': f'Invalid stage ID: {stage_id}'}, status=404)
                except Exception as e:
                    return JsonResponse({'error': f'Error processing stage ID {stage_id}: {str(e)}'}, status=500)

            return JsonResponse({
                'message': 'Stages marked as complete successfully.',
                'completed_stages': completed_stages
            })

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data.'}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request method.'}, status=405)
#############################-------------------------------Fruits Stages History-----------------#############
@csrf_exempt
def FruitStagesHistory(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            land_id = data.get('land_id')
            if not user_id or not land_id:
                return JsonResponse({'error': 'User ID and Land ID are required.'}, status=400)
            try:
                land_address = FarmerLandAddress.objects.get(id=land_id, fk_farmer_id=user_id)
            except FarmerLandAddress.DoesNotExist:
                return JsonResponse({'error': 'Invalid land ID provided.'}, status=404)
            completed_stages = FruitsStageCompletion.objects.filter(
                fk_farmer_id=user_id,
                fk_farmland_id=land_id,
                completion_date__isnull=False
            ).order_by('-completion_date')
            history_data = []
            for completion in completed_stages:
                fruit_pop = completion.fk_fruits
                start_date = completion.start_date
                completion_date = completion.completion_date
                
                # Calculate total days and days taken
                total_days = (date(start_date.year, fruit_pop.end_month, calendar.monthrange(start_date.year, fruit_pop.end_month)[1]) - 
                              date(start_date.year, fruit_pop.start_month, 1)).days
                days_taken = (completion_date - start_date).days

                stage_data = {
                    'stage_id': fruit_pop.id,
                    'crop_name': fruit_pop.fk_crops.crop_name,
                    'stage_name': fruit_pop.stage_name,
                    'stage_number': fruit_pop.stage_number,
                    'description': fruit_pop.description,
                    'start_month': fruit_pop.start_month,
                    'end_month': fruit_pop.end_month,
                    'orchidtype': fruit_pop.orchidtype,
                    'start_date': start_date.isoformat(),
                    'completion_date': completion_date.isoformat(),
                    'days_taken': days_taken,
                    'total_days': total_days,
                    'delay_count': completion.delay_count,
                    'on_time': days_taken <= total_days
                }
                history_data.append(stage_data)

            response_data = {
                'user_id': user_id,
                'land_id': land_id,
                'completed_stages_history': history_data
            }

            return JsonResponse(response_data)

        except ValueError as ve:
            return JsonResponse({'error': 'Value error occurred', 'message': str(ve)}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request method.'}, status=405)

#####################################----------------------------Fruits POP-------------------------##################
@csrf_exempt
def AddFruitsPOP(request):
    try:
        if request.method=="POST":
            user_language=request.POST.get('user_language')
            crop_id=request.POST.get('crop_id')
            state_id=request.POST.get('state_id')
            filter_id=request.POST.get('filter_id')
            excel_file = r'/home/AgreecultureUpdate/static/mangoe.xlsx'
            data_xl = pd.read_excel(excel_file,sheet_name='mangohi')
            for index, row in data_xl.iterrows():
                FruitsPop.objects.create(
                    fk_state_id=state_id,
                    fk_filter_id=filter_id,
                    fk_language_id=user_language,
                    fk_crops_id=crop_id,
                    stages=row['stages'],
                    stage_name=row['stage_name'],
                    stage_number=row['stage_number'],
                    start_period=row['start_period'],
                    end_period=row['end_period'],
                    start_month=row['start_month'],
                    end_month=row['end_month'],
                    description=row['description'],
                    orchidtype=row['orchidtype']
                )
            return JsonResponse({'success':'Data Uploaded Successfully'})
        else:
           return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

##################################-----------------------------Vegetables POPwithout sowing Date---------------------##########################
from django.utils import timezone
@csrf_exempt
def VegetableStages(request):
    try:
        if request.method == 'POST':
            user_id = request.POST.get('user_id')
            crop_id = request.POST.get('crop_id')
            user_language = request.POST.get('user_language')
            
            try:
                farmer = FarmerProfile.objects.get(id=user_id)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'message': 'Farmer Not Found'})

            veges = VegetablePop.objects.filter(
                fk_crop_id=crop_id,
                fk_language_id=user_language
            ).order_by("preference", "stage_number")

            today = timezone.now().date()
            stage_data = []

            previous_preference = None

            for vege in veges:
                # Ensure VegetableStageCompletion and VegetablePreferenceCompletion are updated correctly
                stage_completion, created = VegetableStageCompletion.objects.get_or_create(
                    vegetable_pop=vege,
                    fk_farmer_id=user_id,
                    defaults={'start_date': None},
                    stage_number=vege.stage_number
                )

                preference_completion, _ = VegetablePreferenceCompletion.objects.get_or_create(
                    fk_farmer_id=user_id,
                    fk_crop_id=crop_id,
                    preference_number=vege.preference,
                    fk_vegetablestage=vege
                )

                # Initialize start date for the first stage of this preference
                if stage_completion.start_date is None:
                    # Check if previous stage of the same preference is completed
                    if previous_preference != vege.preference:
                        stage_completion.start_date = today
                    else:
                        # Use completion date of previous stage as start date for the next stage
                        previous_stage_completion = VegetableStageCompletion.objects.get(
                            vegetable_pop__preference=vege.preference,
                            fk_farmer_id=user_id,
                            stage_number=vege.stage_number - 1
                        )
                        stage_completion.start_date = previous_stage_completion.completion_date

                    stage_completion.save()

                # Calculate progress for this preference
                total_stages = VegetablePop.objects.filter(
                    fk_crop_id=crop_id,
                    preference=vege.preference
                ).count()

                completed_stages = VegetableStageCompletion.objects.filter(
                    fk_farmer_id=user_id,
                    vegetable_pop__fk_crop_id=crop_id,
                    vegetable_pop__preference=vege.preference,
                    is_completed=True
                ).count()

                progress = int((completed_stages / total_stages) * 100) if total_stages > 0 else 0
                preference_completion.progress = progress
                preference_completion.save()

                # Check if all stages for this preference are completed
                if progress == 100 and not preference_completion.is_completed:
                    preference_completion.is_completed = True
                    preference_completion.completion_date = today
                    preference_completion.total_days = (today - preference_completion.start_date).days
                    preference_completion.save()

                # Add stage data to stage_data list
                stage_data.append({
                    'stage_id': vege.id,
                    'stages': vege.stages,
                    'stage_name': vege.stage_name,
                    'sow_period': vege.sow_period,
                    'description': vege.description,
                    'stage_number': vege.stage_number,
                    'preference': vege.preference,
                    'is_completed': stage_completion.is_completed,
                    'days_spent': stage_completion.total_days_spent,
                    'start_date': stage_completion.start_date
                })

                previous_preference = vege.preference

            return JsonResponse({'stages': stage_data})

    except Exception as e:
        return JsonResponse({'message': str(e)})
#####################-------------------------------------------------Mark Vegetable Stage as complete---------------################## 
@csrf_exempt
def MarkVegetableStageComplete(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        stage_ids_str = request.POST.get('stage_ids')
        try:
            stage_ids = list(map(int, stage_ids_str.split(',')))
        except ValueError:
            return JsonResponse({'message': 'Invalid stage_ids format'})
        try:
            farmer = FarmerProfile.objects.get(id=user_id)
        except FarmerProfile.DoesNotExist:
            return JsonResponse({'message': 'Farmer Not Found'})
        result = []
        for stage_id in stage_ids:
            try:
                completion_record = VegetableStageCompletion.objects.get(
                    fk_farmer=farmer,
                    vegetable_pop_id=stage_id
                )
                completion_record.completion_date = timezone.now().date()
                completion_record.is_completed = True
                completion_record.total_days_spent = (completion_record.completion_date - completion_record.start_date).days
                completion_record.save()

                # Update preference progress
                vegetable_pop = completion_record.vegetable_pop
                preference_completions = VegetablePreferenceCompletion.objects.filter(
                    fk_farmer=farmer,
                    fk_crop=vegetable_pop.fk_crop,
                    preference_number=vegetable_pop.preference
                )

                total_stages = VegetablePop.objects.filter(
                    fk_crop=vegetable_pop.fk_crop,
                    preference=vegetable_pop.preference
                ).count()

                completed_stages = VegetableStageCompletion.objects.filter(
                    fk_farmer=farmer,
                    vegetable_pop__fk_crop=vegetable_pop.fk_crop,
                    vegetable_pop__preference=vegetable_pop.preference,
                    is_completed=True
                ).count()

                progress = int((completed_stages / total_stages) * 100) if total_stages > 0 else 0

                for preference_completion in preference_completions:
                    preference_completion.progress = progress

                    if progress == 100 and not preference_completion.is_completed:
                        preference_completion.is_completed = True
                        preference_completion.completion_date = timezone.now().date()
                        preference_completion.total_days = (preference_completion.completion_date - preference_completion.start_date).days
                        preference_completion.save()

                        # Current preference is completed, initialize the next preference
                        next_preference = vegetable_pop.preference + 1
                        next_preference_completion = VegetablePreferenceCompletion.objects.filter(
                            fk_farmer=farmer,
                            fk_crop=vegetable_pop.fk_crop,
                            preference_number=next_preference
                        ).first()

                        if next_preference_completion and next_preference_completion.start_date is None:
                            next_preference_completion.start_date = timezone.now().date()
                            next_preference_completion.save()

                            # Initialize the first stage of the next preference
                            next_stage = VegetablePop.objects.filter(
                                fk_crop=vegetable_pop.fk_crop,
                                preference=next_preference
                            ).order_by('stage_number').first()

                            if next_stage:
                                next_stage_completion, _ = VegetableStageCompletion.objects.get_or_create(
                                    vegetable_pop=next_stage,
                                    fk_farmer=farmer,
                                    defaults={'start_date': timezone.now().date()}
                                )
                    
                    preference_completion.save()

                result.append({
                    'stage_id': completion_record.vegetable_pop.id,
                    'stage_number': completion_record.stage_number,
                    'days_to_complete': completion_record.total_days_spent,
                    'preference_number': vegetable_pop.preference,
                    'preference_progress': progress
                })

            except VegetableStageCompletion.DoesNotExist:
                # If the stage completion doesn't exist, skip it
                continue

        return JsonResponse({'completed_stages': result})

    return JsonResponse({'message': 'Invalid request method'})

##########################-------------------------------------PROGRES BAR Based on Stagename /Preference----------##########
@csrf_exempt
def VegetableProgress(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        preference_numbers_str = request.POST.get('preference_numbers')
        
        try:
            preference_numbers = list(map(int, preference_numbers_str.split(',')))
        except ValueError:
            return JsonResponse({'message': 'Invalid preference_numbers format'})

        try:
            farmer = FarmerProfile.objects.get(id=user_id)
        except FarmerProfile.DoesNotExist:
            return JsonResponse({'message': 'Farmer Not Found'})

        preference_progress = []

        for preference_number in preference_numbers:
            stages = VegetablePop.objects.filter(preference=preference_number)
            total_stages = stages.count()

            if total_stages == 0:
                continue  # Skip if there are no stages for this preference

            # Get completed stages for this farmer and preference
            completed_stages = VegetableStageCompletion.objects.filter(
                fk_farmer=farmer,
                vegetable_pop__preference=preference_number,
                is_completed=True
            ).count()

            # Calculate overall progress for this preference
            progress = int((completed_stages / total_stages) * 100) if total_stages > 0 else 0

            # Get any preference completion record (they should all have the same crop)
            preference_completion = VegetablePreferenceCompletion.objects.filter(
                fk_farmer=farmer,
                preference_number=preference_number
            ).first()

            if preference_completion:
                preference_progress.append({
                    'preference_number': preference_number,
                    'crop_id': preference_completion.fk_crop.id,
                    'crop_name': preference_completion.fk_crop.crop_name,
                    'progress': progress,
                    'is_completed': progress == 100,
                    'total_days': preference_completion.total_days if progress == 100 else 0
                })

        return JsonResponse({'preference_progress': preference_progress})

    return JsonResponse({'message': 'Invalid request method'})

#######################---------------------------------Crop Suggestion Based on Season------------###################
@csrf_exempt
def Get_Suggested_Crops(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body.decode('utf-8'))
            user_id = data.get('user_id')
            user_language = data.get('user_language')
            current_month = timezone.now().month
            try:
                farmer = FarmerProfile.objects.filter(id=user_id,fk_language_id=user_language)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'message': 'Farmer Not Found'})
            suggested_crops = SuggestedCrop.objects.filter(
                fk_language_id=user_language,
                start_month__lte=current_month,
                end_month__gte=current_month
            )
            crops_data = []
            for crop in suggested_crops:
                crops_data.append({
                    'crop_id': crop.fk_crop.id if crop.fk_crop else None,
                    'crop_name': crop.fk_crop.crop_name if crop.fk_crop else None,
                })
            return JsonResponse({'suggested_crops': crops_data})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)
##############################--------------------------Show Suggeste Crop-------------------###############
@csrf_exempt
def GetSuggested_Crop_Details(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_id=data.get('user_id')
            crop_id = data.get('crop_id')
            user_language=data.get('user_language')
            if not crop_id:
                return JsonResponse({'error': 'Crop ID is required'}, status=400)
            try:
                crop = CropMaster.objects.get(id=crop_id)
            except CropMaster.DoesNotExist:
                return JsonResponse({'error': 'Crop not found'}, status=404)
            try:
                farmer = FarmerProfile.objects.filter(id=user_id,fk_language_id=user_language)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'message': 'Farmer Not Found'})
            suggested_crop = SuggestedCrop.objects.filter(fk_crop=crop,fk_language_id=user_language).first()
            crop_data = {
                'crop_id': crop.id,
                'crop_name': crop.crop_name,
                'description': suggested_crop.description if suggested_crop else None,
                'season': suggested_crop.season if suggested_crop else None,
                'weather_temperature': suggested_crop.weather_temperature if suggested_crop else None,
                'cost_of_cultivation': suggested_crop.cost_of_cultivation if suggested_crop else None,
                'market_price': suggested_crop.market_price if suggested_crop else None,
                'production': suggested_crop.production if suggested_crop else None,
                'language': suggested_crop.fk_language.language if suggested_crop and suggested_crop.fk_language else None
            }

            return JsonResponse({'crop_details': crop_data})

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)

    return JsonResponse({'error': 'Invalid request method'}, status=405)

###########################--------------------------SPices POP--------------------------###################
@csrf_exempt
def Spices_Stages(request):
    try:
        if request.method == 'POST':
            user_id = request.POST.get('user_id')
            crop_id = request.POST.get('crop_id')
            filter_type = request.POST.get('filter_type')
            user_language = request.POST.get('user_language')

            # Validate required fields
            required_fields = ['user_id', 'crop_id', 'filter_type', 'user_language']
            for field in required_fields:
                if not locals().get(field):
                    return JsonResponse({'message': f'Missing or empty field: {field}'}, status=400)

            try:
                farmer = FarmerProfile.objects.get(id=user_id)
            except FarmerProfile.DoesNotExist:
                return JsonResponse({'message': 'Farmer Not Found'})

            veges = SpicesPop.objects.filter(
                fk_crop_id=crop_id,
                fk_language_id=user_language,
                fk_croptype_id=filter_type
            ).order_by("preference", "stage_number")

            today = timezone.now().date()
            stage_data = []

            # Fetch all preferences to determine completion status
            preferences = SpicesPop.objects.filter(
                fk_crop_id=crop_id,
                fk_croptype_id=filter_type
            ).values_list('preference', flat=True).distinct().order_by('preference')

            preference_completion_map = {}
            for pref in preferences:
                preference_completion = VegetablePreferenceCompletion.objects.filter(
                    fk_farmer_id=user_id,
                    fk_crop_id=crop_id,
                    fk_croptype_id=filter_type,
                    preference_number=pref
                ).first()

                if preference_completion:
                    preference_completion_map[pref] = preference_completion

            for vege in veges:
                stage_completion, created = VegetableStageCompletion.objects.get_or_create(
                    spice_pop=vege,
                    fk_farmer_id=user_id,
                    fk_croptype_id=filter_type,
                    defaults={'start_date': None},
                    stage_number=vege.stage_number
                )

                preference_completion = preference_completion_map.get(vege.preference)

                if preference_completion:
                    # Initialize start date based on previous preference completion
                    if vege.preference == 1:
                        # First preference always starts now
                        if stage_completion.start_date is None:
                            stage_completion.start_date = today
                            stage_completion.save()
                    else:
                        # Check if all previous preferences are completed
                        previous_preferences = [p for p in preference_completion_map if p < vege.preference]
                        all_previous_completed = all(
                            preference_completion_map[p].is_completed
                            for p in previous_preferences
                            if preference_completion_map.get(p)
                        )

                        if all_previous_completed and stage_completion.start_date is None:
                            # Set the start date based on the completion of the previous stage
                            previous_stage_completion = VegetableStageCompletion.objects.filter(
                                spice_pop__preference=vege.preference,
                                fk_farmer_id=user_id,
                                stage_number=vege.stage_number - 1,
                                fk_croptype_id=filter_type
                            ).first()
                            if previous_stage_completion and previous_stage_completion.completion_date:
                                stage_completion.start_date = previous_stage_completion.completion_date
                            else:
                                stage_completion.start_date = today

                            stage_completion.save()

                # Calculate progress for this preference
                total_stages = SpicesPop.objects.filter(
                    fk_crop_id=crop_id,
                    preference=vege.preference,
                    fk_croptype_id=filter_type
                ).count()

                completed_stages = VegetableStageCompletion.objects.filter(
                    fk_farmer_id=user_id,
                    spice_pop__fk_crop_id=crop_id,
                    fk_croptype_id=filter_type,
                    spice_pop__preference=vege.preference,
                    is_completed=True
                ).count()

                progress = int((completed_stages / total_stages) * 100) if total_stages > 0 else 0
                if preference_completion:
                    preference_completion.progress = progress
                    preference_completion.save()

                    # Check if all stages for this preference are completed
                    if progress == 100 and not preference_completion.is_completed:
                        preference_completion.is_completed = True
                        preference_completion.completion_date = today
                        preference_completion.total_days = (today - preference_completion.start_date).days if preference_completion.start_date else 0
                        preference_completion.save()

                # Add stage data to stage_data list
                stage_data.append({
                    'stage_id': vege.id,
                    'stages': vege.stages,
                    'stage_name': vege.stage_name,
                    'sow_period': vege.sow_period,
                    'description': vege.description,
                    'stage_number': vege.stage_number,
                    'preference': vege.preference,
                    'is_completed': stage_completion.is_completed,
                    'days_spent': stage_completion.total_days_spent,
                    'start_date': stage_completion.start_date
                })

            return JsonResponse({'stages': stage_data})

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##########################-----------------------------Show Products Based on prefrence------------##############
@csrf_exempt
def ShowSpicesProductsBasedOnPrefrence(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body)
            crop_id = data.get('crop_id')
            filter_type = data.get('filter_type')
            user_language = data.get('user_language')
            preference_number = data.get('preference_number')
            # Validate required fields
            required_fields = ['user_id', 'crop_id', 'filter_type', 'preference_number']
            for field in required_fields:
                if not locals().get(field):
                    return JsonResponse({'message': f'Missing or empty field: {field}'}, status=400)

            spices_products=SpicesPop.objects.filter(fk_crop_id=crop_id,
                fk_language_id=user_language,
                fk_croptype_id=filter_type,
                preference_number=preference_number).prefetch_related('fk_product')
            product_data=[]
            for i in spices_products:
                for j in i.fk_product.all():
                    product_data.append({
                        'product_id': j.id,
                        'product_name': j.productName,
                        'product_description': j.productDescription,
                        'product_price': j.price,
                        'product_quantity': j.quantity,
                        'product_image': j.product_image.url if j.product_image else None,
                    })
            return JsonResponse({'products': product_data}, status=200)

        else:
            return JsonResponse({'message': 'Invalid request method'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
#####################-------------------------------------------------Mark Vegetable Stage as complete---------------################## 
@csrf_exempt
def MarkSpicesStageComplete(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        crop_id = request.POST.get('crop_id')
        filter_type = request.POST.get('filter_type')
        preference_number = request.POST.get('preference_number')

        # Validate required fields
        required_fields = ['user_id', 'crop_id', 'filter_type', 'preference_number']
        for field in required_fields:
            if not locals().get(field):
                return JsonResponse({'message': f'Missing or empty field: {field}'}, status=400)

        try:
            farmer = FarmerProfile.objects.get(id=user_id)
        except FarmerProfile.DoesNotExist:
            return JsonResponse({'message': 'Farmer Not Found'})

        try:
            with transaction.atomic():
                stages = SpicesPop.objects.filter(
                    fk_crop_id=crop_id,
                    preference=preference_number,
                    fk_croptype_id=filter_type
                )

                if not stages.exists():
                    return JsonResponse({'message': 'No stages found for this preference'}, status=404)

                today = timezone.now().date()
                completed_stages_data = []

                for stage in stages:
                    completion_record, created = VegetableStageCompletion.objects.get_or_create(
                        spice_pop=stage,
                        fk_farmer=farmer,
                        fk_croptype_id=filter_type,
                        defaults={'start_date': today, 'completion_date': today, 'is_completed': True, 'total_days_spent': 0}
                    )

                    if not created:
                        completion_record.completion_date = today
                        completion_record.is_completed = True
                        if completion_record.start_date:
                            completion_record.total_days_spent = (completion_record.completion_date - completion_record.start_date).days
                        completion_record.save()

                    completed_stages_data.append({
                        'stage_id': completion_record.spice_pop.id,
                        'stage_number': completion_record.stage_number,
                        'days_to_complete': completion_record.total_days_spent,
                        'preference_number': stage.preference
                    })

                # Handle preference completion
                preference_completion, created = VegetablePreferenceCompletion.objects.get_or_create(
                    fk_farmer=farmer,
                    fk_crop_id=crop_id,
                    fk_croptype_id=filter_type,
                    preference_number=preference_number,
                    fk_spicestage=stages.first(),  # Ensure unique identifier
                    defaults={'start_date': today, 'completion_date': today, 'is_completed': True, 'total_days': 0, 'progress': 100}
                )

                if not created:
                    preference_completion.completion_date = today
                    preference_completion.is_completed = True
                    if preference_completion.start_date:
                        preference_completion.total_days = (preference_completion.completion_date - preference_completion.start_date).days
                    else:
                        preference_completion.total_days = 0
                    preference_completion.progress = 100
                    preference_completion.save()

                # Initialize the next preference
                next_preference_number = int(preference_number) + 1
                next_preference_stages = SpicesPop.objects.filter(
                    fk_crop_id=crop_id,
                    preference=next_preference_number,
                    fk_croptype_id=filter_type
                ).order_by('stage_number').first()

                if next_preference_stages:
                    next_preference_completion, _ = VegetablePreferenceCompletion.objects.get_or_create(
                        fk_farmer=farmer,
                        fk_crop_id=crop_id,
                        fk_croptype_id=filter_type,
                        preference_number=next_preference_number,
                        fk_spicestage=next_preference_stages,  # Ensure unique identifier
                        defaults={'start_date': today}
                    )

                    next_stage_completion, _ = VegetableStageCompletion.objects.get_or_create(
                        spice_pop=next_preference_stages,
                        fk_farmer=farmer,
                        fk_croptype_id=filter_type,
                        defaults={'start_date': today}
                    )

                return JsonResponse({'completed_stages': completed_stages_data})

        except Exception as e:
            return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

    return JsonResponse({'message': 'Invalid request method'})


