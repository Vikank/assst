from django.utils import timezone
import time
import requests
import re
from .models import *
import requests
import logging
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import tldextract
import urllib
from urllib.parse import urljoin
import re

logger = logging.getLogger(__name__)
 
def update_sowing_progress():
    try:
        for sowing_time in SowingTime.objects.all():
            days_since_sowing = sowing_time.get_days_since_sowing()
            SowingProgress.objects.update_or_create(
                fk_sowing_time=sowing_time,
                day_count=days_since_sowing,
                defaults={'created_at': timezone.now()}
            )
            sowing_time.update_day_count()
    except Exception as e:
        logger.error(f"Error updating sowing progress: {e}")

