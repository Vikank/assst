from django.db import models
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import User
import os
from django.utils import timezone
import string
import random
from datetime import datetime
# Create your models here.
class LanguageSelection(models.Model):
    langchoice=[
        ("EN", "EN"),
        ("HI", "HI"),
        ("TE", "TE"),  
        ("TA", "TA"),
        ("MR","MR"),
        ("ML","ML"),
        ("BHO","BHO"),
        ("GU","GU"),
        ("PA","PA"),
        ("BN","BN"),
        ("OR","OR")  ,
        ("AS","AS"),
        ("KN","KN")
        
    ]
    language=models.CharField(max_length=200, choices=langchoice, default='EN')
    class Meta:
        db_table='agreeculture_app_languageselection'


class StateMaster(models.Model):
    state = models.CharField(null=True, blank=True, max_length=100)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_statemaster'

class CityMaster(models.Model):
    fk_state = models.ForeignKey(StateMaster, on_delete=models.CASCADE, null=True, blank=True)
    city = models.CharField(null=True, blank=True, max_length=100)
    created_date = models.DateField(null=True , blank=True)
    class Meta:
        db_table = 'agreeculture_app_citymaster'

class DistrictMaster(models.Model):
    fk_state = models.ForeignKey(StateMaster, on_delete=models.CASCADE, null=True, blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    district=models.CharField(null=True, blank=True, max_length=100)
    class Meta:
        db_table='agreeculture_app_districtmaster'

##############--------------------------CROP Details--------------------------##########################
class SeasonMaster(models.Model):
    season = models.CharField(null=True , blank=True,max_length=100)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_seasonmaster'
    
class CropTypeMaster(models.Model):
    fk_season =models.ForeignKey(SeasonMaster,on_delete=models.CASCADE,null=True,blank=True)
    type = models.CharField(null=True, blank=True, max_length=100)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_croptypemaster'

class CropMaster(models.Model):
    fk_crop_type =models.ForeignKey(CropTypeMaster,on_delete=models.CASCADE,null=True,blank=True)
    crop_name = models.CharField(null=True, blank=True, max_length=100)
    crop_status=models.BooleanField(null=True,blank=True,default="")
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_cropmaster'

class CropImages(models.Model):
    fk_cropmaster = models.ManyToManyField(CropMaster,blank=True)
    crop_image = models.FileField(upload_to="crops/", blank=True, null=True)
    class Meta:
        db_table='agreeculture_app_cropimages'

###############-------------------------------Diffrenet Kinds of Service Providers------------------------##############################
class Service_Provider(models.Model):
    name =  models.CharField(null=True,blank=True,max_length=100)
    service_provider_pic = models.FileField(upload_to="service_provider/", blank=True, null=True)
    paid_or_free = models.BooleanField(default=False, blank=True, null=True)
    created_dt = models.DateTimeField(auto_now_add=False)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_service_provider'

###########################################----------------------------FPO Profile------------------------------#####################
class FPOProfile(models.Model):
    fk_crops=models.CharField(null=True, blank=True, max_length=200)
    password = models.CharField(max_length=128)
    mobile_no = models.CharField(null=True, blank=True, max_length=10)
    fpo_name = models.CharField(max_length=128, blank=True, null=True)
    fk_language = models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    profile = models.FileField(upload_to="Profile/", blank=True, null=True)
    address = models.CharField(null=True, blank=True, max_length=200)
    pincode = models.CharField(null=True, blank=True, max_length=10)
    state = models.CharField(null=True, blank=True, max_length=100)
    district = models.CharField(null=True, blank=True, max_length=100)
    sub_district = models.CharField(null=True, blank=True, max_length=100)
    village = models.CharField(null=True, blank=True, max_length=100)
    # Land area
    lat1 = models.CharField(null=True, blank=True, max_length=100)
    lat2 = models.CharField(null=True, blank=True, max_length=100)
    lat3 = models.CharField(null=True, blank=True, max_length=100)
    lat4 = models.CharField(null=True, blank=True, max_length=100)
    coins = models.IntegerField(null=True, blank=True, default=0)
    badgecolor = models.ImageField(upload_to="fpobadges/", null=True, blank=True)
    BADGE_CHOICES = {
        'white': 'badge-white.png',
        'yellow': 'badge-yellow.png',
        'red': 'badge-red.jpg',
        'blue': 'badge-blue.jpg',
        'green': 'badge-green.jpg'
    }
    def updateBadgeColor(self, coinCount):
        if coinCount == 0:
            return None
        badges = {'white': 100, 'yellow': 500, "red": 1000, "blue": 1500, "green": 200000000000}
        for color, threshold in badges.items():
            if coinCount < threshold:
                return os.path.join('badges/', self.BADGE_CHOICES[color])
        return os.path.join('badges/', self.BADGE_CHOICES['green'])  

    def add_coins(self, amount):
        self.coins += amount
        self.badgecolor = self.updateBadgeColor(self.coins)
        self.save()
    class Meta:
        db_table = 'agreeculture_app_fpoprofile'

#####################----------------------------------------Supplier Details-------------------------####################
class SupplierDetails(models.Model):
    name = models.CharField(max_length=100, blank=True, null=True)
    mobile_no = models.CharField(max_length=12, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)
    address = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=15, blank=True, null=True)
    district = models.CharField(max_length=15, blank=True, null=True)
    village=models.CharField(max_length=100,blank= True,null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    lat = models.DecimalField(max_digits=15, decimal_places=10, blank=True, null=True)
    long=models.DecimalField(max_digits=15, decimal_places=10, blank=True, null=True)
    pincode=models.IntegerField(null=True, blank=True)
    profile = models.FileField(upload_to="SupplierProfile/", blank=True, null=True)
    password = models.CharField(max_length=128,null=True, blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
#############################----------------------------------FPO Bank & Business Details-------------------------------################
class BankBusinessDetails(models.Model):
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_supplier=models.ForeignKey(SupplierDetails,on_delete=models.CASCADE,null=True,blank=True)
    accountholder_name=models.CharField(max_length=100,null=True,blank=True)
    account_number=models.IntegerField(null=True,blank=True)
    bank_name=models.CharField(max_length=100,null=True,blank=True)
    ifsc_code=models.CharField(max_length=100,null=True,blank=True)
    business_establishdate=models.DateField(null=True,blank=True)
    pan_no=models.CharField(max_length=100,null=True,blank=True)
    registration_id=models.CharField(max_length=100,null=True,blank=True)
    gst_number=models.CharField(max_length=100,null=True,blank=True)
    class Meta:
        db_table='agreeculture_app_bankbusinessdetails'
##############################--------------------------------------Shops & Products-----------------------############################
class ShopDetails(models.Model):
    shopName = models.CharField(max_length=100, blank=True, null=True)
    shopContactNo = models.CharField(max_length=12, null=True, blank=True)
    shopaddress = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=15, blank=True, null=True)
    village=models.CharField(max_length=100,blank= True,null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    shopLatitude = models.DecimalField(max_digits=15, decimal_places=10, blank=True, null=True)
    shopLongitude = models.DecimalField(max_digits=15, decimal_places=10, blank=True, null=True)
    productDealsIn = models.CharField(max_length=500, blank=True, null=True)
    Tehsil = models.CharField(max_length=50, blank=True, null=True)
    time_open = (
    ("1 a.m", "1 a.m"),
    ("2 a.m", "2 a.m"),
    ("3 a.m", "3 a.m"),
    ("4 a.m", "4 a.m"),
    ("5 a.m", "5 a.m"),
    ("6 a.m", "6 a.m"),
    ("7 a.m", "7 a.m"),
    ("8 a.m", "8 a.m"),
    ("9 a.m", "9 a.m"),
    ("10 a.m", "10 a.m"),
    ("11 a.m", "11 a.m"),
    )

    time_close = (
    ("12 p.m", "12 p.m"),
    ("1 p.m", "1 p.m"),
    ("2 p.m", "2 p.m"),
    ("3 p.m", "3 p.m"),
    ("4 p.m", "4 p.m"),
    ("5 p.m", "5 p.m"),
    ("6 p.m", "6 p.m"),
    ("7 p.m", "7 p.m"),
    ("8 p.m", "8 p.m"),
    ("9 p.m", "9 p.m"),
    ("10 p.m", "10 p.m"),
    ("11 p.m", "11 p.m"),
    )

    shopd = (
    ("Monday - Tuesday", "Monday - Tuesday"),
    ("Monday - Wednesday", "Monday - Wednesday"),
    ("Monday - Thursday", "Monday - Thursday"),
    ("Monday - Friday", "Monday - Friday"),
    ("Monday - Saturday", "Monday - Saturday"),
    ("Monday - Sunday", "Monday - Sunday"),
    )

    shopclosed = (
    ("Monday", "Monday"),
    ("Tuesday", "Tuesday"),
    ("Wednesday", "Wednesday"),
    ("Thursday", "Thursday"),
    ("Friday", "Friday"),
    ("Saturday", "Saturday"),
    ("Sunday", "Sunday"),
    )
    
    shop_opentime=models.CharField(max_length=100,choices=time_open,default="10 a.m")
    shop_closetime=models.CharField(max_length=100,choices=time_close,default="10 p.m")
    shop_opendays=models.CharField(max_length=100,choices=shopd,default="Monday - Tuesday")
    shop_closedon=models.CharField(max_length=100,choices=shopclosed,default="Sunday")
    shopimage = models.ImageField(upload_to='shopimage/', blank=True, null=True)
    no_of_ratings = models.IntegerField(default=0, blank=True, null=True)
    choices=(
        ("Loan", "Loan"),
      	("Soil Testing", "Soil Testing"),
        ("Shops","Shops"),
        ("Yojna","Yojna")
	)
    provided_by=models.CharField(max_length= 200 , choices = choices,default='Shops')
    partnerservice=models.ForeignKey(Service_Provider,on_delete=models.CASCADE,blank=True, null=True)
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,blank=True,null=True)
    fk_supplier=models.ForeignKey(SupplierDetails,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_supplierdetails'

##################---------------------------------------
#1.Disease Information
class DiseaseMaster(models.Model):
    name = models.CharField(null=True,blank=True,max_length=100)
    symptom = models.TextField(null=True,blank=True)
    treatmentbefore = models.TextField(null=True,blank=True)
    treatmentfield=models.TextField(null=True,blank=True)
    suggestiveproduct=models.TextField(null=True,blank=True)
    treatment=models.TextField(null=True,blank=True)
    message=models.TextField(null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    fk_crops=models.ManyToManyField(CropMaster,blank=True)
    class Meta:
        db_table = 'agreeculture_app_diseasemaster'

class DiseaseTranslation(models.Model):
    fk_disease = models.ForeignKey(DiseaseMaster, on_delete=models.CASCADE,null=True,blank=True)
    fk_language = models.ForeignKey(LanguageSelection, on_delete=models.CASCADE,null=True,blank=True)
    fk_crops=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    translation = models.CharField(max_length=255,null=True,blank=True)

    class Meta:
        #unique_together = ['fk_disease', 'fk_language','fk_crops']
        db_table='agreeculture_app_diseasetranslation'

####################################################---------------Crop Variety---------------------#################
class CropVariety(models.Model):
    fk_crops=models.ForeignKey(CropMaster,blank=True,null=True,on_delete=models.CASCADE)
    variety=models.CharField(max_length=100,null=True,blank=True)
##################################--------------------------Product Type For Sale----------------------#############
class ProductType(models.Model):
    typchoic=[
        ("Agricultural Inputs","Agricultural Inputs"),
        ("Crops","Crops"),
        ("Finish Goods","Finish Goods")
    ]
    product_type=models.CharField(max_length=100,null=True,blank=True,choices=typchoic)

######################---------------------------------FPO Suppliers-----------------------------########################
class FPOSuppliers(models.Model):
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    purchase_date=models.DateField(null=True,blank=True)
    party_name=models.CharField(null=True,blank=True,max_length=100)
    party_mobileno=models.CharField(null=True,blank=True,max_length=10)
    party_company=models.CharField(null=True,blank=True,max_length=10)
    total_amount=models.FloatField(null=True,blank=True,max_length=100)
    unit_price=models.FloatField(null=True,blank=True,max_length=100)
    party_gst=models.CharField(null=True,blank=True,max_length=100)
    state=models.CharField(null=True,blank=True,max_length=100)
    district=models.CharField(null=True,blank=True,max_length=100)
    fk_productype=models.ForeignKey(ProductType,on_delete=models.CASCADE,null=True,blank=True)
    quantity=models.FloatField(null=True,blank=True)
##################----------------------------------Input Suppliers ----------#########
class InputSuppliers(models.Model):
    purchase_date=models.DateField(null=True,blank=True)
    fk_supplier=models.ForeignKey(SupplierDetails,on_delete=models.CASCADE,null=True)
    party_name=models.CharField(null=True,blank=True,max_length=100)
    party_mobileno=models.CharField(null=True,blank=True,max_length=10)
    party_company=models.CharField(null=True,blank=True,max_length=100)
    total_amount=models.FloatField(null=True,blank=True,max_length=100)
    unit_price=models.FloatField(null=True,blank=True,max_length=100)
    fk_productype=models.ForeignKey(ProductType,on_delete=models.CASCADE,null=True,blank=True)
    quantity=models.FloatField(null=True,blank=True)
    state=models.CharField(null=True,blank=True,max_length=100)
    district=models.CharField(null=True,blank=True,max_length=100)
    party_gst=models.CharField(null=True,blank=True,max_length=100)
#####################------------------------------POP Types--------------------------################
class POPTypes(models.Model):
    name=models.CharField(max_length=100,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_poptypes'
####################---------------------------------------Product Information----------------------##################
class ProductDetails(models.Model):
    productName = models.CharField(max_length=100, blank=True, null=True)
    weight = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    productDescription = models.CharField(max_length=500, blank=True, null=True)
    composition=models.CharField(max_length=500, blank=True, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    manufacturerName = models.CharField(max_length=100, blank=True, null=True)
    manufacturing_date=models.DateField(null=True,blank=True)
    product_image = models.ImageField(upload_to='productimage/', blank=True, null=True)
    fk_serviceprovider=models.ForeignKey(Service_Provider,on_delete=models.CASCADE,blank=True,null=True)
    units_cho=[
    ('KG','KG'),
    ('GM','GM'),
    ('L','L'),
    ('ML','ML'),
    ('DOZEN','DOZEN'),
    ]
    measurement_type=models.CharField(max_length=100,null=True,blank=True,choices=units_cho,default="")
    measurement_unit=models.IntegerField(null=True,blank=True)
    sellby_choice=[
        ("Pcs","PCS"),
        ("Weight","WEIGHT")
    ]
    sellby=models.CharField(max_length=100,choices=sellby_choice,null=True,blank=True,default="")
    quantity=models.IntegerField(null=True,blank=True)
    pieces = models.IntegerField(null=True,blank=True)
    sell_statschoice=[
        ("Online","Online"),
        ("Offline","Offline"),
        ("All","All")
    ]
    selling_status=models.CharField(max_length=100,null=True,blank=True,choices=sell_statschoice,default="")
    fk_productype=models.ForeignKey(ProductType,on_delete=models.CASCADE,null=True,blank=True)
    Category=models.CharField(max_length=100,null=True,blank=True)
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_crops=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_variety=models.ForeignKey(CropVariety,on_delete=models.CASCADE,null=True,blank=True)
    fk_supplier=models.ManyToManyField(SupplierDetails,blank=True)
    expiry_date=models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True,null=True,blank=True)
    updated_at = models.DateTimeField(auto_now=True,null=True,blank=True)
    fk_fposupplier=models.ForeignKey(FPOSuppliers,on_delete=models.CASCADE,null=True,blank=True)
    fk_inputsupplier=models.ForeignKey(InputSuppliers,on_delete=models.CASCADE,null=True,blank=True)
    fk_poptype=models.ForeignKey(POPTypes,blank=True,null=True,on_delete=models.CASCADE)
    def expiry_datestatus(self):
        if self.expiry_date:
            current_date = datetime.now().date()
            delta = (self.expiry_date - current_date).days
            if delta > 10:
                return None
            elif delta > 0:
                return f"Expires in {delta} days"
            elif delta == 0:
                return "Expires today"
            else:
                return "Expired"
        return "No expiry date set"

    class Meta:
        db_table = 'agreeculture_app_productdetails'

############################################-------------------Pricing Table------------------------###################
class ProductPrices(models.Model):
    fk_product=models.ForeignKey(ProductDetails,blank=True,null=True,on_delete=models.CASCADE)
    fk_fpo=models.ForeignKey(FPOProfile,blank=True,null=True,on_delete=models.CASCADE)
    fk_supplier=models.ForeignKey(SupplierDetails,blank=True,null=True,on_delete=models.CASCADE)
    fk_fposupplier=models.ForeignKey(FPOSuppliers,blank=True,null=True,on_delete=models.CASCADE)
    fk_inputsupplier=models.ForeignKey(InputSuppliers,blank=True,null=True,on_delete=models.CASCADE)
    purchase_price=models.FloatField(null=True,blank=True,max_length=100)
    unit_price=models.FloatField(null=True,blank=True,max_length=100)
    discount=models.FloatField(null=True,blank=True,max_length=100)
    gst=models.FloatField(null=True,blank=True,max_length=100,default=0)
    sgst=models.FloatField(null=True,blank=True,max_length=100,default=0)
    cgst=models.FloatField(null=True,blank=True,max_length=100,default=0)
    final_price_unit=models.FloatField(null=True,blank=True,max_length=100)   

############------------------------------------------Disease Product Master------------------------##################
class DiseaseProductInfo(models.Model):
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_disease=models.ForeignKey(DiseaseMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_product=models.ForeignKey(ProductDetails,on_delete=models.CASCADE,null=True,blank=True,related_name='diseaseproduct')
    class Meta:
        db_table='agreeculture_app_diseaseproductinfo'
#####################----------------------------------Warehouser Mster------------------------- #################
class WarehouseMaster(models.Model):
    warehouse_name = models.CharField(max_length=100, blank=True, null=True)
    warehouse_address = models.CharField(max_length=100, blank=True, null=True)
    warehouse_city = models.CharField(max_length=100, blank=True, null=True)
    warehouse_state = models.CharField(max_length=100, blank=True, null=True)
    warehouse_pincode = models.CharField(max_length=100, blank=True, null=True)
    warehouse_district= models.CharField(max_length=100, blank=True, null=True)
    warehouse_agentname=models.CharField(max_length=100, blank=True, null=True)
    warehouse_agentcontact=models.CharField(max_length=100, blank=True, null=True)
    warehouse_tehsil = models.CharField(max_length=50, blank=True, null=True)
    time_open = (
    ("1 a.m", "1 a.m"),
    ("2 a.m", "2 a.m"),
    ("3 a.m", "3 a.m"),
    ("4 a.m", "4 a.m"),
    ("5 a.m", "5 a.m"),
    ("6 a.m", "6 a.m"),
    ("7 a.m", "7 a.m"),
    ("8 a.m", "8 a.m"),
    ("9 a.m", "9 a.m"),
    ("10 a.m", "10 a.m"),
    ("11 a.m", "11 a.m"),
    )

    time_close = (
    ("12 p.m", "12 p.m"),
    ("1 p.m", "1 p.m"),
    ("2 p.m", "2 p.m"),
    ("3 p.m", "3 p.m"),
    ("4 p.m", "4 p.m"),
    ("5 p.m", "5 p.m"),
    ("6 p.m", "6 p.m"),
    ("7 p.m", "7 p.m"),
    ("8 p.m", "8 p.m"),
    ("9 p.m", "9 p.m"),
    ("10 p.m", "10 p.m"),
    ("11 p.m", "11 p.m"),
    )

    shopd = (
    ("Monday - Tuesday", "Monday - Tuesday"),
    ("Monday - Wednesday", "Monday - Wednesday"),
    ("Monday - Thursday", "Monday - Thursday"),
    ("Monday - Friday", "Monday - Friday"),
    ("Monday - Saturday", "Monday - Saturday"),
    ("Monday - Sunday", "Monday - Sunday"),
    )

    shopclosed = (
    ("Monday", "Monday"),
    ("Tuesday", "Tuesday"),
    ("Wednesday", "Wednesday"),
    ("Thursday", "Thursday"),
    ("Friday", "Friday"),
    ("Saturday", "Saturday"),
    ("Sunday", "Sunday"),
    )
    
    warehouse_opentime=models.CharField(max_length=100,choices=time_open,default="10 a.m")
    warehouse_closetime=models.CharField(max_length=100,choices=time_close,default="10 p.m")
    warehouse_opendays=models.CharField(max_length=100,choices=shopd,default="Monday - Tuesday")
    warehouse_closedon=models.CharField(max_length=100,choices=shopclosed,default="Sunday")
    fpo_warehouse=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    warehouse_stock=models.IntegerField(null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_warehousemaster'


###################-----------------------------Services Providers Soil Services Prices------------------------################
class SoilCharges(models.Model):
    fk_providername=models.ForeignKey(Service_Provider,on_delete=models.CASCADE,blank=True,null=True)
    fk_shop=models.ForeignKey(SupplierDetails,on_delete=models.CASCADE,blank=True,null=True)
    price=models.FloatField(default=0, blank=True, null=True)
    choices=(
        ("Basic", "Basic"),
      	("Standard", "Standard"),
        ('Premium','Premium'),

	)
    plans=models.CharField(max_length= 200 , choices = choices,default='Basic')
    description=models.CharField(max_length= 200,null=True,blank=True)
    details=models.CharField(max_length= 200,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_soilcharges'


##########################----------------------------FARMER Profile-------------------------------###########################
class FarmerProfile(models.Model):
    fk_crops = models.ManyToManyField(CropMaster, blank=True)
    created_date = models.DateField(null=True, blank=True)
    name = models.CharField(null=True, blank=True, max_length=100)
    mobile_no = models.CharField(null=True, blank=True, max_length=10)
    fk_language = models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    fpo_name = models.ForeignKey(FPOProfile, on_delete=models.CASCADE, related_name='farmers',null=True)
    profile = models.FileField(upload_to="Profile/", blank=True, null=True)
    village=models.CharField(null=True, blank=True, max_length=100)
    block=models.CharField(null=True, blank=True, max_length=100)
    coins = models.IntegerField(null=True, blank=True, default=0)
    badgecolor = models.ImageField(upload_to="badges/", null=True, blank=True)
    BADGE_CHOICES = {
        'white': 'badge-white.png',
        'yellow': 'badge-yellow.png',
        'red': 'badge-red.jpg',
        'blue': 'badge-blue.jpg',
        'green': 'badge-green.jpg'
    }

    def updateBadgeColor(self, coinCount):
        if coinCount == 0:
            return None
        badges = {'white': 100, 'yellow': 500, "red": 1000, "blue": 1500, "green": 200000000000}
        for color, threshold in badges.items():
            if coinCount < threshold:
                return os.path.join('badges/', self.BADGE_CHOICES[color])
        return os.path.join('badges/', self.BADGE_CHOICES['green'])  

    def add_coins(self, amount):
        self.coins += amount
        self.badgecolor = self.updateBadgeColor(self.coins)
        self.save()
    class Meta:
        db_table = 'agreeculture_app_farmerprofile'
   

class UserCommentOnShop(models.Model):
    fk_shop = models.ForeignKey(SupplierDetails, on_delete=models.CASCADE,blank=True,null=True)
    fk_user = models.ForeignKey(FarmerProfile, on_delete=models.CASCADE,blank=True,null=True)
    comment = models.TextField(null=True, blank=True)
    rating = models.CharField(max_length=5, blank=True, null=True)
    class Meta:
        db_table = 'agreeculture_app_usercommentonshop'

#####################################-------------------Farmer Land Records-----------------------###################
class FarmerLandAddress(models.Model):
    fk_farmer=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    land_area=models.FloatField(max_length=20,blank=True,null=True)
    address = models.CharField(null=True, blank=True, max_length=200)
    pincode = models.CharField(null=True, blank=True, max_length=10)
    fk_state = models.ForeignKey(StateMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_district = models.ForeignKey(DistrictMaster,on_delete=models.CASCADE,null=True,blank=True)
    village = models.CharField(null=True, blank=True, max_length=100)
    lat1 = models.FloatField(null=True, blank=True, max_length=100)
    lat2 = models.FloatField(null=True, blank=True, max_length=100)
    tehsil=models.CharField(null=True, blank=True, max_length=100)
    fk_crops=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
#####################################---------------------------Buyer Details------------------------#############
class CustomerDetails(models.Model):
    buyer_name=models.CharField(null=True,blank=True,max_length=100)
    mobile_no=models.CharField(null=True,blank=True,max_length=10)
    address=models.TextField(max_length=400,null=True,blank=True)
    company_name=models.CharField(null=True,blank=True,max_length=100)
    gst_number=models.CharField(null=True,blank=True,max_length=100)
    created_at=models.DateTimeField(auto_now=True)
    fk_fpo=models.ForeignKey(FPOProfile,blank=True,null=True,on_delete=models.CASCADE)
    fk_farmer=models.ForeignKey(FarmerProfile,blank=True,null=True,on_delete=models.CASCADE)
    fk_supplier=models.ForeignKey(SupplierDetails,blank=True,null=True,on_delete=models.CASCADE)
###################--------------------------------------------Disease Detection------------------#############################
#1.Disease Type Selector
class DiseaseTypeSelector(models.Model):
    disease_choice=(
        ("High","High"),
        ("Low","Low"),
        ("Medium","Medium"),
        ("उच्च","उच्च"),
        ("निम्न","निम्न"),
        ("मध्यम","मध्यम")
    )
    disease_category=models.CharField(max_length=20,null=True,blank=True,choices=disease_choice)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table='agreeculture_app_diseasetypeselector'

#2.Disaease Image
class Disease_Images_Master(models.Model):
    fk_disease = models.ManyToManyField(DiseaseMaster,blank=True)
    disease_file = models.FileField(upload_to="disease/", blank=True, null=True)
    class Meta:
        db_table = 'agreeculture_app_disease_images_master'
#3.Disease Output Store
class Upload_Disease(models.Model):
    created_dt = models.DateTimeField(auto_now_add=False)
    fk_provider=models.ForeignKey(Service_Provider,on_delete=models.CASCADE,null=True,blank=True)
    fk_User=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_disease=models.ForeignKey(DiseaseMaster,on_delete=models.CASCADE,blank=True,null=True)  
    uploaded_image = models.FileField(upload_to="uploaded/", blank=True, null=True)
    filter_type =  models.CharField(null=True,blank=True,max_length=100)
    fk_farmer_land=models.ForeignKey(FarmerLandAddress,on_delete=models.CASCADE,null=True,blank=True)
    state = models.CharField(max_length=100, null=True, blank=True)
    district = models.CharField(max_length=100, null=True, blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    #fk_diseasetype=models.ForeignKey(DiseaseTypeSelector,on_delete=models.CASCADE,null=True,blank=True)
    
    class Meta:
        db_table = 'agreeculture_app_upload_disease'

######------------------------------------------Community Section------------------------------############################

# community purpose
class CommunityPost(models.Model):
    fk_user = models.ForeignKey(FarmerProfile, on_delete=models.CASCADE,null=True,blank=True)
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster, on_delete=models.CASCADE , null=True,blank=True)
    description=models.TextField(null=True, blank=True)
    created_dt=models.DateTimeField(auto_now_add=False)
    class Meta:
        db_table = 'agreeculture_app_communitypost'

class PostsMedia(models.Model):
    fk_post=models.ForeignKey(CommunityPost,on_delete=models.CASCADE,null=True,blank=True)
    video_file=models.FileField(upload_to='post/videos', null=True, blank=True)
    image_file = models.FileField(upload_to='post/image', null=True, blank=True)
    class Meta:
        db_table = 'agreeculture_app_postsmedia'

class PostComments(models.Model):
    fk_post=models.ForeignKey(CommunityPost,on_delete=models.CASCADE,null=True,blank=True)
    fk_user=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    text=models.TextField(null=True,blank=True)
    created_dt=models.DateTimeField(auto_now_add=False , null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_postcomments'

class CommentReply(models.Model):
    fk_postcomment = models.ForeignKey(PostComments,on_delete=models.CASCADE,null=True,blank=True)
    fk_user=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    text=models.TextField(null=True,blank=True)
    created_dt=models.DateTimeField(auto_now_add=False)
    class Meta:
        db_table = 'agreeculture_app_commentreply'

class PostsLike(models.Model):
    fk_post=models.ForeignKey(CommunityPost,on_delete=models.CASCADE,null=True,blank=True)    
    fk_user=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    created_dt = models.DateTimeField(auto_now_add=False)
    like_count = models.IntegerField(default=0, blank=True, null=True)
    class Meta:
        db_table = 'agreeculture_app_postslike'
###################################-------------------------------FPO ADD Crop Details----------------#################
class FPOCropDetails(models.Model):
    fpo_crop=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    crop_name=models.CharField(max_length=100,null=True,blank=True)
    crop_variety=models.CharField(max_length=100,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_fpocropdetails'

################-------------------Inventory Details-----------------####################
class InventoryDetails(models.Model):
    fk_product=models.ForeignKey(ProductDetails, on_delete=models.CASCADE,null=True, blank=True)
    fk_fpo=models.ForeignKey(FPOProfile,blank=True,null=True,on_delete=models.CASCADE)
    fk_supplier=models.ForeignKey(SupplierDetails,blank=True,null=True,on_delete=models.CASCADE)
    fk_fposupplier=models.ForeignKey(FPOSuppliers,on_delete=models.CASCADE,null=True,blank=True)
    fk_inputsupplier=models.ForeignKey(InputSuppliers,on_delete=models.CASCADE,null=True,blank=True)
    stock = models.PositiveIntegerField()
    location = models.CharField(max_length=100,null=True,blank=True)
    created_at=models.DateTimeField(auto_now=True)
    updated_at = models.DateTimeField(auto_now=True)
    fk_price=models.ForeignKey(ProductPrices,blank=True,null=True,on_delete=models.CASCADE)
    def stock_status(self):
        if self.stock==0:
            return "Out of Stock"
        elif self.stock<10:
            return "Low Stock"
        else:
            return "In Stock"
    def save(self, *args, **kwargs):
        if not self.stock:
            self.stock = self.fk_product.quantity
        super().save(*args, **kwargs)
    
    class Meta:
        db_table='agreeculture_app_inventorydetails'

#####################----------------------------------Product Sale------------------------################
class ProductSale(models.Model):
    fk_invent=models.ForeignKey(InventoryDetails,on_delete=models.CASCADE,null=True,blank=True)
    fk_custom=models.ForeignKey(CustomerDetails,on_delete=models.CASCADE,null=True,blank=True)
    amount = models.FloatField(null=True,blank=True,max_length=100)
    paymentchocie=[
        ('Cash','Cash'),
        ('Card','Card'),
        ('Online','Online'),
        ('Cheque','Cheque'),
        ('Others','Others'),
    ]
    payment_method = models.CharField(max_length=100, choices=paymentchocie, null=True, blank=True)
    sales_date = models.DateField(null=True,blank=True)
    final_price=models.FloatField(null=True,blank=True,max_length=100)
    class Meta:
        db_table='agreeculture_app_productsale'
#########################---------------------------Sales Record-----------------------##################
class SalesRecordItem(models.Model):
    fk_fpo=models.ForeignKey(FPOProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_supplier=models.ForeignKey(SupplierDetails,on_delete=models.CASCADE,null=True,blank=True)
    fk_fposupplier=models.ForeignKey(FPOSuppliers,on_delete=models.CASCADE,null=True,blank=True)
    fk_inputsupplier=models.ForeignKey(InputSuppliers,on_delete=models.CASCADE,null=True,blank=True)
    fk_producttype=models.ForeignKey(ProductType,on_delete=models.CASCADE,null=True,blank=True)
    category = models.CharField(max_length=100,null=True,blank=True)
    quantity = models.PositiveIntegerField()
    total_amount=models.FloatField(null=True,blank=True,max_length=100)
    sales_date = models.DateField(null=True,blank=True)
    name=models.CharField(max_length=100,null=True,blank=True)
    class Meta:
        db_table='agreeculture_app_salesrecorditem'
#############--------------------------Packaging Details---------------#######################
class PackagingDetails(models.Model):
    created_dt=models.DateTimeField(auto_now_add=False)
    fk_product=models.ForeignKey(ProductDetails, null=True, blank=True,on_delete=models.CASCADE)
    PACKAGE_TYPE =[
        ("Bags and Sacks","Bags and Sacks"),
        ("Boxes","Boxes"),
        ("Bins","Bins"),
        ("Cartons and Trays","Cartons and Trays"),
        ("Pallet Boxes","Pallet Boxes"),
        ("Clamshell Packaging","Clamshell Packaging"),
        ("Bulk Bags","Bulk Bags"),
        ("Shrink Wrap and Stretch Film","Shrink Wrap and Stretch Film"),
    ]
    package_type=models.CharField(max_length=100,null=True,blank=True,choices=PACKAGE_TYPE,default="")
    weight = models.CharField(max_length=15,null=True, blank=True)
    height = models.CharField(max_length=15,null=True, blank=True)
    length = models.CharField(max_length=15,null=True, blank=True)
    breadth = models.CharField(max_length=15,null=True, blank=True)
    class Meta:
        db_table = 'agreeculture_app_packagingdetails'

class WarehouseDetails(models.Model):
    #fk_warehosue = models.ForeignKey(WarehouseMaster,on_delete=models.CASCADE,null=True,blank=True)
    #fk_inventory = models.ForeignKey(InventoryDetails,on_delete=models.CASCADE,null=True,blank=True)
    created_date = models.DateField(null=True, blank=True)
    stock = models.CharField(max_length=100, blank=True, null=True)
    class Meta:
        db_table = 'agreeculture_app_warehousedetails'
########################------------------------------------Current News----------------------###################
class CurrentNews(models.Model):
    title=models.CharField(max_length=5000,null=True,blank=True)
    content=models.TextField(null=True,blank=True)
    created_at = models.DateField(null=True, blank=True)
    image=models.FileField(upload_to="current_news/", blank=True, null=True)
    related_post=models.CharField(max_length=100,null=True,blank=True)
    source=models.CharField(max_length=100,null=True,blank=True)
    link = models.CharField(null=True,blank=True,max_length=5000)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_currentnews'

#################-----------------------------------Vegetable Pop-----------------#############################
class VegetablePop(models.Model):  
    stages=models.CharField(max_length=100,null=True,blank=True)
    sow_perd=[
        ("0-7","0-7"),
        ("7-14","7-14"),
        ("14-21","14-21"),
        ("21-28","21-28"),
        ("28-35","28-35"),
        ("35-42","35-42"),
        ("42-49","42-49"),
        ("49-56","49-56"),
        ("56-63","56-63"),
        ("63-70","63-70"),
        ("70-77","70-77"),
        ("77-84","77-84"),
    ]
    sow_period=models.CharField(max_length=100,null=True,blank=True,choices=sow_perd,default="")
    stage_name=models.CharField(max_length=100,null=True,blank=True)
    stage_number=models.IntegerField(null=True,blank=True)
    description=models.TextField(null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    preference=models.IntegerField(null=True,blank=True)
    video=models.FileField(upload_to="vegetable_pop/", blank=True, null=True)
    fk_croptype=models.ForeignKey(POPTypes,on_delete=models.CASCADE,null=True,blank=True)
    class Meta:
        db_table = 'agreeculture_app_cropstages'

###########################----------------SPices POP--------------------------------######################
class SpicesPop(models.Model):  
    stages=models.CharField(max_length=100,null=True,blank=True)
    sow_period=models.CharField(max_length=1000,null=True,blank=True)
    stage_name=models.CharField(max_length=100,null=True,blank=True)
    stage_number=models.IntegerField(null=True,blank=True)
    description=models.TextField(null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    preference=models.IntegerField(null=True,blank=True)
    video=models.FileField(upload_to="spicespop/", blank=True, null=True)
    fk_croptype=models.ForeignKey(POPTypes,on_delete=models.CASCADE,null=True,blank=True)
    fk_product=models.ManyToManyField(ProductDetails,blank=True)
    class Meta:
        db_table = 'agreeculture_app_spicespop'


##############---------------------------------Stage Completion of Vegetables------------------##########
class VegetableStageCompletion(models.Model):
    vegetable_pop = models.ForeignKey(VegetablePop, on_delete=models.CASCADE,null=True,blank=True)
    spice_pop = models.ForeignKey(SpicesPop,on_delete=models.CASCADE,null=True,blank=True)
    stage_number = models.IntegerField(null=True,blank=True)
    fk_farmer = models.ForeignKey(FarmerProfile, on_delete=models.CASCADE,null=True,blank=True)
    fk_croptype=models.ForeignKey(POPTypes,on_delete=models.CASCADE,null=True,blank=True)
    start_date=models.DateField(null=True, blank=True)
    completion_date = models.DateField(null=True, blank=True)
    total_days_spent = models.IntegerField(default=0)
    delay_days = models.IntegerField(default=0)
    early_days = models.IntegerField(default=0)
    progress=models.IntegerField(default=0)
    is_completed = models.BooleanField(default=False)
    class Meta:
        db_table='agreeculture_app_vegetablestagecompletion'
##################------------------------------------Prefrence Record (Land prepation,sowing etc)----------##########
class VegetablePreferenceCompletion(models.Model):
    fk_farmer = models.ForeignKey(FarmerProfile, on_delete=models.CASCADE)
    fk_crop = models.ForeignKey(CropMaster, on_delete=models.CASCADE)
    fk_vegetablestage = models.ForeignKey(VegetablePop,on_delete=models.CASCADE,null=True,blank=True)
    fk_spicestage=models.ForeignKey(SpicesPop,on_delete=models.CASCADE,null=True,blank=True)
    fk_croptype=models.ForeignKey(POPTypes,on_delete=models.CASCADE,null=True,blank=True)
    preference_number = models.IntegerField()
    start_date = models.DateField(null=True, blank=True)
    completion_date = models.DateField(null=True, blank=True)
    total_days = models.IntegerField(default=0)
    is_completed = models.BooleanField(default=False)
    progress=models.IntegerField(default=0)
    class Meta:
        db_table = 'agreeculture_app_vegetablepreferencecompletion'
##################---------------------------------Sowing Stages----------------------##########
class SowingTime(models.Model):
    fk_user=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_farm=models.ForeignKey(FarmerLandAddress,on_delete=models.CASCADE,null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    sowing_date=models.DateField(null=True,blank=True)
    total_days = models.IntegerField(default=0)
    def get_days_since_sowing(self):
        today = timezone.now().date()
        if self.sowing_date:
            if isinstance(self.sowing_date, str):
                sowing_date = datetime.strptime(self.sowing_date, "%Y-%m-%d").date()
            else:
                sowing_date = self.sowing_date
            return (today - sowing_date).days
        return 0
    def update_day_count(self):
        self.day_count = self.get_days_since_sowing()
        self.save()
    class Meta:
        db_table = 'agreeculture_app_sowingtime'

########################------------------------------Sowing Progress-----------------------##############
class SowingProgress(models.Model):
    fk_sowing_time = models.ForeignKey(SowingTime, on_delete=models.CASCADE, related_name='progress')
    stage = models.ForeignKey(VegetablePop, on_delete=models.CASCADE,null=True,blank=True)
    day_count = models.IntegerField(default=0)
    completed_at = models.DateTimeField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20,null=True,blank=True)
    fk_farm=models.ForeignKey(FarmerLandAddress,on_delete=models.CASCADE,null=True,blank=True)
    fk_user=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    stage_start_date = models.DateField(null=True, blank=True)
    stage_end_date = models.DateField(null=True, blank=True)
    delay_days = models.IntegerField(default=0)
    class Meta:
        db_table = 'agreeculture_app_sowingprogress'
        ordering = ['created_at']


class StageCompletionInfo(models.Model):
    fk_sowing_progress = models.ForeignKey(SowingProgress, on_delete=models.CASCADE,null=True,blank=True)
    days_taken = models.IntegerField(null=True,blank=True)
    total_days_taken = models.IntegerField(null=True,blank=True)
    fk_farm=models.ForeignKey(FarmerLandAddress,on_delete=models.CASCADE,null=True,blank=True)
    fk_user=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    stage_start_date = models.DateField(null=True, blank=True)
    stage_end_date = models.DateField(null=True, blank=True)
    delay_days = models.IntegerField(default=0)
    class Meta:
        db_table = 'agreeculture_app_stagecompletioninfo'

###################################------------------------Govt Schemes-----------------------------################
class GovtSchemes(models.Model):
    scheme_name=models.TextField(max_length=300,null=True,blank=True)
    details=models.TextField(max_length=5000,null=True,blank=True)
    benefits=models.TextField(max_length=5000,null=True,blank=True)
    elgibility=models.TextField(max_length=5000,null=True,blank=True)
    application_process=models.TextField(max_length=5000,null=True,blank=True)
    document_require=models.TextField(max_length=5000,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    scheme_choice=(
        ("Central Schemes","Central Schemes"),
        ("State Schemes","State Schemes"),
        ("केन्द्र सरकार की योजनाएं","केन्द्र सरकार की योजनाएं"),
        ("राज्य सरकार की योजनाएं","राज्य सरकार की योजनाएं")
    )
    scheme_by=models.CharField(null=True,blank=True,choices=scheme_choice,max_length=50,default="")
    ministry_name=models.CharField(null=True,blank=True,max_length=100)
    fk_state=models.ForeignKey(StateMaster,on_delete=models.CASCADE,null=True,blank=True,default="")
    applicationform_link=models.URLField(null=True,blank=True,default="")
    reference=models.TextField(null=True, blank=True, default="")
    scheme_image = models.FileField(upload_to='scheme', null=True, blank=True)
    def save(self,*args,**kwargs):
        if self.reference:
            self.reference='\n'.join(self.reference.split())
        super().save(*args,**kwargs)
    class Meta:
        db_table='agreeculture_app_govtschemes'

##############################-----------------Fertilizer--------------------------------############
class Fertilizer(models.Model):
    fk_state=models.ForeignKey(StateMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    nitrogen=models.IntegerField(null=True,blank=True)
    phosphorus=models.IntegerField(null=True,blank=True)
    potassium=models.IntegerField(null=True,blank=True)
    zincsulphate=models.IntegerField(null=True,blank=True)
    units_cho=[
    ('KG','KG'),
    ('GM','GM'),
    ('L','L'),
    ('ML','ML'),
    ('DOZEN','DOZEN'),
    ]
    measurement_type=models.CharField(max_length=100,null=True,blank=True,choices=units_cho,default="")
    # def calcuatekgha(self,obj):
    #     if self.objec



#############################--------------------CROP Filter---------------------###############################
class CropFilter(models.Model):
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    crop_categories=models.CharField(null=True,blank=True,max_length=100,default="")
##############################----------------------Fruits POP--------------------#########
class FruitsPop(models.Model):
    fk_state=models.ForeignKey(StateMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_filter=models.ForeignKey(CropFilter,on_delete=models.CASCADE,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    fk_crops=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    stages=models.CharField(max_length=100,null=True,blank=True)
    stage_name=models.CharField(max_length=100,null=True,blank=True)
    stage_number=models.IntegerField(null=True,blank=True)
    start_periodch=(
    ("January", "January"),
    ("February", "February"),
    ("March", "March"),
    ("April", "April"),
    ("May", "May"),
    ("June", "June"),
    ("July", "July"),
    ("August", "August"),
    ("September", "September"),
    ("October", "October"),
    ("November", "November"),
    ("December", "December")
    )
    start_period=models.CharField(max_length=20,null=True,blank=True,default="",choices=start_periodch)
    end_periodch=(
    ("January", "January"),
    ("February", "February"),
    ("March", "March"),
    ("April", "April"),
    ("May", "May"),
    ("June", "June"),
    ("July", "July"),
    ("August", "August"),
    ("September", "September"),
    ("October", "October"),
    ("November", "November"),
    ("December", "December")
    )
    end_period=models.CharField(max_length=20,null=True,blank=True,default="",choices=end_periodch)
    start_month = models.IntegerField(null=True,blank=True)
    end_month = models.IntegerField(null=True,blank=True)
    prefrence_type=models.IntegerField(null=True,blank=True)
    orchidtype=models.CharField(max_length=20,null=True,blank=True,default="")
    fk_croptype=models.ForeignKey(POPTypes,on_delete=models.CASCADE,null=True,blank=True)
    is_complete = models.BooleanField(default=False)
    description=models.TextField(null=True,blank=True)

class FruitsStageCompletion(models.Model):
    fk_fruits = models.ForeignKey(FruitsPop, on_delete=models.CASCADE,null=True,blank=True)
    fk_farmer=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True)
    fk_farmland=models.ForeignKey(FarmerLandAddress,on_delete=models.CASCADE,null=True)
    start_date = models.DateField(auto_now_add=True)
    completion_date = models.DateField(null=True, blank=True)
    submit_image=models.FileField(upload_to="fruit_submit/", blank=True, null=True)
    days_completed = models.IntegerField(default=0)
    delay_count = models.IntegerField(default=0)
######################################-------------------------Soil Testing BY Salam Kisan---------------------------##########
class SalamKisanSoilTesting(models.Model):
    fk_farmer=models.ForeignKey(FarmerProfile,on_delete=models.CASCADE,null=True,blank=True)
    fk_serviceprovider=models.ForeignKey(Service_Provider,on_delete=models.CASCADE,null=True,blank=True)
    fk_farmland=models.ForeignKey(FarmerLandAddress,on_delete=models.CASCADE,null=True,blank=True)
    cropselect=models.CharField(max_length=100,null=True,blank=True)
    class Meta:
        db_table='agreeculture_app_salamkisansoiltesting'

#######################-----------------------------------Disease Video---------------------############
class DiseaseVideo(models.Model):
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    video=models.FileField(upload_to="disease_video/", blank=True, null=True)




class OverallStageProgress(models.Model):
    stage_name = models.CharField(max_length=100)
    preference = models.IntegerField()
    total_stages = models.IntegerField(default=0)
    completed_stages = models.IntegerField(default=0)
    overall_progress = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    fk_crop_id = models.IntegerField(default=0)

    class Meta:
        unique_together = ('stage_name', 'preference', 'fk_crop_id')

#############################-------------------------------Suggested CrOPS--------------------#############
class SuggestedCrop(models.Model):
    season = models.CharField(max_length=500,null=True,blank=True)
    start_month = models.IntegerField(null=True, blank=True)
    end_month = models.IntegerField(null=True, blank=True)
    description = models.TextField(max_length=1000,null=True,blank=True)
    weather_temperature = models.CharField(max_length=500,null=True,blank=True)
    cost_of_cultivation = models.CharField(max_length=500,null=True,blank=True)
    market_price = models.CharField(max_length=500,null=True,blank=True)
    production = models.CharField(max_length=1000,null=True,blank=True)
    fk_crop=models.ForeignKey(CropMaster,on_delete=models.CASCADE,null=True,blank=True)
    fk_language=models.ForeignKey(LanguageSelection,on_delete=models.CASCADE,null=True,blank=True)
    