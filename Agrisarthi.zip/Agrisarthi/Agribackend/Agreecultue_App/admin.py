from django.contrib import admin
from .models import *
from django.utils.html import format_html
# Register your models here.
#############------------------------------------Language Slecytion-------------------##############
@admin.register(LanguageSelection)
class LangaugeSelectionAdmin(admin.ModelAdmin):
    list_display=('id','language')

#################------------------------------POP Types-----------------------------############
@admin.register(POPTypes)
class POPTypesAdmin(admin.ModelAdmin):
    list_display=('id','name','getlanguage')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'
#########################-------------------------State Master--------------------------##################
@admin.register(StateMaster)
class StateMasterAdmin(admin.ModelAdmin):
    list_display = ('id','state', 'getlanguage')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'
#########################----------------------------Distict Master-------------------------#############
@admin.register(DistrictMaster)
class DistrictMasterAdmin(admin.ModelAdmin):
    list_display=('id','getstate','district')
    def getstate(self,obj):
        return obj.fk_state.state if obj.fk_state else None
    getstate.short_description='State'

@admin.register(CityMaster)
class CityMasterAdmin(admin.ModelAdmin):
    list_display = ('get_state', 'city', 'created_date')

    def get_state(self, obj):
        return obj.fk_state.state if obj.fk_state else None
    get_state.short_description = 'State'
    get_state.admin_order_field = 'fk_state__state'

@admin.register(SeasonMaster)
class SeasonMasterAdmin(admin.ModelAdmin):
    list_display = ('id','season','getlanguage')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

@admin.register(CropTypeMaster)
class CropTypeMasterAdmin(admin.ModelAdmin):
    list_display = ('id','get_season', 'type','getlanguage')
    def get_season(self, obj):
        return obj.fk_season.season if obj.fk_season else None
    get_season.short_description = 'Season'
    get_season.admin_order_field = 'fk_season__season'
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

@admin.register(CropMaster)
class CropMasterAdmin(admin.ModelAdmin):
    list_display = ('id','get_crop_type', 'crop_name','getlanguage')

    def get_crop_type(self, obj):
        return obj.fk_crop_type.type if obj.fk_crop_type else None
    get_crop_type.short_description = 'Crop Type'
    get_crop_type.admin_order_field = 'fk_crop_type__type'

    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'


@admin.register(CropImages)
class CropImagesAdmin(admin.ModelAdmin):
    list_display=('id','get_crop','crop_image')
    def get_crop(self, obj):
        return ", ".join([disease.crop_name for disease in obj.fk_cropmaster.all()])
    get_crop.short_description = 'Crop Name'
###############################--------------------------------------Disease Section-------------######################
@admin.register(DiseaseProductInfo)
class DiseaseProductInfoAdmin(admin.ModelAdmin):
    list_display = ('getcrop_name', 'getdis_name', 'getproduct_name','fk_crop')
    search_fields = ('fk_crop__cropname', 'fk_disease__name', 'fk_product__productName')  # Adjust field names as per your model
    #list_filter = ('fk_crop', 'fk_disease', 'fk_product')
    def getcrop_name(self,obj):
        return obj.fk_crop.crop_name if obj.fk_crop else None
    getcrop_name.short_description = 'Crop Name'

    def getdis_name(self,obj):
        return obj.fk_disease.name if obj.fk_disease else None
    getdis_name.short_description = 'Disease Name'

    def getproduct_name(self,obj):
        return obj.fk_product.productName if obj.fk_product else None
    getproduct_name.short_description = 'Product Name'
############################----------------------------User Comments on Shop-----------------###############
@admin.register(UserCommentOnShop)
class UserCommentOnShopAdmin(admin.ModelAdmin):
    list_display=('id','comment','rating')
    #def get_user_name(self,obj):
     #   return obj.fk_user.type if obj.fk_user else None
    #def get_shop_name(self,obj):
      #  return obj.fk_shop.shopName if obj.fk_shop else None

#############################---------------------------Diffferent UsERS---------------------#################
@admin.register(FarmerProfile)
class FarmerofileAdmin(admin.ModelAdmin):
    list_display = ('id','name', 'mobile_no', 'getlanguage','display_badgecolor','coins')
    def display_badgecolor(self, obj):
        if obj.badgecolor:
            return format_html('<a href="{}" target="_blank"><img src="{}" width="100px" /></a>',  obj.badgecolor.url,obj.badgecolor.url)
        else:
            return '-'
    display_badgecolor.short_description = 'Badge Color'

    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'


    def save_model(self, request, obj, form, change):
        if 'coins' in form.changed_data:
            obj.add_coins(form.cleaned_data['coins'])
        super().save_model(request, obj, form, change)



#############--------------------------------------------Community Section---------------------##################### 
@admin.register(CommunityPost)
class CommunityPostAdmin(admin.ModelAdmin):
    list_display = ('get_user_name','display_fponame','get_crop_name', 'description', 'created_dt')

    def get_user_name(self, obj):
        return obj.fk_user.name if obj.fk_user else None
    get_user_name.short_description = 'Posted by Farmer'
    get_user_name.admin_order_field = 'fk_user__name'
    def display_fponame(self,obj):
        return obj.fk_fpo.fpo_name if obj.fk_fpo else None
    display_fponame.short_description ="Posted By FPO"
    def get_crop_name(self, obj):
        return obj.fk_crop.crop_name if obj.fk_crop else None
    get_crop_name.short_description = 'Crop Name'
    get_crop_name.admin_order_field = 'fk_crop__crop_name'

@admin.register(PostsMedia)
class PostsMediaAdmin(admin.ModelAdmin):
    list_display = ('fk_post', 'video_file', 'image_file')

@admin.register(PostComments)
class PostCommentsAdmin(admin.ModelAdmin):
    list_display = ('fk_post', 'get_user_name','display_fponame','text', 'created_dt')
    def get_user_name(self, obj):
        return obj.fk_user.name if obj.fk_user else None
    get_user_name.short_description = 'Commented by Farmer'
    get_user_name.admin_order_field = 'fk_user__name'
    def display_fponame(self,obj):
        return obj.fk_fpo.fpo_name if obj.fk_fpo else None
    display_fponame.short_description ="Commented By FPO"

@admin.register(CommentReply)
class CommentReplyAdmin(admin.ModelAdmin):
    list_display = ('display_postcomment', 'displayfarmer_name','display_fponame','text', 'created_dt')

    def display_postcomment(self,obj):
        return obj.fk_postcomment.text if obj.fk_postcomment else None
    display_postcomment.short_description = "Comment"

    def displayfarmer_name(self,obj):
        return obj.fk_user.name if obj.fk_user else None
    displayfarmer_name.short_description = "Reply by Farmer"

    def display_fponame(self,obj):
        return obj.fk_fpo.fpo_name if obj.fk_fpo else None
    display_fponame.short_description ="Reply By FPO"
    

@admin.register(PostsLike)
class PostsLikeAdmin(admin.ModelAdmin):
    list_display = ('fk_post', 'fk_user','fk_fpo','like_count', 'created_dt')
    def display_post(self,obj):
        return obj.fk_post.description if obj.fk_post else None

################---------------------------------------Service Providers----------------------------###################################

@admin.register(Service_Provider)
class Service_ProviderAdmin(admin.ModelAdmin):
    list_display = ('id','name', 'display_service', 'created_dt','paid_or_free','getlanguage')

    def display_service(self, obj):

        if obj.service_provider_pic:
            return format_html('<a href="{}" target="_blank"><img src="{}" width="100px" /></a>', obj.service_provider_pic.url, obj.service_provider_pic.url)
        else:
            return '-'
    display_service.short_description = 'Service Provider'

    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

#########################----------------------------------Disease Section Admin-----------------------------------##################
@admin.register(DiseaseMaster)
class DiseaseMasterAdmin(admin.ModelAdmin):
    list_display = ('id','name','symptom','treatmentbefore','treatmentfield','getlanguage')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

@admin.register(Disease_Images_Master)
class Disease_Images_MasterAdmin(admin.ModelAdmin):
    list_display = ('id','get_fk_disease', 'disease_file')
    
    def get_fk_disease(self, obj):
        return ", ".join([disease.name for disease in obj.fk_disease.all()])
    get_fk_disease.short_description = 'Diseases'

@admin.register(DiseaseTranslation)
class DiseaseTranslationAdmin(admin.ModelAdmin):
    list_display=('id','getdisease_name','getlanguage','translation','fk_crops')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

    def getdisease_name(self,obj):
        return obj.fk_disease.name if obj.fk_disease else None
    
@admin.register(DiseaseTypeSelector)
class DiseaseTypeSelectorAdmin(admin.ModelAdmin):
    list_display=('id','disease_category','getlanguage')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

#######################--------------------------------------Upload Diseasees--------------------------#################
@admin.register(Upload_Disease)
class Uploaded_DiseaseAdmin(admin.ModelAdmin):
    list_display = ('id','get_service_provider', 'get_crop_name','get_disease_name','get_user','fk_language','state','district'
                    )

    def get_user(self, obj):
        return obj.fk_User.id if obj.fk_User else None
    get_user.short_description = 'User'

    def get_service_provider(self, obj):
        return obj.fk_provider.name if obj.fk_provider else None
    get_service_provider.short_description = 'Service Provider'
    get_service_provider.admin_order_field = 'fk_provider__name'

    def get_crop_name(self, obj):
        return obj.fk_crop.crop_name if obj.fk_crop else None
    get_crop_name.short_description = 'Crop Name'
    get_crop_name.admin_order_field = 'fk_crop__crop_name'

    def get_disease_name(self, obj):

        return obj.fk_disease.name if obj.fk_disease else None
    get_disease_name.short_description = 'Disease Name'
    get_disease_name.admin_order_field = 'fk_disease__name'


###################----------------------------------Admin Product and Supplier Details------------------------#################
@admin.register(ProductDetails)
class ProductDetailsAdmin(admin.ModelAdmin):
    list_display = ('id', 'productName', 'Category', 'weight', 'price', 'manufacturerName', 'display_product_image',"measurement_type",
                    "quantity")
    list_filter = ('Category', 'manufacturerName')
    search_fields = ('productName', 'manufacturerName')

    def display_product_image(self, obj):
        if obj.product_image:
            return format_html('<a href="{}" target="_blank"><img src="{}" width="100px" /></a>', obj.product_image.url, obj.product_image.url)
        else:
            return '-'
    display_product_image.short_description = 'Product Image'

#####################-------------------------------------Input Suppliers(Suppliers)----------------------#########################
@admin.register(SupplierDetails)
class SupplierDetailsAdmin(admin.ModelAdmin):
    list_display = ('name', 'mobile_no', 'email', 'state', 'district', 'city', 'village')

@admin.register(InputSuppliers)
class InputSuppliersAdmin(admin.ModelAdmin):
    list_display = ('purchase_date', 'fk_supplier', 'party_name', 'party_mobileno', 'party_company', 'total_amount', 'unit_price', 'fk_productype', 'quantity', 'party_gst')
    search_fields = ('party_name', 'party_company', 'party_mobileno')
    list_filter = ('purchase_date', 'fk_supplier', 'fk_productype')
################--------------------------------------SHOP Details-----------------------------#######################
@admin.register(ShopDetails)
class ShopDetailsAdmin(admin.ModelAdmin):
    list_display = ('shopName', 'shopContactNo', 'city', 'state','fk_fpo','fk_supplier')
    search_fields = ('shopName', 'city', 'state')
    list_filter = ('state', 'city', 'shop_opendays')
@admin.register(FPOProfile)
class FPOProfileAdmin(admin.ModelAdmin):
    list_display = ('id', 'fpo_name', 'fk_language', 'address', 'display_badgecolor', 'coins')
    #inlines = [FPOProductInline]
    def display_badgecolor(self, obj):
        if obj.badgecolor:
            return format_html('<a href="{}" target="_blank"><img src="{}" width="100px" /></a>',  obj.badgecolor.url,obj.badgecolor.url)
        else:
            return '-'
    display_badgecolor.short_description = 'Badge Color'

    def save_model(self, request, obj, form, change):
        if 'coins' in form.changed_data:
            obj.add_coins(form.cleaned_data['coins'])
        super().save_model(request, obj, form, change)

#################-------------------------------------FPO Busines Details-----------------------###########
@admin.register(BankBusinessDetails)
class BankBusinessDetailsAdmin(admin.ModelAdmin):
    list_display = ('fk_fpo','fk_supplier','accountholder_name','bank_name')
    list_filter = ('fk_fpo', 'fk_supplier')

######################----------------------------------Soil Tseting------------------############################
@admin.register(SoilCharges)
class SoilAdminCharges(admin.ModelAdmin):
    list_display = ('id', 'servicre_shop_name', 'supplier_shop_name', 'price', 'plans', 'description','details')

    def supplier_shop_name(self, obj):
        return obj.fk_shop.shopName

    supplier_shop_name.admin_order_field = 'fk_shop__shopName'
    supplier_shop_name.short_description = 'Supplier Shop Name'

    def servicre_shop_name(self, obj):
        return obj.fk_providername.name

    servicre_shop_name.admin_order_field = 'fk_providername__name'
    servicre_shop_name.short_description = 'Provider Name'

   
######################-----------------------------FPO Product Deatils-------------------############
@admin.register(FPOCropDetails)
class FPOCropDetailsAdmin(admin.ModelAdmin):
    list_display=('crop_name','crop_variety')

#######################################---------------------------Customers Who Buy Products-------------------#########
@admin.register(CustomerDetails)
class CustomerDetailsAdmin(admin.ModelAdmin):
    list_display=('buyer_name','mobile_no','address','company_name','gst_number','created_at')
########################---------------------------Warehouse Details------------------------################
@admin.register(WarehouseMaster)
class WarehouseMasterAdmin(admin.ModelAdmin):
   list_display = ('warehouse_name', 'warehouse_address', 'warehouse_city', 'warehouse_state', 'warehouse_pincode', 'warehouse_district', 'warehouse_agentname', 'warehouse_agentcontact', 'warehouse_tehsil', 'warehouse_opentime', 'warehouse_closetime', 'warehouse_opendays', 'warehouse_closedon')


###########################--------------Inventory & Packaging-------------------------------###########################
@admin.register(InventoryDetails)
class InventoryDetailsAdmin(admin.ModelAdmin):
    list_display = ('id', 'get_produtcname','stock','location','created_at','updated_at','get_filtertype')
    def get_produtcname(self, obj):
        return obj.fk_product.productName if obj.fk_product else None
    get_produtcname.short_description = 'Product Name'

    def get_filtertype(self,obj):
        return obj.fk_product.fk_productype.product_type if obj.fk_product else None
@admin.register(PackagingDetails)
class PackagingDetailsAdmin(admin.ModelAdmin):
    list_display = ('id','weight','height','length','breadth')
    search_fields = ('id', )

###############################--------------------------FPO Product Suppliers-----------------------------##############
@admin.register(FPOSuppliers)
class FPOSuppliersAdmin(admin.ModelAdmin):
    list_display = ('fk_fpo', 'purchase_date', 'party_name', 'party_mobileno', 'party_company', 'total_amount', 'unit_price', 'fk_productype', 'quantity')
    search_fields = ('party_name', 'party_mobileno', 'party_company')
    list_filter = ('purchase_date', 'fk_productype')
    ordering = ('purchase_date',)
    fieldsets = (
        (None, {
            'fields': ('fk_fpo', 'purchase_date', 'party_name', 'party_mobileno', 'party_company', 'total_amount', 'unit_price', 'fk_productype', 'quantity')
        }),
    )
#################################----------------------------------Product Sales---------------------------##################
@admin.register(ProductSale)
class ProductSaleAdmin(admin.ModelAdmin):
    list_display = ('get_produtcname', 'amount', 'sales_date','final_price')
    def get_produtcname(self, obj):
        return obj.fk_invent.fk_product.productName if obj.fk_invent else None
    get_produtcname.short_description = 'Product Name'
######################--------------------------------------------Sales Record of Each Buyer---------------------------##########
@admin.register(SalesRecordItem)
class SalesRecordItemAdmin(admin.ModelAdmin):
    list_display=('display_fponame','category','quantity','total_amount','name')
    list_filter=("fk_fpo",'name')
    def display_fponame(self,obj):
        return obj.fk_fpo.fpo_name if obj.fk_fpo else None
##################----------------------------------Vegetable POP-----------------------############
@admin.register(VegetablePop)
class VegetablePopAdmin(admin.ModelAdmin):
    list_display = ('stages','description','stage_number','sow_period', 'get_crop_name','getlanguage','preference')
    list_filter = ('stages','fk_language')
    search_fields = ('stages', 'description')
    def get_crop_name(self, obj):
        return obj.fk_crop.crop_name if obj.fk_crop else None
    get_crop_name.short_description = 'Crop Name'

    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

##################################----------------------Spices POP------------------------##################
@admin.register(SpicesPop)
class SpicesPopAdmin(admin.ModelAdmin):
    list_display = ('stages','description','stage_number','getcrop_type', 'get_crop_name','getlanguage','preference')
    list_filter = ('stages','fk_language')
    search_fields = ('stages', 'description')
    def get_crop_name(self, obj):
        return obj.fk_crop.crop_name if obj.fk_crop else None
    get_crop_name.short_description = 'Crop Name'

    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

    def getcrop_type(self,obj):
        return obj.fk_croptype.name if obj.fk_croptype else None


###############################----------------------Stages Completion--------------------##########################
@admin.register(VegetableStageCompletion)
class VegtableStageCompletionAdmin(admin.ModelAdmin):
    list_display = ('vegetable_pop', 'stage_number', 'fk_farmer', 'completion_date', 'total_days_spent', 'delay_days')

@admin.register(VegetablePreferenceCompletion)
class VegetablePreferenceCompletionAdmin(admin.ModelAdmin):
    list_display = ('fk_farmer', 'fk_crop', 'preference_number', 'start_date', 'completion_date', 'total_days', 'is_completed')

    
@admin.register(SowingTime)    
class SowingTimeAdmin(admin.ModelAdmin):
    list_display = ('fk_user', 'get_crop_name', 'sowing_date')
    list_filter = ('fk_user', 'fk_crop', 'sowing_date')
    def get_crop_name(self, obj):
        return obj.fk_crop.crop_name if obj.fk_crop else None
    get_crop_name.short_description = 'Crop Name'

@admin.register(SowingProgress)
class SowingProgressAdmin(admin.ModelAdmin):
    list_display = ('fk_sowing_time', 'day_count', 'created_at','stage_start_date','stage_end_date')
    list_filter = ('created_at',)
    search_fields = ('fk_sowing_time', 'day_count')
    ordering = ('-created_at',)

@admin.register(StageCompletionInfo)
class StageCompletionInfoAdmin(admin.ModelAdmin):
    list_display = ['fk_sowing_progress', 'days_taken', 'total_days_taken']



################-----------------------------------------Govt Schemes-------------------######################
@admin.register(GovtSchemes)
class GovtSchemesAdmin(admin.ModelAdmin):
    list_display = ('scheme_name','scheme_by','getlanguage','display_links','display_image')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

    def getstate(self,obj):
        return obj.fk_state.state if obj.fk_state else None
    getstate.short_description='State'

    def display_links(self, obj):
        if obj.reference:
            links = obj.reference.split('\n')
            return '\n'.join(links)
        return ""
    def display_image(self, obj):
        if obj.scheme_image:
            return format_html('<a href="{}" target="_blank"><img src="{}" width="100px" /></a>', obj.scheme_image.url, obj.scheme_image.url)
        else:
            return '-'
    display_image.short_description = 'Image'



@admin.register(CurrentNews)
class CurrentNewsAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'getlanguage')
    list_filter = ('fk_language', 'created_at','source')
    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

@admin.register(FarmerLandAddress)
class FarmerLandAddressAdmin(admin.ModelAdmin):
    list_display = ('id','fk_farmer', 'land_area', 'address','getcrop_name','pincode', 'get_state', 'get_district', 'village', 'lat1', 'lat2',
                    'tehsil')
    def getcrop_name(self,obj):
        return obj.fk_crops.crop_name if obj.fk_crops else None
    getcrop_name.short_description = 'Crop Name'
    def get_state(self,obj):
        return obj.fk_state.state if obj.fk_state else None
    get_state.short_description='State'
    def get_district(self,obj):
        return obj.fk_district.district if obj.fk_district else None
    get_district.short_description='District'

@admin.register(Fertilizer)
class FertilizerAdmin(admin.ModelAdmin):
    list_display = ('get_state', 'fk_language', 'nitrogen', 'phosphorus', 'potassium', 'zincsulphate', 'measurement_type')
    search_fields = ('fk_state__state', 'fk_language__language')  
    list_filter = ('measurement_type',)
    def get_state(self,obj):
        return obj.fk_state.state if obj.fk_state else None
    get_state.short_description='State'

#################################------------------------------Fruits POP-----------------------------####################
@admin.register(CropFilter)
class CropFilterAdmin(admin.ModelAdmin):
    list_display = ['crop_categories', 'fk_language']

@admin.register(FruitsPop)
class FruitsPopAdmin(admin.ModelAdmin):
    list_display = ['stages','stage_name', 'stage_number', 'start_period', 'end_period', 'orchidtype',
                    'getlanguage','getcrop_name','crop_type']
    def getcrop_name(self,obj):
        return obj.fk_crops.crop_name if obj.fk_crops else None
    getcrop_name.short_description = 'Crop Name'

    def getlanguage(self,obj):
        return obj.fk_language.language if obj.fk_language else None
    getlanguage.short_description='Language'

    def crop_type(self,obj):
        return obj.fk_filter.crop_categories if obj.fk_filter else None
    crop_type.short_description='Crop Category'

@admin.register(FruitsStageCompletion)
class FruitsStageComplete(admin.ModelAdmin):
    list_display=('fk_fruits','fk_farmer','fk_farmland','start_date','completion_date','days_completed','delay_count')
##########################################---------------Product Prices--------------------------------------------------###############
@admin.register(ProductPrices)
class ProductPricesAdmin(admin.ModelAdmin):
    list_display = ('fk_product', 'purchase_price', 'unit_price', 'discount', 'final_price_unit')
    search_fields = ('fk_product__productName',)  # Assuming the ProductDetails model has a 'name' field
    list_filter = ('fk_product',)
###########################################----------------------Crop Variety---------------------------------------#################
@admin.register(CropVariety)
class CropVarietyAdmin(admin.ModelAdmin):
    list_display=('id','getcrop_name','variety')
    search_fields=('variety',)
    def getcrop_name(self,obj):
        return obj.fk_crops.crop_name if obj.fk_crops else None
    getcrop_name.short_description = 'Crop Name'
#################################---------------------------------Product Type--------------------------------###############
@admin.register(ProductType)
class ProductTypeAdmin(admin.ModelAdmin):
    list_display=('id','product_type')

###########################------------------------------------Salam Kisan Soil Testing----------------------###############
@admin.register(SalamKisanSoilTesting)
class SalamKisanSoilTest(admin.ModelAdmin):
    list_display=('fk_farmer','fk_farmland','cropselect')

################-----------------------------------------------Disease Video------------------------#############
@admin.register(DiseaseVideo)
class DiseaseVideoAdmin(admin.ModelAdmin):
    list_display=('fk_language','video')



################-----------------------------------------------OverallStageProgress------------------------#############
@admin.register(OverallStageProgress)
class OverallStageProgressAdmin(admin.ModelAdmin):
    list_display=('stage_name','preference','total_stages','completed_stages','overall_progress','fk_crop_id')    
################################------------------------------Crop Suggestion----------------#####################
@admin.register(SuggestedCrop)
class SuggestedCropAdmin(admin.ModelAdmin):
    list_display = ('season', 'start_month', 'end_month', 'weather_temperature', 'cost_of_cultivation', 'market_price', 'production', 'getcrop_name', 'fk_language')
    def getcrop_name(self,obj):
        return obj.fk_crop.crop_name if obj.fk_crop else None
    getcrop_name.short_description = 'Crop Name'