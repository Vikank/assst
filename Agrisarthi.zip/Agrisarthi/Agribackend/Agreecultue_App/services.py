import  json
import traceback
from django.http import JsonResponse
from .models import *
from .scraper import *
from .cron import *
from django.shortcuts import get_object_or_404
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
import random
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.sessions.models import Session
from django.http import HttpResponse
from django.db.models import Q
import pandas as pd
from django.conf import settings
import xlrd
import requests
import string
import os
from urllib.parse import urlparse
from django.core.exceptions import ObjectDoesNotExist
from django.core.files.base import ContentFile
from transformers import pipeline
from PIL import Image
from django.core.mail import send_mail
# from newsapi import NewsApiClient
from django.core.exceptions import ValidationError

###############################################---------------------------Salam Kisan API------------------------#####################
#1.Signup
@csrf_exempt
def SendFarmerProfile(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid HTTP method'}, status=405)
    
    farmer_id = request.POST.get('farmer_id')
    if not farmer_id:
        return JsonResponse({'error': 'Farmer ID not provided'}, status=400)
    
    try:
        farmer = FarmerProfile.objects.get(id=farmer_id)
    except FarmerProfile.DoesNotExist:
        return JsonResponse({'error': 'FarmerProfile not found'}, status=404)
    
    try:
        service_user = SalamKisanSoilTesting.objects.create(fk_farmer_id=farmer_id)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
    
    data = {
        'name': farmer.name,
        'mobile_number': farmer.mobile_number,
        'latitude': farmer.latitude,
        'longitude': farmer.longitude,
    }

    try:
        response = requests.post('http://65.45.87:8000/auth/v1/login', json=data)
        response_data = response.json()

        if response.status_code == 200 and response_data.get('success'):
            request.session['jwt'] = response_data['data']['jwt']
            return JsonResponse({
                'message': 'User logged in successfully',
                'jwt': response_data['data']['jwt'],
                'soil_testing_user_id': service_user.id
            })
        else:
            return JsonResponse({
                'error': 'Failed to login',
                'response': response_data
            }, status=400)

    except requests.exceptions.RequestException as e:
        return JsonResponse({'error': str(e)}, status=500)
#2.Address Endpoint
@csrf_exempt
def SendLandAddress(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid HTTP method'}, status=405)
    farmer_id = request.POST.get('farmer_id')
    if not farmer_id:
        return JsonResponse({'error': 'Farmer ID not provided'}, status=400)
    jwt = request.session.get('jwt')
    if not jwt:
        return JsonResponse({'error': 'JWT token not found. Please log in first.'}, status=403)
    try:
        farmerland = FarmerLandAddress.objects.get(fk_farmer_id=farmer_id)
    except FarmerLandAddress.DoesNotExist:
        return JsonResponse({'error': 'FarmerLand not found'}, status=404)
    
    data = {
        'address_line1': farmerland.address,
        'taluka': farmerland.tehsil
    }
    headers = {
        'Authorization': f'Bearer {jwt}'
    }
    try:
        response = requests.post('http://65.45.87:8000/user/v1/addresses', json=data, headers=headers)
        response_data = response.json()
        if response.status_code == 200:
            return JsonResponse({
                'message': 'Address sent successfully',
                'response': response_data
            })
        else:
            return JsonResponse({
                'error': 'Failed to send address',
                'response': response_data
            }, status=400)

    except requests.exceptions.RequestException as e:
        return JsonResponse({'error': str(e)}, status=500)
    
#3.Get All Crop--- Will be Used as it of salam kisann (Tobe call by Vikas)
#4.
