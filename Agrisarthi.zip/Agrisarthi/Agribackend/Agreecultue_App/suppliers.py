# Create your views here.
import  json
import traceback
from django.http import JsonResponse
from .models import *
from .scraper import *
from .cron import *
from django.shortcuts import get_object_or_404
from datetime import datetime
from django.db import transaction
from django.views.decorators.csrf import csrf_exempt
import random
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.sessions.models import Session
from django.http import HttpResponse
from django.db.models import Q
import pandas as pd
from django.conf import settings
import xlrd
import requests
import string
import os
from urllib.parse import urlparse
from django.core.exceptions import ObjectDoesNotExist
from django.core.files.base import ContentFile
from transformers import pipeline
from PIL import Image
from django.core.mail import send_mail
# from newsapi import NewsApiClient
from django.core.exceptions import ValidationError
######################-------------------------------Supplier Login----------------------------####################
@csrf_exempt
def Supplier_Login(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            mobile_no = data.get('mobile_no')
            user_language = data.get('user_language')
            if 'supplier_id' in request.session:
                obj = SupplierDetails.objects.get(id=request.session['supplier_id'])
                if obj.mobile_no == mobile_no:
                    obj.fk_language_id = user_language
                    obj.save()
                    return JsonResponse({'message': 'User already logged in', 'obj_id': obj.id,'user_exists': True})
            obj = SupplierDetails.objects.filter(mobile_no=mobile_no).first()
            if obj:
                obj.fk_language_id = user_language
                obj.save()
                request.session['supplier_id'] = obj.id
                
                return JsonResponse({
                    'message': 'User Logged in successfully',
                    'obj_id': obj.id,
                    'user_exists': True
                })
            else:
                obj = SupplierDetails.objects.create(mobile_no=mobile_no,fk_language_id=user_language)
                request.session['supplier_id'] = obj.id

                return JsonResponse({
                    'message': 'User created and logged in successfully',
                    'obj_id': obj.id,
                    'user_exists': False
                })
        else:
            return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
    
##############------------------------------------SUPPLIER LOGOUT------------------------------#######################
@csrf_exempt
def Supplier_Logout(request):
    try:
        if request.method == "POST":
            if 'supplier_id' in request.session:
                del request.session['supplier_id']
                request.session.save()
                return JsonResponse({'message': 'User logged out successfully'})
            else:
                return JsonResponse({'message': 'User not logged in'})
        else:
            return JsonResponse({'status': 'error', 'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
###------------------------------------------Get Supplier(User Details) Details-------------------------###################
@csrf_exempt
def GetSupplierProfileDetails(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            supplier_id = data['supplier_id']
            try:
                supplier_data = SupplierDetails.objects.filter(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'message': 'Supplier not found'}, status=404)
            supplierbank_business=BankBusinessDetails.objects.filter(fk_supplier_id=supplier_id)
            suppliershop_details=ShopDetails.objects.filter(fk_supplier_id=supplier_id)
            return JsonResponse({'message':'suceess',"basic_info":list(supplier_data.values()),
                                 'bank_business':list(supplierbank_business.values()),
                                 'shop_details':list(suppliershop_details.values())})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except SupplierDetails.DoesNotExist:
        return JsonResponse({'error': 'User does not exist'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
##################################------------------------Supplier Profile Update----------------------################
@csrf_exempt
def Supplier_Profile_Update(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            supplier_id = data.get('supplier_id')
            try:
                supplier = SupplierDetails.objects.get(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'message': 'Supplier not found'}, status=404)
            supplier_bank_business, created = BankBusinessDetails.objects.get_or_create(fk_supplier=supplier)
            supplier_shop,created=ShopDetails.objects.get_or_create(fk_supplier=supplier)
            supplier_fields = [
             'name', 'mobile_no', 'email', 'state', 'district', 'city', 'village','pincode'
            ]
            bank_business_fields = [
            'accountholder_name', 'account_number', 'bank_name', 'ifsc_code',
            'business_establishdate', 'pan_no', 'registration_id', 'gst_number'
            ]
            shop_details=[
                'shopName','shopContactNo','shopaddress','shop_opentime','shop_closetime','shop_opendays','shop_closedon'
            ]
            for i in supplier_fields:
                if i in data:
                    setattr(supplier,i,data[i])
            for i in bank_business_fields:
                if i in data:
                    setattr(supplier_bank_business,i,data[i])
            for i in shop_details:
                if i in data:
                    setattr(supplier_shop,i,data[i])
            supplier.save()
            supplier_bank_business.save()
            supplier_shop.save()
            return JsonResponse({'message': 'Supplier profile updated successfully'}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except SupplierDetails.DoesNotExist:
        return JsonResponse({'message': 'Supplier not found'}, status=404)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
    
######################-------------------------------Supplier Profile Picture Update-----------##################
@csrf_exempt
def SupplierProfilePictureUpdate(request):
    try:
        if request.method=="POST":
            supplier_id = request.POST.get('supplier_id')
            profile_image = request.FILES.get('profile_image')
            try:
                supplier_profile = SupplierDetails.objects.get(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'message': 'Supplier not found'}, status=404)
            supplier_profile.profile=profile_image
            supplier_profile.save()
            return JsonResponse({'message': 'Image updated successfully'}, status=200)
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': str(e)}, status=500)
#################--------------------------------------Add Product by Suppliers----------######################
@csrf_exempt
def AddProductDetails_Suppliers(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
        supplier_id = data.get('supplier_id')

        if not supplier_id:
            return JsonResponse({'message': 'Supplier ID is required'}, status=400)

        try:
            supplier_info = SupplierDetails.objects.get(id=supplier_id)
        except SupplierDetails.DoesNotExist:
            return JsonResponse({'message': 'Supplier not found'}, status=404)

        product_data = {
            'productName': data.get('productName'),
            'productDescription': data.get('productDescription'),
            'composition': data.get('composition'),
            'measurement_type': data.get('measurement_type'),
            'measurement_unit': data.get('measurement_unit'),
            'selling_status': data.get('selling_status'),
            'Category': data.get('Category'),
            'quantity': data.get('quantity'),
            'fk_productype_id': data.get('producttype'),
            'expiry_date': data.get('expiry_date'),
            'manufacturerName': data.get('manufacturerName')
        }

        product = ProductDetails.objects.create(**product_data)
        product.fk_supplier.set([supplier_info])  

        supplier = InputSuppliers.objects.create(
            fk_supplier=supplier_info,
            fk_productype_id=data.get('producttype'),
            quantity=data.get('quantity'),
            total_amount=data.get('purchase_price'),
            party_name=data.get('party_name'),
            party_mobileno=data.get('mobileno'),
            party_company=data.get('company_name'),
            unit_price=data.get('unit_price'),
            party_gst=data.get('party_gst')
        )
        product.fk_inputsupplier = supplier
        product.save()
        ProductPrices.objects.create(
            fk_product=product,
            fk_supplier=supplier_info,
            purchase_price=data.get('purchase_price'),
            unit_price=data.get('unit_price'),
            discount=data.get('discount'),
            final_price_unit=data.get('final_price'),
            fk_inputsupplier=supplier
        )

        InventoryDetails.objects.create(
            fk_product=product,
            stock=data.get('quantity', 0),
            fk_inputsupplier=supplier,
            fk_supplier=supplier_info
        )

        return JsonResponse({'message': 'Product created & Added successfully!'})
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
#############################--------------------------UPDATE Product Details BY Suppliers----------------############
@csrf_exempt
def UpdateProduct_DeatilsSuppliers(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        product_id = data.get('product_id')
        supplier_id = data.get('userid')
        if not product_id or not supplier_id:
            return JsonResponse({'message': 'Product ID and Supplier ID are required'}, status=400)
        try:
            supplier = SupplierDetails.objects.get(id=supplier_id)
        except SupplierDetails.DoesNotExist:
            return JsonResponse({'message': 'Supplier not found'}, status=404)
        try:
            product = ProductDetails.objects.get(id=product_id, fk_supplier=supplier)
        except ProductDetails.DoesNotExist:
            return JsonResponse({'message': 'Product not found'}, status=404)
        # Update the product details
        product.productName = data.get('productName', product.productName)
        product.quantity = data.get('quantity', product.quantity)
        product.expiry_date=data.get('expiry_date',product.expiry_date)
        product.productDescription = data.get('productDescription', product.productDescription)
        product.composition = data.get('composition', product.composition)
        product.measurement_type = data.get('measurement_type', product.measurement_type)
        product.measurement_unit=data.get('measurement_unit',product.measurement_unit)
        product.selling_status = data.get('selling_status', product.selling_status)
        product.manufacturerName = data.get('manufacturerName', product.manufacturerName)
        product.Category = data.get('Category', product.Category)
        product.save()
        try:
            product_prices = ProductPrices.objects.get(fk_product=product, fk_supplier=supplier)
            product_prices.purchase_price = data.get('purchase_price', product_prices.purchase_price)
            product_prices.unit_price = data.get('unit_price', product_prices.unit_price)
            product_prices.discount = data.get('discount', product_prices.discount)
            product_prices.final_price_unit = data.get('final_price', product_prices.final_price_unit)
            product_prices.save()
        except ProductPrices.DoesNotExist:
            return JsonResponse({'message': 'Product prices not found'}, status=404)
        try:
            inventory = InventoryDetails.objects.get(fk_product=product,fk_supplier=supplier)
            inventory.stock = product.quantity
            inventory.save()
        except InventoryDetails.DoesNotExist:
            return JsonResponse({'message': 'Inventory details not found'}, status=404)

        return JsonResponse({'message': 'Product updated successfully!'})
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
#######################----------------------------Get FPO Supplier Details-----------------#########
@csrf_exempt
def GetSuppliersDetailsInfo(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            supplier_id = data.get('supplier_id')
            if not supplier_id:
                return JsonResponse({'message': 'Supplier ID not provided'}, status=400)
            try:
                supplier_info = SupplierDetails.objects.get(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'message': 'Supplier not found'}, status=404)
            
            suppliers = InputSuppliers.objects.filter(fk_supplier=supplier_info)
            supplier_details = []
            product_details = []
            price_details = []

            for supplier in suppliers:
                products = ProductDetails.objects.filter(fk_inputsupplier_id=supplier.id,fk_supplier=supplier_info)
                product_names = ', '.join([product.productName for product in products])
                
                supplier_details.append({
                    'supplierid': supplier.id,
                    'suppliername': supplier.party_name,
                    'suppliermobileno': supplier.party_mobileno,
                    'party_company': supplier.party_company,
                    'total_amount': supplier.total_amount,
                    'unit_pricebought': supplier.unit_price,
                    'party_gst': supplier.party_gst,
                    'producttype': supplier.fk_productype.product_type if supplier.fk_productype else None,
                    'quantity': supplier.quantity,
                    'product_names': product_names
                })

                for product in products:
                    product_details.append({
                        'supplierid': product.fk_inputsupplier.id if product.fk_inputsupplier else None,
                        'product_id': product.id,
                        'productName': product.productName,
                        'Category': product.Category,
                        'productDescription': product.productDescription,
                        'composition': product.composition,
                        'measurement_type': product.measurement_type,
                        'measurement_unit': product.measurement_unit,
                        'selling_status': product.selling_status,
                        'manufacturerName': product.manufacturerName,
                        'expiry_date': product.expiry_date
                    })

                prices = ProductPrices.objects.filter(fk_inputsupplier_id=supplier.id,fk_supplier=supplier_info)
                for price in prices:
                    price_details.append({
                        'product_id': price.fk_product.id if price.fk_product else None,
                        'supplierid': price.fk_inputsupplier.id if price.fk_inputsupplier else None,
                        'unit_price': price.unit_price,
                        'purchase_price': price.purchase_price,
                    })

            return JsonResponse({"message": "success", 'supplier_details': supplier_details, 'product_details': product_details, 'price_details': price_details})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        import traceback
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
####################----------------------SHow Product/Inventory DETAILS---------------------------##########
@csrf_exempt
def ShowInventorySupplier(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method. Use POST.'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        supplier_id = data.get('supplier_id')
        if not supplier_id:
            return JsonResponse({'error': 'Supplier ID are required.'}, status=400)
        supplier = SupplierDetails.objects.filter(id=supplier_id).first()
        if not supplier:
            return JsonResponse({'error': 'Invalid supplier ID.'}, status=400)
        products = ProductDetails.objects.filter(fk_supplier=supplier)
        response_data = []
        for product in products:
            inventory = InventoryDetails.objects.filter(fk_product=product,fk_supplier=supplier).first()
            response_data.append({
                'product_id': product.id,
                'Product Name': product.productName,
                'Category': product.Category,
                'Product Expiry':product.expiry_datestatus() if product else None,
                'Inventory id': inventory.id if inventory else None,
                'stock_status': inventory.stock_status() if inventory else None,
                'stock_quantity': inventory.stock if inventory else 0,
                "Sell via":product.selling_status if product else None
            })

        return JsonResponse(response_data, safe=False)

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)  
#############################------------------------------Update Inventory By Suppliers------------------------------################
@csrf_exempt
def UpdateInventorybySupplier(request):
    try:
        if request.method=="POST":
            data=json.loads(request.body.decode('utf-8'))
            inventory_id=data.get('inventory_id')
            new_stock=data.get('new_stock')
            supplier_id=data.get('supplier_id')
            try:
                supplier = SupplierDetails.objects.get(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'message': 'Supplier not found'}, status=404)
            if inventory_id is None or new_stock is None:
                return JsonResponse({'error': 'Inventory ID and new stock value are required.'}, status=400)
            try:
                new_stock = int(new_stock)
            except ValueError:
                return JsonResponse({'error': 'Stock value must be an integer.'}, status=400)
            inventory = InventoryDetails.objects.filter(id=inventory_id,fk_supplier=supplier).first()
            product_id=inventory.fk_product.id
            if not inventory:
                return JsonResponse({'error': 'Invalid inventory ID.'}, status=400)
            # Get the associated product
            product = ProductDetails.objects.filter(id=product_id).first()
            if not product:
                return JsonResponse({'error': 'Associated product not found.'}, status=400)
            if new_stock > product.quantity:
                return JsonResponse({
                    'error': 'Stock update failed. New stock value exceeds the product\'s original quantity.',
                    'max_allowed': product.quantity
                }, status=400)
            inventory.stock = new_stock
            inventory.save()

            return JsonResponse({
            'message': 'Stock updated successfully',
            'inventory_id': inventory.id,
            'new_stock': inventory.stock,
            'stock_status': inventory.stock_status()
        })

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)



##################################-----------------------------------ADD Sales to Customer by Suppliers---------------############
@csrf_exempt
def AddSalesbySupplier(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            supplier_id = data.get('supplier_id')
            buyer_name = data.get('buyer_name')
            mobile_no = data.get('mobile_no')
            address = data.get('address')
            sale_date = data.get('sale_date')
            products = data.get('products')
            payment=data.get('payment') 
            if not supplier_id:
                return JsonResponse({'error': 'Invalid Supplier ID.'}, status=400)
            try:
                supplier = SupplierDetails.objects.get(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'message': 'Supplier not found'}, status=404)
            customer = CustomerDetails.objects.create(
                buyer_name=buyer_name,
                mobile_no=mobile_no,
                address=address,
                fk_supplier=supplier
            )
            with transaction.atomic():
                sale_responses = []
                total_price = 0
                for product_data in products:
                    quantity = product_data.get('Quantity')
                    inventory_id = product_data.get('inventory_id')
                    inventory = InventoryDetails.objects.filter(id=inventory_id, fk_supplier=supplier).first()
                    if not inventory:
                        return JsonResponse({'error': f'Inventory not found for product id: {inventory_id}'}, status=404)
                    product = inventory.fk_product
                    if inventory.stock < quantity:
                        return JsonResponse({"error": f"Insufficient stock for product: {product.productName}"}, status=400)

                    # Final Price Calculation
                    try:
                        productprice = ProductPrices.objects.filter(fk_product=product).first()
                        price = productprice.final_price_unit
                        amount = price * quantity
                    except TypeError:
                        return JsonResponse({'error': f'Invalid price or quantity for product: {product.productName}'}, status=400)

                    # Update Inventory
                    inventory.stock -= quantity
                    inventory.save()

                    # Update Product Quantity
                    product.quantity -= quantity
                    product.save()

                    # Create Sales
                    sale = ProductSale.objects.create(
                        fk_invent=inventory,
                        amount=amount,
                        sales_date=sale_date,
                        final_price=price,
                        payment_method=payment,
                        fk_custom=customer
                    )

                    sale_responses.append({
                        "sale_id": sale.id,
                        "product_name": product.productName,
                        "final_price": price,
                        "remaining_stock": inventory.stock,
                    })
                    total_price += price

                    SalesRecordItem.objects.create(
                        name=buyer_name,
                        quantity=quantity,
                        total_amount=total_price,
                        fk_supplier=supplier,
                        sales_date=sale_date,
                        category=inventory.fk_product.fk_productype.product_type,
                        fk_inputsupplier=inventory.fk_inputsupplier
                    )

            return JsonResponse({
                "message": "Sales processed successfully",
                "sales": sale_responses,
                "total_price": total_price
            }, status=201)

        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except KeyError as e:
        return JsonResponse({"error": f"Missing field {str(e)}"}, status=400)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': traceback.format_exc()}, status=500)
    
################---------------------------------Get all Sales by Supplier---------------###################################
@csrf_exempt
def GetSupplier_CustomerRecordSales(request):
    try:
        if request.method=="POST":
            data = json.loads(request.body.decode('utf-8'))
            supplier_id = data.get('supplier_id')
            customer_sales=SalesRecordItem.objects.filter(fk_supplier_id=supplier_id)
            return JsonResponse({"message": "success",'data':list(customer_sales.values())})
        else:
            return JsonResponse({'message': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
    
###########################----------------------------Get Supplier All Products------------------###################
@csrf_exempt
def GetThirdPartySupplier_AllProducts(request):
    if request.method != 'POST':
        return JsonResponse({'message': 'Method not allowed'}, status=405)
    try:
        data = json.loads(request.body.decode('utf-8'))
        supplier_id = data.get('supplier_id')
        products = InventoryDetails.objects.filter(fk_supplier_id=supplier_id)
        if not products.exists():
            return JsonResponse({'message': 'No products found for the specified filter type'}, status=404)
        product_list = []
        for product in products:
            product_details = product.fk_product  
            if product_details:
                product_data = {
                    'inventory_id': product.id,
                    'supplier_id':product.fk_inputsupplier.id if product.fk_inputsupplier else None,
                    'supplier_state':product.fk_inputsupplier.state if product.fk_inputsupplier else None,
                    'supplier_name':product.fk_inputsupplier.party_name if product.fk_inputsupplier else None,
                    'supplier_district':product.fk_inputsupplier.district if product.fk_inputsupplier else None,
                    'stock_status': product.stock_status() if product else None,
                    'stock_quantity': product.stock if product else 0,
                    'product_id': product_details.id,
                    'productName': product_details.productName,
                    'Category': product_details.Category,
                    'product_type': product_details.fk_productype.product_type,
                }
                product_prices = ProductPrices.objects.filter(fk_product=product_details)
                if product_prices.exists():
                    price_data = {
                        'purchase_price': product_prices.first().purchase_price,
                        'unit_price': product_prices.first().unit_price,
                        'discount': product_prices.first().discount,
                        'final_price': product_prices.first().final_price_unit,
                    }
                    product_data.update(price_data)

                product_list.append(product_data)

        return JsonResponse({'status': 'success', 'products': product_list})

    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)
###########################---------------------------Get Single Product Details---------------------------##############
@csrf_exempt
def GetSingleProduct_SupplierDetails(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body.decode('utf-8'))
            supplier_id = data['supplier_id']
            product_id = data.get('product_id') 
            try:
                supplier = SupplierDetails.objects.get(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'error': 'User does not exist'}, status=404)
            
            fpo_product = ProductDetails.objects.filter(fk_supplier=supplier, id=product_id)
            for i in fpo_product:
                prices=ProductPrices.objects.filter(fk_product=i,fk_supplier=supplier).first()
                res=({
                    'productid':i.id,
                    "productname":i.productName,
                    "productdescription":i.productDescription,
                    'manufacturerName':i.manufacturerName,
                    'manufacturing_date':i.manufacturing_date,
                    'crop_id':i.fk_crops.id if i.fk_crops else None,
                    'measurement_type':i.measurement_type,
                    'measurement_unit':i.measurement_unit,
                    'composition':i.composition,
                    'quantity':i.quantity,
                    'selling_status':i.selling_status,
                    'productype':i.fk_productype.product_type,
                    'Category':i.Category,
                    'expirydate':i.expiry_date,
                    'purchase_price':prices.purchase_price if prices else None,
                    'unit_price':prices.unit_price if prices else None,
                    'discount':prices.discount if prices else None,
                    'gst':prices.gst if prices else None,
                    'sgst':prices.sgst if prices else None,
                    'cgst':prices.cgst if prices else None,
                    'final_price_unit':prices.final_price_unit if prices else None
                })
            return JsonResponse({"success": res})
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)
    except Exception as e:
        return JsonResponse({'message': 'An error occurred', 'error': traceback.format_exc()}, status=500)

#############################-----------------------------------Suppliers Dashboard Home Page---------------------##########
#1.Inventory In & Out of Stock
def format_inventory_details(inventory_items):
    """Helper function to format inventory details."""
    return [{
        'inventory_id': item.id,
        'product_id': item.fk_product.id if item.fk_product else None,
        'productname': item.fk_product.productName if item.fk_product else None,
        'productytpe': item.fk_product.fk_productype.product_type if item.fk_product else None,
        'stock': item.stock,
        'stock_status': item.stock_status()
    } for item in inventory_items]

@csrf_exempt
def Supplier_Inventoryin_outstock(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode('utf-8'))
            userid = data.get('userid')
            filter_type = data.get('filter_type')
            required_fields=['userid', 'filter_type']
            for i  in required_fields:
                if not data.get(i):
                    return JsonResponse({'message': f'Missing{i} is required'}, status=400)
            try:
                supplier = SupplierDetails.objects.get(id=userid)
            except FPOProfile.DoesNotExist:
                return JsonResponse({'message': 'FPO not found'}, status=404)

            in_stock_filter = InventoryDetails.objects.filter(stock__gte=10, fk_supplier=supplier, fk_product__selling_status=filter_type)
            out_stock_filter = InventoryDetails.objects.filter(stock=0, fk_supplier=supplier,fk_product__selling_status=filter_type)

            # Apply common formatting
            instockls = format_inventory_details(in_stock_filter)
            outtockls = format_inventory_details(out_stock_filter)

            # Get totals
            totalintsock = in_stock_filter.count()
            totaloutsock = out_stock_filter.count()

            return JsonResponse({
                'message': 'success',
                'In Stock': instockls,
                'In Stock Total': totalintsock,
                'Out of Stock': outtockls,
                'Out Stock Total': totaloutsock
            })

        except json.JSONDecodeError:
            return JsonResponse({'message': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': 'An error occurred.', 'details': str(e), 'traceback': traceback.format_exc()}, status=500)

    return JsonResponse({'error': 'Invalid request method.'}, status=405)
#######################------------------------------GetTotal Sales By Suppliers-----------------###############
@csrf_exempt
def GetTotalSalesBySuppliers(request):
    try:
        if request.method == "POST":
            data = json.loads(request.body.decode('utf-8'))
            supplier_id = data.get('supplier_id')
            filter_type = data.get('filter_type')
            sales_status=data.get('sales_status')
            if supplier_id is None:
                return JsonResponse({'error': 'Supplier ID not provided'}, status=400)
            try:
                supplier = SupplierDetails.objects.get(id=supplier_id)
            except SupplierDetails.DoesNotExist:
                return JsonResponse({'message': 'Supplier not found'}, status=404)
            sales=SalesRecordItem.objects.filter(fk_supplier=supplier,category=filter_type)
            sales_count = sales.count()
            total_sales_amount = sales.aggregate(total=models.Sum('total_amount'))['total'] or 0
            profit_sales=ProductPrices.objects.filter(fk_supplier=supplier,fk_product__fk_productype__product_type=filter_type,
                                                      fk_product__selling_status=sales_status)
            total_profit = sum(
                (ps.final_price_unit - ps.unit_price)
                for ps in profit_sales
            )
            return JsonResponse({
                'sales_count': sales_count,
                'total_sales_amount': total_sales_amount,
                'total_profit':total_profit
            }, status=200)
    except Exception as e:
        return JsonResponse({'error': 'An error occurred.', 'details': str(e)}, status=500)
